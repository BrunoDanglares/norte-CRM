import { useEffect, useState } from 'react';
import './index.css';
import { useStore } from './store/useStore';
import { authService } from './services';
import { getToken } from './services/api';
import Sidebar from './components/layout/Sidebar';
import Topbar from './components/layout/Topbar';
import { Notifications } from './components/ui';
import Login from './components/pages/Login';
import Dashboard from './components/pages/Dashboard';
import Leads from './components/pages/Leads';
import Pipeline from './components/pages/Pipeline';
import Contatos from './components/pages/Contatos';
import Inbox from './components/pages/Inbox';
import { Automacoes } from './components/pages/Automacoes';
import {
  Agenda, Financeiro, Campanhas,
  IA, Conexoes, Usuarios, Integracoes, Billing,
  Relatorios, Configuracoes, Perfil
} from './components/pages/OtherPages';

// Hook para carregar dados da página ativa
function usePageData(page, store) {
  useEffect(() => {
    const loaders = {
      dashboard:    () => { store.fetchLeads(); store.fetchConversations(); store.fetchAgenda(); },
      leads:        () => store.fetchLeads(),
      pipeline:     () => store.fetchLeads(),
      contatos:     () => store.fetchContatos(),
      inbox:        () => store.fetchConversations(),
      campanhas:    () => store.fetchCampanhas(),
      automacoes:   () => store.fetchAutomacoes(),
      ia:           () => store.fetchKb(),
      agenda:       () => store.fetchAgenda(),
      financeiro:   () => store.fetchFinanceiro(),
      usuarios:     () => store.fetchUsuarios(),
      billing:      () => store.fetchBilling(),
      conexoes:     () => store.fetchConexoes(),
    };
    loaders[page]?.();
  }, [page]);
}

const PAGES = {
  dashboard:    <Dashboard />,
  leads:        <Leads />,
  pipeline:     <Pipeline />,
  contatos:     <Contatos />,
  inbox:        <Inbox />,
  campanhas:    <Campanhas />,
  automacoes:   <Automacoes />,
  ia:           <IA />,
  agenda:       <Agenda />,
  financeiro:   <Financeiro />,
  relatorios:   <Relatorios />,
  conexoes:     <Conexoes />,
  usuarios:     <Usuarios />,
  integracoes:  <Integracoes />,
  billing:      <Billing />,
  configuracoes:<Configuracoes />,
  perfil:       <Perfil />,
};

export default function App() {
  const { user, setUser, currentPage } = useStore();
  const store = useStore();
  const [checking, setChecking] = useState(true);

  // Verificar se já há token salvo ao abrir o app
  useEffect(() => {
    const token = getToken();
    if (token) {
      authService.me()
        .then(u => setUser(u))
        .catch(() => {})
        .finally(() => setChecking(false));
    } else {
      setChecking(false);
    }
  }, []);

  // Carregar dados da página ativa
  usePageData(currentPage, store);

  if (checking) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)' }}>
        <div style={{ color: 'var(--muted)', fontSize: 13 }}>⏳ Carregando...</div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={(u) => setUser(u)} />;
  }

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <Sidebar />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <Topbar />
        <div style={{ flex: 1, overflow: 'hidden', background: 'var(--bg)' }}>
          {PAGES[currentPage] || <Dashboard />}
        </div>
      </div>
      <Notifications />
    </div>
  );
}
