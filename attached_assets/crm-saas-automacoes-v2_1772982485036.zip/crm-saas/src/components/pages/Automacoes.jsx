import { useState, useRef, useEffect } from 'react';
import { useStore } from '../../store/useStore';
import { automacoesService } from '../../services';

// ─── Tipos de nó ─────────────────────────────────────────────────────────────
const NODE_TYPES = {
  trigger:      { label: 'Gatilho',          icon: '🎯', color: '#34d399', bg: '#34d39918' },
  send_message: { label: 'Enviar Mensagem',   icon: '💬', color: '#9b7ee0', bg: '#9b7ee018' },
  delay:        { label: 'Aguardar',          icon: '⏱',  color: '#60a5fa', bg: '#60a5fa18' },
  condition:    { label: 'Condição',          icon: '🔀', color: '#fbbf24', bg: '#fbbf2418' },
  tag_lead:     { label: 'Marcar Lead',       icon: '🏷',  color: '#f97316', bg: '#f9731618' },
  assign_agent: { label: 'Atribuir Agente',   icon: '👤', color: '#a78bfa', bg: '#a78bfa18' },
  update_lead:  { label: 'Atualizar Lead',    icon: '✏️', color: '#2dd4bf', bg: '#2dd4bf18' },
  ai_response:  { label: 'Resposta IA',       icon: '🤖', color: '#e879f9', bg: '#e879f918' },
  webhook:      { label: 'Webhook',           icon: '🔗', color: '#fb7185', bg: '#fb718518' },
  end:          { label: 'Fim do Fluxo',      icon: '🏁', color: '#6b6190', bg: '#6b619018' },
};

const TRIGGER_OPTIONS = [
  { value: 'new_message',         label: '💬 Nova mensagem recebida' },
  { value: 'conversation_opened', label: '🔔 Conversa iniciada' },
  { value: 'lead_created',        label: '✨ Lead criado' },
  { value: 'lead_status_changed', label: '🔄 Status do lead alterado' },
  { value: 'lead_won',            label: '🏆 Lead marcado como Ganho' },
  { value: 'lead_lost',           label: '❌ Lead marcado como Perdido' },
  { value: 'tag_added',           label: '🏷 Tag adicionada ao lead' },
  { value: 'scheduled',           label: '⏰ Agendado (horário fixo)' },
  { value: 'form_submitted',      label: '📝 Formulário enviado' },
  { value: 'inactivity',          label: '💤 Inatividade detectada' },
];

const UNIT_LABELS = { seconds: 'seg', minutes: 'min', hours: 'h', days: 'dias' };

const STATUS_CONF = {
  ACTIVE: { dot: '#34d399', label: 'Ativa',    btn: '⏸ Pausar'  },
  PAUSED: { dot: '#fbbf24', label: 'Pausada',  btn: '▶ Ativar'  },
  DRAFT:  { dot: '#6b6190', label: 'Rascunho', btn: '▶ Ativar'  },
};

const TEMPLATES = [
  { id:'boas_vindas', icon:'👋', name:'Boas-vindas WhatsApp', desc:'Resposta automática para novos contatos no WA', cat:'Atendimento', trigger:'Conversa iniciada',
    nodes:[
      {id:'n1',type:'trigger',label:'Conversa iniciada',config:{triggerType:'conversation_opened',channel:'whatsapp'},x:180,y:30,next:['n2']},
      {id:'n2',type:'delay',label:'Aguardar 3s',config:{value:3,unit:'seconds'},x:180,y:150,next:['n3']},
      {id:'n3',type:'send_message',label:'Boas-vindas',config:{content:'Olá {{nome}}! 👋\n\nBem-vindo(a) ao nosso atendimento!\n\nEm que posso te ajudar hoje?'},x:180,y:270,next:['n4']},
      {id:'n4',type:'assign_agent',label:'Atribuir à equipe',config:{strategy:'round_robin'},x:180,y:410,next:['n5']},
      {id:'n5',type:'end',label:'Fim do fluxo',config:{},x:180,y:530,next:[]},
    ],
  },
  { id:'qualificacao', icon:'🔥', name:'Qualificação com IA', desc:'IA classifica leads em Quente, Morno ou Frio', cat:'Vendas', trigger:'Lead criado',
    nodes:[
      {id:'n1',type:'trigger',label:'Lead criado',config:{triggerType:'lead_created'},x:180,y:30,next:['n2']},
      {id:'n2',type:'ai_response',label:'Classificar com IA',config:{systemPrompt:'Classifique o lead e responda APENAS: HOT, WARM ou COLD',model:'gpt-4o-mini',saveAs:'aiScore'},x:180,y:150,next:['n3']},
      {id:'n3',type:'condition',label:'É lead quente?',config:{field:'aiScore',operator:'contains',value:'HOT'},x:180,y:300,nextTrue:'n4',nextFalse:'n5'},
      {id:'n4',type:'tag_lead',label:'Tag: Lead Quente',config:{tags:['lead-quente','prioridade-alta'],action:'add'},x:60,y:440,next:['n6']},
      {id:'n5',type:'tag_lead',label:'Tag: Lead Morno',config:{tags:['lead-morno'],action:'add'},x:300,y:440,next:['n6']},
      {id:'n6',type:'assign_agent',label:'Atribuir vendedor',config:{strategy:'least_busy'},x:180,y:570,next:['n7']},
      {id:'n7',type:'end',label:'Fim do fluxo',config:{},x:180,y:690,next:[]},
    ],
  },
  { id:'followup', icon:'📞', name:'Follow-up Após Proposta', desc:'Acompanha leads em estágio de proposta', cat:'Vendas', trigger:'Status: Proposta',
    nodes:[
      {id:'n1',type:'trigger',label:'Status → Proposta',config:{triggerType:'lead_status_changed'},x:180,y:30,next:['n2']},
      {id:'n2',type:'delay',label:'Aguardar 24h',config:{value:24,unit:'hours'},x:180,y:150,next:['n3']},
      {id:'n3',type:'send_message',label:'Follow-up Dia 1',config:{content:'Olá {{nome}}! 😊\n\nPassando para ver se teve chance de analisar nossa proposta.\n\nFicou alguma dúvida?'},x:180,y:270,next:['n4']},
      {id:'n4',type:'delay',label:'Aguardar 3 dias',config:{value:3,unit:'days'},x:180,y:410,next:['n5']},
      {id:'n5',type:'condition',label:'Respondeu?',config:{field:'replied',operator:'eq',value:'true'},x:180,y:530,nextTrue:'n7',nextFalse:'n6'},
      {id:'n6',type:'send_message',label:'Follow-up Final',config:{content:'Oi {{nome}}, última tentativa! 🙏\n\nPosso oferecer condições especiais para fecharmos esta semana?'},x:60,y:660,next:['n7']},
      {id:'n7',type:'end',label:'Fim do fluxo',config:{},x:180,y:790,next:[]},
    ],
  },
  { id:'notif_lead', icon:'🔔', name:'Notificar Equipe — Novo Lead', desc:'Avisa a equipe quando chega lead novo', cat:'Comercial', trigger:'Lead criado',
    nodes:[
      {id:'n1',type:'trigger',label:'Lead criado',config:{triggerType:'lead_created'},x:180,y:30,next:['n2']},
      {id:'n2',type:'send_message',label:'Alerta equipe',config:{content:'🆕 *Novo lead!*\n👤 {{nome}}\n🏢 {{empresa}}\n📞 {{telefone}}\n💰 R$ {{valor}}\n📊 Canal: {{canal}}'},x:180,y:150,next:['n3']},
      {id:'n3',type:'assign_agent',label:'Atribuir vendedor',config:{strategy:'round_robin'},x:180,y:290,next:['n4']},
      {id:'n4',type:'tag_lead',label:'Tag: novo-lead',config:{tags:['novo'],action:'add'},x:180,y:410,next:['n5']},
      {id:'n5',type:'end',label:'Fim do fluxo',config:{},x:180,y:530,next:[]},
    ],
  },
  { id:'reativacao', icon:'💤', name:'Reativação de Leads Frios', desc:'Reengaja leads sem resposta há 7+ dias', cat:'Retenção', trigger:'Inatividade',
    nodes:[
      {id:'n1',type:'trigger',label:'Inatividade 7 dias',config:{triggerType:'inactivity'},x:180,y:30,next:['n2']},
      {id:'n2',type:'condition',label:'Lead ainda ativo?',config:{field:'status',operator:'neq',value:'GANHO'},x:180,y:150,nextTrue:'n3',nextFalse:'n5'},
      {id:'n3',type:'send_message',label:'Reativação',config:{content:'Oi {{nome}}! 👋\n\nFaz um tempinho que não conversamos...\n\nTem algum projeto novo que posso te ajudar?'},x:80,y:290,next:['n4']},
      {id:'n4',type:'tag_lead',label:'Tag: reativado',config:{tags:['reativado'],action:'add'},x:80,y:420,next:['n5']},
      {id:'n5',type:'end',label:'Fim do fluxo',config:{},x:180,y:550,next:[]},
    ],
  },
  { id:'pos_venda', icon:'⭐', name:'Pós-venda & NPS', desc:'Agradecimento + pesquisa NPS após fechar', cat:'Retenção', trigger:'Lead ganho',
    nodes:[
      {id:'n1',type:'trigger',label:'Lead marcado como Ganho',config:{triggerType:'lead_won'},x:180,y:30,next:['n2']},
      {id:'n2',type:'send_message',label:'Agradecimento',config:{content:'🎉 {{nome}}, muito obrigado pela confiança!\n\nÉ uma honra ter você como cliente!'},x:180,y:150,next:['n3']},
      {id:'n3',type:'delay',label:'Aguardar 5 dias',config:{value:5,unit:'days'},x:180,y:280,next:['n4']},
      {id:'n4',type:'send_message',label:'Pesquisa NPS',config:{content:'Olá {{nome}}! 😊\n\nDe 0 a 10, quanto nos indicaria a um amigo?\n\n0️⃣1️⃣2️⃣3️⃣4️⃣5️⃣6️⃣7️⃣8️⃣9️⃣🔟'},x:180,y:400,next:['n5']},
      {id:'n5',type:'tag_lead',label:'Tag: cliente-ativo',config:{tags:['cliente','nps-enviado'],action:'add'},x:180,y:530,next:['n6']},
      {id:'n6',type:'end',label:'Fim do fluxo',config:{},x:180,y:650,next:[]},
    ],
  },
];

function genId() { return 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2,5); }

const MOCK_DATA = [
  { nome:'Boas-vindas WhatsApp', status:'ACTIVE', trigger:'Conversa iniciada', execucoes:1247, passos:5, _local:true, nodes: TEMPLATES[0].nodes },
  { nome:'Qualificação com IA',  status:'ACTIVE', trigger:'Lead criado',       execucoes:388,  passos:7, _local:true, nodes: TEMPLATES[1].nodes },
  { nome:'Follow-up Proposta',   status:'PAUSED', trigger:'Status: Proposta',  execucoes:94,   passos:7, _local:true, nodes: TEMPLATES[2].nodes },
  { nome:'Notif. Novo Lead',     status:'ACTIVE', trigger:'Lead criado',       execucoes:521,  passos:5, _local:true, nodes: TEMPLATES[3].nodes },
  { nome:'Reativação Frios',     status:'DRAFT',  trigger:'Inatividade',       execucoes:0,    passos:5, _local:true, nodes: TEMPLATES[4].nodes },
];

// ─── Estilos ──────────────────────────────────────────────────────────────────
const S = {
  btnPrimary: { display:'inline-flex', alignItems:'center', gap:6, padding:'7px 14px', borderRadius:9, background:'linear-gradient(135deg,var(--accent),var(--accent2))', border:'none', color:'#fff', fontSize:12, fontWeight:700, cursor:'pointer', fontFamily:'inherit', whiteSpace:'nowrap' },
  btnGhost:   { display:'inline-flex', alignItems:'center', gap:6, padding:'6px 12px', borderRadius:8, border:'1px solid var(--border2)', background:'var(--card2)', color:'var(--text2)', fontSize:12, fontWeight:600, cursor:'pointer', fontFamily:'inherit', whiteSpace:'nowrap' },
  iconBtnSm:  { display:'inline-flex', alignItems:'center', gap:4, padding:'5px 10px', borderRadius:7, border:'1px solid var(--border)', background:'transparent', color:'var(--muted2)', fontSize:11.5, fontWeight:600, cursor:'pointer', fontFamily:'inherit', whiteSpace:'nowrap' },
  iconBtn:    { background:'transparent', border:'none', cursor:'pointer', fontSize:14, color:'var(--muted)', padding:'2px 6px', borderRadius:5 },
  label:      { display:'block', fontSize:10.5, fontWeight:700, color:'var(--muted2)', textTransform:'uppercase', letterSpacing:.5, marginBottom:5 },
  input:      { width:'100%', padding:'7px 10px', borderRadius:8, border:'1.5px solid var(--border)', background:'var(--card2)', color:'var(--text)', fontSize:12, outline:'none', fontFamily:'inherit', boxSizing:'border-box' },
};

// ─── COMPONENTE PRINCIPAL ─────────────────────────────────────────────────────
export function Automacoes() {
  const notify = useStore(s => s.notify);
  const [list, setList]           = useState(MOCK_DATA);
  const [selIdx, setSelIdx]       = useState(null);
  const [nodes, setNodes]         = useState([]);
  const [selNode, setSelNode]     = useState(null);
  const [isDirty, setIsDirty]     = useState(false);
  const [loading, setLoading]     = useState(false);
  const [testLog, setTestLog]     = useState(null);
  const [modal, setModal]         = useState(null);
  const [newName, setNewName]     = useState('');
  const [newTrig, setNewTrig]     = useState('new_message');

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const res = await automacoesService.list();
        const data = Array.isArray(res?.data) ? res.data : (Array.isArray(res) ? res : []);
        if (data.length > 0) setList(data);
      } catch {}
      setLoading(false);
    })();
  }, []);

  function openAuto(i) {
    const a = list[i];
    setSelIdx(i);
    setNodes(a.nodes?.length ? JSON.parse(JSON.stringify(a.nodes)) : defaultNodes(a));
    setSelNode(null);
    setIsDirty(false);
    setTestLog(null);
  }

  function defaultNodes(a) {
    return [
      {id:'n1',type:'trigger',label:a.trigger||'Gatilho',config:{triggerType:'new_message'},x:180,y:30,next:['n2']},
      {id:'n2',type:'send_message',label:'Enviar mensagem',config:{content:''},x:180,y:170,next:['n3']},
      {id:'n3',type:'end',label:'Fim do fluxo',config:{},x:180,y:310,next:[]},
    ];
  }

  function addNode(type, x=220, y=200) {
    const id = genId();
    setNodes(prev => [...prev, { id, type, label:NODE_TYPES[type].label, config:{}, x, y, next:[] }]);
    setSelNode(id);
    setIsDirty(true);
  }

  function updatePos(id, x, y) {
    setNodes(prev => prev.map(n => n.id===id ? {...n,x,y} : n));
  }

  function updateCfg(id, field, value) {
    setNodes(prev => prev.map(n => n.id===id ? {...n, config:{...n.config,[field]:value}} : n));
    setIsDirty(true);
  }

  function updateLabel(id, label) {
    setNodes(prev => prev.map(n => n.id===id ? {...n,label} : n));
    setIsDirty(true);
  }

  function deleteNode(id) {
    setNodes(prev => prev.filter(n=>n.id!==id).map(n=>({
      ...n,
      next:(n.next||[]).filter(x=>x!==id),
      nextTrue:n.nextTrue===id?undefined:n.nextTrue,
      nextFalse:n.nextFalse===id?undefined:n.nextFalse,
    })));
    if (selNode===id) setSelNode(null);
    setIsDirty(true);
  }

  function addEdge(fromId, toId, branch) {
    setNodes(prev => prev.map(n => {
      if (n.id!==fromId) return n;
      if (branch==='true')  return {...n,nextTrue:toId};
      if (branch==='false') return {...n,nextFalse:toId};
      return (n.next||[]).includes(toId) ? n : {...n,next:[...(n.next||[]),toId]};
    }));
    setIsDirty(true);
    notify('🔗 Nós conectados!');
  }

  async function save() {
    if (selIdx===null) return;
    const cur = list[selIdx];
    try {
      if (cur.id && !cur._local) {
        await automacoesService.update(cur.id, {nodes, passos:nodes.length});
      }
    } catch {}
    setList(prev => prev.map((a,i)=>i===selIdx?{...a,nodes,passos:nodes.length}:a));
    setIsDirty(false);
    notify('💾 Automação salva com sucesso!');
  }

  async function toggleStatus(i) {
    const a = list[i];
    const nextStatus = a.status==='ACTIVE'?'PAUSED':'ACTIVE';
    try { if (a.id&&!a._local) await automacoesService.toggle(a.id); } catch {}
    setList(prev=>prev.map((x,idx)=>idx===i?{...x,status:nextStatus}:x));
    notify(nextStatus==='ACTIVE' ? `▶ "${a.nome}" ativada` : `⏸ "${a.nome}" pausada`);
  }

  async function duplicateAuto(i) {
    const copy = {...JSON.parse(JSON.stringify(list[i])), nome:`${list[i].nome} (cópia)`, status:'DRAFT', execucoes:0, _local:true};
    setList(prev=>[...prev,copy]);
    notify(`📋 "${list[i].nome}" duplicada!`);
  }

  async function deleteAuto(i) {
    if (!window.confirm(`Excluir "${list[i].nome}"?`)) return;
    try { if (list[i].id&&!list[i]._local) await automacoesService.delete(list[i].id); } catch {}
    setList(prev=>prev.filter((_,idx)=>idx!==i));
    if (selIdx===i) { setSelIdx(null); setNodes([]); setSelNode(null); }
    notify('🗑 Automação excluída');
  }

  async function testRun() {
    setModal('test');
    setTestLog(null);
    await new Promise(r=>setTimeout(r,1400));
    const cur = list[selIdx];
    try {
      if (cur?.id&&!cur._local) {
        const res = await automacoesService.execute(cur.id,{});
        setTestLog(res?.data || buildLog(nodes));
        return;
      }
    } catch {}
    setTestLog(buildLog(nodes));
  }

  function buildLog(ns) {
    return {
      executedAt: new Date().toISOString(),
      success: true,
      log: ns.map(n => {
        const c=n.config||{};
        const out = n.type==='trigger'?{triggered:true}
          :n.type==='delay'?{waited:`${c.value||0} ${UNIT_LABELS[c.unit]||'min'}`}
          :n.type==='send_message'?{sent:true,preview:(c.content||'').slice(0,60)}
          :n.type==='condition'?{field:c.field,result:'true'}
          :n.type==='ai_response'?{reply:'[Resposta simulada da IA]',model:c.model}
          :n.type==='webhook'?{statusCode:200,url:c.url}
          :n.type==='end'?{finished:true}:{};
        return {nodeId:n.id,type:n.type,label:n.label,status:'success',duration:Math.floor(Math.random()*90)+10,output:out};
      }),
    };
  }

  function createNew() {
    if (!newName.trim()) return;
    const trigLabel = TRIGGER_OPTIONS.find(o=>o.value===newTrig)?.label.replace(/^.{2} /,'') || newTrig;
    const novo = {
      nome:newName.trim(), status:'DRAFT', trigger:trigLabel,
      execucoes:0, passos:3, _local:true,
      nodes:[
        {id:'n1',type:'trigger',label:trigLabel,config:{triggerType:newTrig},x:180,y:30,next:['n2']},
        {id:'n2',type:'send_message',label:'Enviar mensagem',config:{content:''},x:180,y:170,next:['n3']},
        {id:'n3',type:'end',label:'Fim do fluxo',config:{},x:180,y:310,next:[]},
      ],
    };
    setList(prev=>[...prev,novo]);
    setModal(null);
    setNewName('');
    setTimeout(()=>openAuto(list.length),60);
    notify('✅ Automação criada — configure os nós no editor');
  }

  function useTemplate(tpl) {
    const novo = {nome:tpl.name,status:'DRAFT',trigger:tpl.trigger,execucoes:0,passos:tpl.nodes.length,_local:true,nodes:JSON.parse(JSON.stringify(tpl.nodes))};
    const next = [...list,novo];
    setList(next);
    setModal(null);
    setTimeout(()=>openAuto(next.length-1),60);
    notify(`📚 Template "${tpl.name}" carregado!`);
  }

  const activeCount = list.filter(a=>a.status==='ACTIVE').length;
  const pausedCount = list.filter(a=>a.status==='PAUSED').length;
  const totalExec   = list.reduce((s,a)=>s+(a.execucoes||0),0);
  const curAuto     = selIdx!==null ? list[selIdx] : null;

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',overflow:'hidden'}}>

      {/* HEADER */}
      <div style={{padding:'14px 24px',background:'var(--card)',borderBottom:'1px solid var(--border)',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div>
          <div style={{fontSize:15,fontWeight:900,letterSpacing:-.3}}>⚡ Motor de Automações</div>
          <div style={{fontSize:11.5,color:'var(--muted)',marginTop:2}}>Crie fluxos inteligentes sem escrever código</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button style={S.btnGhost} onClick={()=>setModal('templates')}>📚 Templates</button>
          <button style={S.btnPrimary} onClick={()=>setModal('new')}>+ Nova Automação</button>
        </div>
      </div>

      {/* STATS BAR */}
      <div style={{display:'flex',borderBottom:'1px solid var(--border)',flexShrink:0,background:'var(--bg2)'}}>
        {[
          {n:activeCount,               label:'Ativas',         color:'#34d399'},
          {n:pausedCount,               label:'Pausadas',       color:'#fbbf24'},
          {n:totalExec.toLocaleString('pt-BR'),label:'Execuções',color:'#b89ef8'},
          {n:'99.1%',                   label:'Taxa de sucesso',color:'#34d399'},
        ].map((s,i)=>(
          <div key={i} style={{flex:1,padding:'10px 16px',borderRight:i<3?'1px solid var(--border)':'none',textAlign:'center'}}>
            <div style={{fontSize:19,fontWeight:900,color:s.color}}>{s.n}</div>
            <div style={{fontSize:10.5,color:'var(--muted)',marginTop:1}}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* BODY */}
      <div style={{display:'flex',flex:1,overflow:'hidden'}}>

        {/* LISTA LATERAL */}
        <div style={{width:272,flexShrink:0,borderRight:'1px solid var(--border)',overflowY:'auto',background:'var(--bg)'}}>
          <div style={{padding:'7px 12px',fontSize:9.5,fontWeight:800,color:'var(--muted)',textTransform:'uppercase',letterSpacing:1,borderBottom:'1px solid var(--border)'}}>
            Suas Automações · {list.length}
          </div>
          {loading && <div style={{padding:20,textAlign:'center',color:'var(--muted)',fontSize:12}}>Carregando…</div>}
          {list.map((a,i)=>{
            const sc=STATUS_CONF[a.status]||STATUS_CONF.DRAFT;
            const isSel=selIdx===i;
            return (
              <div key={i} onClick={()=>openAuto(i)}
                style={{padding:'11px 14px',borderBottom:'1px solid var(--border)',cursor:'pointer',background:isSel?'var(--accentBg)':'transparent',borderLeft:`2.5px solid ${isSel?'var(--accent2)':'transparent'}`,transition:'background .1s'}}
                onMouseOver={e=>{if(!isSel)e.currentTarget.style.background='var(--card2)';}}
                onMouseOut={e=>{if(!isSel)e.currentTarget.style.background='transparent';}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:4}}>
                  <div style={{fontWeight:700,fontSize:12.5,flex:1,paddingRight:6,lineHeight:1.3}}>{a.nome}</div>
                  <div style={{display:'flex',alignItems:'center',gap:4,flexShrink:0}}>
                    <span style={{width:6,height:6,borderRadius:'50%',background:sc.dot,display:'inline-block',boxShadow:`0 0 6px ${sc.dot}`}}/>
                    <span style={{fontSize:9,color:sc.dot,fontWeight:800}}>{sc.label}</span>
                  </div>
                </div>
                <div style={{fontSize:10.5,color:'var(--muted)',marginBottom:8}}>{a.trigger}</div>
                <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
                  <span style={{fontSize:10,color:'var(--muted2)'}}>⚡ {(a.execucoes||0).toLocaleString()} · {a.passos||0} nós</span>
                  <div style={{display:'flex',gap:4}}>
                    <button onClick={e=>{e.stopPropagation();duplicateAuto(i);}} title="Duplicar" style={S.iconBtn}>📋</button>
                    <button onClick={e=>{e.stopPropagation();deleteAuto(i);}} title="Excluir" style={{...S.iconBtn,color:'var(--red)'}}>🗑</button>
                    <button onClick={e=>{e.stopPropagation();toggleStatus(i);}}
                      style={{padding:'3px 9px',borderRadius:20,border:`1px solid ${sc.dot}`,fontSize:10,fontWeight:700,cursor:'pointer',background:'transparent',color:sc.dot,fontFamily:'inherit'}}
                      onMouseOver={e=>e.currentTarget.style.background=sc.dot+'22'}
                      onMouseOut={e=>e.currentTarget.style.background='transparent'}>
                      {sc.btn}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
          {!loading&&list.length===0&&(
            <div style={{padding:'24px 16px',textAlign:'center',color:'var(--muted)',fontSize:12,lineHeight:1.7}}>
              Nenhuma automação ainda.<br/>
              <button style={{...S.btnPrimary,marginTop:12}} onClick={()=>setModal('new')}>+ Criar primeira</button>
            </div>
          )}
        </div>

        {/* CANVAS / EDITOR */}
        {curAuto ? (
          <FlowEditor
            automation={curAuto}
            nodes={nodes}
            selNode={selNode}
            isDirty={isDirty}
            onSelectNode={setSelNode}
            onAddNode={addNode}
            onUpdatePos={updatePos}
            onUpdateCfg={updateCfg}
            onUpdateLabel={updateLabel}
            onDeleteNode={deleteNode}
            onAddEdge={addEdge}
            onSave={save}
            onTest={testRun}
            onToggle={()=>toggleStatus(selIdx)}
          />
        ):(
          <EmptyCanvas onNew={()=>setModal('new')} onTemplates={()=>setModal('templates')} />
        )}
      </div>

      {/* MODAL: Nova Automação */}
      {modal==='new'&&(
        <Modal title="⚡ Nova Automação" onClose={()=>setModal(null)}>
          <div style={{padding:'0 24px 24px'}}>
            <div style={{marginBottom:14}}>
              <label style={S.label}>Nome da automação</label>
              <input style={S.input} placeholder="Ex: Boas-vindas WhatsApp" value={newName}
                onChange={e=>setNewName(e.target.value)} autoFocus
                onKeyDown={e=>e.key==='Enter'&&createNew()} />
            </div>
            <div style={{marginBottom:20}}>
              <label style={S.label}>Evento disparador</label>
              <select style={S.input} value={newTrig} onChange={e=>setNewTrig(e.target.value)}>
                {TRIGGER_OPTIONS.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
            </div>
            <div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
              <button style={S.btnGhost} onClick={()=>setModal(null)}>Cancelar</button>
              <button style={S.btnPrimary} onClick={createNew}>Criar e Abrir Editor →</button>
            </div>
          </div>
        </Modal>
      )}

      {/* MODAL: Templates */}
      {modal==='templates'&&(
        <Modal title="📚 Templates de Automação" onClose={()=>setModal(null)} wide>
          <div style={{padding:'0 24px 24px',display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12}}>
            {TEMPLATES.map(tpl=>(
              <div key={tpl.id} onClick={()=>useTemplate(tpl)}
                style={{padding:'16px 14px',borderRadius:12,border:'1.5px solid var(--border)',cursor:'pointer',transition:'all .15s'}}
                onMouseOver={e=>{e.currentTarget.style.borderColor='var(--accent2)';e.currentTarget.style.background='var(--accentBg)';}}
                onMouseOut={e=>{e.currentTarget.style.borderColor='var(--border)';e.currentTarget.style.background='transparent';}}>
                <div style={{fontSize:28,marginBottom:8}}>{tpl.icon}</div>
                <div style={{fontSize:12.5,fontWeight:800,marginBottom:4}}>{tpl.name}</div>
                <div style={{fontSize:10.5,color:'var(--muted)',marginBottom:10,lineHeight:1.5}}>{tpl.desc}</div>
                <span style={{fontSize:9.5,fontWeight:700,padding:'3px 9px',borderRadius:20,background:'rgba(124,92,191,.15)',color:'var(--accent3)',border:'1px solid rgba(124,92,191,.3)'}}>{tpl.cat}</span>
                <div style={{marginTop:8,fontSize:10,color:'var(--muted2)'}}>📌 {tpl.nodes.length} nós</div>
              </div>
            ))}
          </div>
        </Modal>
      )}

      {/* MODAL: Resultado do Teste */}
      {modal==='test'&&(
        <Modal title="▶ Resultado do Teste" onClose={()=>setModal(null)}>
          <div style={{padding:'0 24px 24px'}}>
            {!testLog?(
              <div style={{padding:'36px 0',textAlign:'center',color:'var(--muted)'}}>
                <div style={{fontSize:36,marginBottom:14}}>⏳</div>
                <div style={{fontSize:13,fontWeight:600}}>Executando automação com dados de teste…</div>
                <div style={{fontSize:11,color:'var(--muted)',marginTop:6}}>Payload: nome, empresa, telefone</div>
              </div>
            ):(
              <>
                <div style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',borderRadius:10,background:testLog.success?'#34d39915':'#f8717115',border:`1px solid ${testLog.success?'#34d39940':'#f8717140'}`,marginBottom:16}}>
                  <span style={{fontSize:20}}>{testLog.success?'✅':'❌'}</span>
                  <div>
                    <div style={{fontWeight:700,fontSize:13,color:testLog.success?'var(--green)':'var(--red)'}}>
                      {testLog.success?'Todos os nós executados com sucesso!':'Erro durante a execução'}
                    </div>
                    <div style={{fontSize:10.5,color:'var(--muted)'}}>{new Date(testLog.executedAt).toLocaleString('pt-BR')}</div>
                  </div>
                </div>
                {testLog.log?.map((step,i)=>(
                  <div key={i} style={{display:'flex',gap:12,padding:'10px 12px',borderRadius:8,marginBottom:8,background:'var(--card2)',border:'1px solid var(--border)'}}>
                    <div style={{flexShrink:0,width:30,height:30,borderRadius:'50%',background:'#34d39920',display:'flex',alignItems:'center',justifyContent:'center',fontSize:15}}>
                      {NODE_TYPES[step.type]?.icon||'●'}
                    </div>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}>
                        <div style={{fontWeight:700,fontSize:12}}>{step.label}</div>
                        <div style={{display:'flex',gap:8,alignItems:'center'}}>
                          <span style={{fontSize:10,color:'var(--muted)'}}>{step.duration}ms</span>
                          <span style={{fontSize:10,fontWeight:700,color:'var(--green)'}}>✓ OK</span>
                        </div>
                      </div>
                      <div style={{fontSize:10.5,color:'var(--muted2)',fontFamily:'monospace',wordBreak:'break-all'}}>
                        {JSON.stringify(step.output)}
                      </div>
                    </div>
                  </div>
                ))}
              </>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}

// ─── FlowEditor ───────────────────────────────────────────────────────────────
function FlowEditor({automation,nodes,selNode,isDirty,onSelectNode,onAddNode,onUpdatePos,onUpdateCfg,onUpdateLabel,onDeleteNode,onAddEdge,onSave,onTest,onToggle}) {
  const canvasRef = useRef(null);
  const dragRef   = useRef(null);
  const connectRef= useRef(null);
  const [showPicker,setShowPicker]=useState(false);
  const [, forceUpdate] = useState(0);
  const sc = STATUS_CONF[automation.status]||STATUS_CONF.DRAFT;

  // atualiza edges após render
  useEffect(()=>{ forceUpdate(n=>n+1); },[nodes]);

  function startDrag(e,nodeId) {
    if(e.button!==0) return;
    e.preventDefault(); e.stopPropagation();
    const node=nodes.find(n=>n.id===nodeId);
    if(!node) return;
    dragRef.current={nodeId,startX:e.clientX,startY:e.clientY,origX:node.x,origY:node.y};
    const onMove=ev=>{
      if(!dragRef.current) return;
      const dx=ev.clientX-dragRef.current.startX, dy=ev.clientY-dragRef.current.startY;
      onUpdatePos(nodeId,Math.max(0,dragRef.current.origX+dx),Math.max(0,dragRef.current.origY+dy));
    };
    const onUp=()=>{ dragRef.current=null; window.removeEventListener('mousemove',onMove); window.removeEventListener('mouseup',onUp); };
    window.addEventListener('mousemove',onMove);
    window.addEventListener('mouseup',onUp);
  }

  function onDrop(e) {
    e.preventDefault();
    const type=e.dataTransfer.getData('nodeType');
    if(!type) return;
    const rect=canvasRef.current.getBoundingClientRect();
    const x=e.clientX-rect.left+canvasRef.current.scrollLeft-90;
    const y=e.clientY-rect.top+canvasRef.current.scrollTop-30;
    onAddNode(type,Math.max(10,x),Math.max(10,y));
    setShowPicker(false);
  }

  function startConnect(e,nodeId,branch) {
    e.stopPropagation();
    if(connectRef.current) {
      if(connectRef.current.fromId!==nodeId) onAddEdge(connectRef.current.fromId,nodeId,connectRef.current.branch);
      connectRef.current=null;
      return;
    }
    connectRef.current={fromId:nodeId,branch};
    const msg = branch==='true'?'Clique no nó de destino para a saída ✓ Sim':branch==='false'?'Clique no nó de destino para a saída ✗ Não':'Clique no nó de destino para conectar';
    alert(msg);
  }

  // Calcular edges SVG
  function renderEdges() {
    const edges=[];
    nodes.forEach(node=>{
      const el=document.getElementById('fn-'+node.id);
      if(!el) return;
      const fx=(node.x||0)+90, fy=(node.y||0)+el.offsetHeight+2;
      const draw=(toId,color)=>{
        const toNode=nodes.find(n=>n.id===toId);
        const toEl=document.getElementById('fn-'+toId);
        if(!toNode||!toEl) return;
        const tx=(toNode.x||0)+90, ty=(toNode.y||0)-2;
        const midY=(fy+ty)/2;
        edges.push(<path key={node.id+'-'+toId+'-'+color} d={`M${fx},${fy} C${fx},${midY} ${tx},${midY} ${tx},${ty}`} stroke={color} strokeWidth="2" fill="none" opacity=".8" markerEnd="url(#arrowhead)"/>);
      };
      (node.next||[]).forEach(id=>draw(id,'#6b619088'));
      if(node.nextTrue)  draw(node.nextTrue,'#34d399');
      if(node.nextFalse) draw(node.nextFalse,'#f87171');
    });
    return edges;
  }

  const selectedNode=nodes.find(n=>n.id===selNode);

  return (
    <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>

      {/* Toolbar */}
      <div style={{padding:'8px 14px',background:'var(--card)',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',gap:8,flexShrink:0,minHeight:46}}>
        <div style={{fontWeight:800,fontSize:13,flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{automation.nome}</div>
        {isDirty&&<span style={{fontSize:10,color:'var(--yellow)',fontWeight:700,flexShrink:0}}>● não salvo</span>}
        <span style={{display:'flex',alignItems:'center',gap:5,fontSize:11,flexShrink:0}}>
          <span style={{width:7,height:7,borderRadius:'50%',background:sc.dot,display:'inline-block'}}/>
          <span style={{color:sc.dot,fontWeight:700}}>{sc.label}</span>
        </span>
        <div style={{width:1,height:18,background:'var(--border)'}}/>
        <button style={S.iconBtnSm} onClick={()=>setShowPicker(p=>!p)}>+ Nó</button>
        <button style={S.iconBtnSm} onClick={onTest}>▶ Testar</button>
        <button style={S.iconBtnSm} onClick={onToggle}>{automation.status==='ACTIVE'?'⏸ Pausar':'▶ Ativar'}</button>
        <button style={S.btnPrimary} onClick={onSave}>💾 Salvar</button>
      </div>

      {/* Picker de nós flutuante */}
      {showPicker&&(
        <div style={{position:'absolute',top:145,left:290,zIndex:60,background:'var(--card)',border:'1.5px solid var(--border2)',borderRadius:14,padding:14,boxShadow:'0 12px 40px rgba(0,0,0,.5)',display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,width:340}}>
          <div style={{gridColumn:'1/-1',fontSize:10,fontWeight:800,color:'var(--muted)',textTransform:'uppercase',letterSpacing:.8,marginBottom:4}}>Tipo de nó</div>
          {Object.entries(NODE_TYPES).filter(([k])=>k!=='trigger').map(([type,conf])=>(
            <div key={type} onClick={()=>{onAddNode(type);setShowPicker(false);}}
              style={{padding:'9px 10px',borderRadius:9,border:'1.5px solid var(--border)',cursor:'pointer',display:'flex',alignItems:'center',gap:8,transition:'all .12s'}}
              onMouseOver={e=>{e.currentTarget.style.borderColor=conf.color;e.currentTarget.style.background=conf.bg;}}
              onMouseOut={e=>{e.currentTarget.style.borderColor='var(--border)';e.currentTarget.style.background='transparent';}}>
              <span style={{fontSize:18}}>{conf.icon}</span>
              <span style={{fontSize:11.5,fontWeight:600}}>{conf.label}</span>
            </div>
          ))}
          <button onClick={()=>setShowPicker(false)} style={{...S.btnGhost,gridColumn:'1/-1',justifyContent:'center'}}>Fechar</button>
        </div>
      )}

      {/* Área do editor */}
      <div style={{flex:1,display:'flex',overflow:'hidden'}}>

        {/* Paleta lateral */}
        <div style={{width:152,flexShrink:0,background:'var(--card)',borderRight:'1px solid var(--border)',overflowY:'auto',padding:'10px 8px'}}>
          <div style={{fontSize:9.5,fontWeight:800,color:'var(--muted)',textTransform:'uppercase',letterSpacing:.6,marginBottom:8}}>Arrastar p/ canvas</div>
          {Object.entries(NODE_TYPES).filter(([k])=>k!=='trigger').map(([type,conf])=>(
            <div key={type} draggable onDragStart={e=>e.dataTransfer.setData('nodeType',type)}
              style={{display:'flex',alignItems:'center',gap:7,padding:'7px 8px',borderRadius:8,marginBottom:5,border:'1.5px solid var(--border)',background:'var(--card2)',cursor:'grab',fontSize:11,transition:'all .12s'}}
              onMouseOver={e=>{e.currentTarget.style.borderColor=conf.color;e.currentTarget.style.background=conf.bg;}}
              onMouseOut={e=>{e.currentTarget.style.borderColor='var(--border)';e.currentTarget.style.background='var(--card2)';}}>
              <span style={{fontSize:15}}>{conf.icon}</span>
              <span style={{lineHeight:1.3}}>{conf.label}</span>
            </div>
          ))}
        </div>

        {/* Canvas */}
        <div ref={canvasRef} id="flow-canvas"
          onDragOver={e=>e.preventDefault()}
          onDrop={onDrop}
          onClick={e=>{if(e.target===canvasRef.current||e.target.id==='nodes-layer'){onSelectNode(null);setShowPicker(false);}}}
          style={{flex:1,overflow:'auto',position:'relative',backgroundImage:'radial-gradient(circle,var(--border2) 1px,transparent 1px)',backgroundSize:'20px 20px',cursor:'default'}}>
          <svg style={{position:'absolute',top:0,left:0,width:'100%',height:'100%',pointerEvents:'none',overflow:'visible',zIndex:1}}>
            <defs>
              <marker id="arrowhead" markerWidth="9" markerHeight="9" refX="7" refY="3" orient="auto">
                <path d="M0,0 L0,6 L9,3 z" fill="var(--muted2)"/>
              </marker>
            </defs>
            {renderEdges()}
          </svg>
          <div id="nodes-layer" style={{position:'relative',minWidth:900,minHeight:800,zIndex:2}}>
            {nodes.map(node=>(
              <FlowNode key={node.id} node={node} isSelected={selNode===node.id}
                onMouseDown={e=>startDrag(e,node.id)}
                onClick={e=>{e.stopPropagation();onSelectNode(node.id);}}
                onConnect={startConnect}/>
            ))}
          </div>
        </div>

        {/* Config panel */}
        {selectedNode&&(
          <ConfigPanel node={selectedNode} onUpdateCfg={onUpdateCfg} onUpdateLabel={onUpdateLabel}
            onDelete={()=>onDeleteNode(selectedNode.id)} onClose={()=>onSelectNode(null)}/>
        )}
      </div>
    </div>
  );
}

// ─── Nó do fluxo ─────────────────────────────────────────────────────────────
function FlowNode({node,isSelected,onMouseDown,onClick,onConnect}) {
  const conf=NODE_TYPES[node.type]||NODE_TYPES.end;
  function preview() {
    const c=node.config||{};
    switch(node.type){
      case 'trigger':      return TRIGGER_OPTIONS.find(o=>o.value===c.triggerType)?.label.replace(/^.{2} /,'')||'Configure o gatilho';
      case 'send_message': return c.content?c.content.replace(/\n/g,' ').slice(0,48)+(c.content.length>48?'…':''):'Escreva a mensagem…';
      case 'delay':        return c.value?`Aguardar ${c.value} ${UNIT_LABELS[c.unit]||c.unit}`:'Configure o tempo';
      case 'condition':    return c.field?`Se ${c.field} ${c.operator||''} "${c.value||''}"`:'Configure a condição';
      case 'tag_lead':     return c.tags?.length?`${c.action==='remove'?'−':'+'}  ${c.tags.join(', ')}`:'Selecione as tags';
      case 'assign_agent': return ({round_robin:'Round Robin',least_busy:'Menos ocupado',specific:c.agentName||'Específico',ai:'IA decide'})[c.strategy]||'Configure a estratégia';
      case 'update_lead':  return c.field?`${c.field} → ${c.value||'…'}`:'Configure a atualização';
      case 'ai_response':  return c.model?`${c.model} → {{${c.saveAs||'aiReply'}}}`:'Configure o modelo';
      case 'webhook':      return c.url?c.url.replace('https://','').slice(0,40):'Configure a URL';
      case 'end':          return 'Fim do fluxo';
      default:             return '';
    }
  }
  return (
    <div id={'fn-'+node.id} onMouseDown={onMouseDown} onClick={onClick}
      style={{position:'absolute',left:node.x||0,top:node.y||0,width:180,borderRadius:12,border:`2px solid ${isSelected?conf.color:'var(--border)'}`,background:'var(--card)',boxShadow:isSelected?`0 0 0 3px ${conf.color}20,0 4px 20px rgba(0,0,0,.3)`:'0 2px 12px rgba(0,0,0,.2)',cursor:'grab',userSelect:'none',transition:'border-color .15s,box-shadow .15s'}}>
      <div style={{padding:'8px 10px',display:'flex',alignItems:'center',gap:7,borderBottom:'1px solid var(--border)',borderRadius:'10px 10px 0 0',background:conf.bg}}>
        <span style={{fontSize:17,flexShrink:0}}>{conf.icon}</span>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:9.5,fontWeight:800,color:conf.color,textTransform:'uppercase',letterSpacing:.5}}>{conf.label}</div>
          <div style={{fontSize:11,color:'var(--text)',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',marginTop:1}}>{node.label}</div>
        </div>
      </div>
      <div style={{padding:'6px 10px 10px',fontSize:10.5,color:'var(--muted2)',lineHeight:1.4,minHeight:26}}>{preview()}</div>
      {node.type==='condition'&&(
        <div style={{display:'flex',borderTop:'1px solid var(--border)'}}>
          <div onClick={e=>onConnect(e,node.id,'true')} style={{flex:1,padding:'5px 0',textAlign:'center',fontSize:9.5,fontWeight:800,color:'#34d399',borderRight:'1px solid var(--border)',cursor:'pointer'}} title="Conectar saída Sim">✓ Sim</div>
          <div onClick={e=>onConnect(e,node.id,'false')} style={{flex:1,padding:'5px 0',textAlign:'center',fontSize:9.5,fontWeight:800,color:'#f87171',cursor:'pointer'}} title="Conectar saída Não">✗ Não</div>
        </div>
      )}
      {node.type!=='end'&&node.type!=='condition'&&(
        <div onClick={e=>onConnect(e,node.id,null)} title="Clique para conectar"
          style={{position:'absolute',bottom:-8,left:'50%',transform:'translateX(-50%)',width:16,height:16,background:'var(--card)',border:`2px solid ${conf.color}`,borderRadius:'50%',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',fontSize:9,color:conf.color,zIndex:10}}>+</div>
      )}
    </div>
  );
}

// ─── Painel de configuração ───────────────────────────────────────────────────
function ConfigPanel({node,onUpdateCfg,onUpdateLabel,onDelete,onClose}) {
  const conf=NODE_TYPES[node.type]||NODE_TYPES.end;
  const c=node.config||{};
  return (
    <div style={{width:280,flexShrink:0,background:'var(--card)',borderLeft:'1px solid var(--border)',overflowY:'auto',display:'flex',flexDirection:'column'}}>
      <div style={{padding:'13px 16px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',gap:8,flexShrink:0,background:conf.bg}}>
        <span style={{fontSize:20}}>{conf.icon}</span>
        <div style={{flex:1}}>
          <div style={{fontSize:12,fontWeight:800,color:conf.color}}>{conf.label}</div>
          <div style={{fontSize:9.5,color:'var(--muted)'}}>ID: {node.id}</div>
        </div>
        <button onClick={onDelete} style={{...S.iconBtn,color:'var(--red)'}} title="Excluir nó">🗑</button>
        <button onClick={onClose} style={S.iconBtn}>✕</button>
      </div>
      <div style={{padding:'14px 16px',flex:1}}>
        <div style={{marginBottom:12}}>
          <label style={S.label}>Rótulo do nó</label>
          <input style={S.input} value={node.label} onChange={e=>onUpdateLabel(node.id,e.target.value)}/>
        </div>

        {node.type==='trigger'&&<>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Evento disparador</label>
            <select style={S.input} value={c.triggerType||''} onChange={e=>onUpdateCfg(node.id,'triggerType',e.target.value)}>
              {TRIGGER_OPTIONS.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Canal (opcional)</label>
            <select style={S.input} value={c.channel||'all'} onChange={e=>onUpdateCfg(node.id,'channel',e.target.value)}>
              <option value="all">Todos</option>
              <option value="whatsapp">WhatsApp</option>
              <option value="instagram">Instagram</option>
              <option value="chat">Webchat</option>
              <option value="email">E-mail</option>
            </select>
          </div>
        </>}

        {node.type==='send_message'&&<>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Canal de envio</label>
            <select style={S.input} value={c.channel||'whatsapp'} onChange={e=>onUpdateCfg(node.id,'channel',e.target.value)}>
              <option value="whatsapp">WhatsApp</option>
              <option value="instagram">Instagram</option>
              <option value="chat">Webchat</option>
            </select>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Tipo de mensagem</label>
            <select style={S.input} value={c.msgType||'text'} onChange={e=>onUpdateCfg(node.id,'msgType',e.target.value)}>
              <option value="text">Texto livre</option>
              <option value="template">Template aprovado</option>
              <option value="image">Imagem</option>
              <option value="audio">Áudio</option>
            </select>
          </div>
          <div style={{marginBottom:8}}>
            <label style={S.label}>Mensagem</label>
            <textarea style={{...S.input,resize:'vertical',minHeight:100,lineHeight:1.5}}
              placeholder={'Olá {{nome}}! 👋\n\nEm que posso te ajudar?'}
              value={c.content||''} onChange={e=>onUpdateCfg(node.id,'content',e.target.value)}/>
          </div>
          <div style={{fontSize:10,color:'var(--muted2)',padding:'7px 9px',background:'var(--card2)',borderRadius:7,lineHeight:1.7}}>
            💡 Variáveis disponíveis:<br/>
            <code style={{color:'var(--accent3)',fontSize:9.5}}>{'{{nome}} {{empresa}} {{telefone}} {{canal}} {{valor}}'}</code>
          </div>
        </>}

        {node.type==='delay'&&(
          <div style={{display:'flex',gap:10}}>
            <div style={{flex:1}}>
              <label style={S.label}>Valor</label>
              <input style={S.input} type="number" min="1" value={c.value||5} onChange={e=>onUpdateCfg(node.id,'value',+e.target.value)}/>
            </div>
            <div style={{flex:1}}>
              <label style={S.label}>Unidade</label>
              <select style={S.input} value={c.unit||'minutes'} onChange={e=>onUpdateCfg(node.id,'unit',e.target.value)}>
                <option value="seconds">Segundos</option>
                <option value="minutes">Minutos</option>
                <option value="hours">Horas</option>
                <option value="days">Dias</option>
              </select>
            </div>
          </div>
        )}

        {node.type==='condition'&&<>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Campo a verificar</label>
            <select style={S.input} value={c.field||''} onChange={e=>onUpdateCfg(node.id,'field',e.target.value)}>
              <option value="">Selecione…</option>
              <option value="content">Conteúdo da mensagem</option>
              <option value="canal">Canal de origem</option>
              <option value="status">Status do lead</option>
              <option value="valor">Valor do lead (R$)</option>
              <option value="tag">Tags do lead</option>
              <option value="replied">Respondeu à mensagem</option>
              <option value="aiScore">Score da IA</option>
              <option value="aiReply">Resposta da IA</option>
            </select>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Operador</label>
            <select style={S.input} value={c.operator||'eq'} onChange={e=>onUpdateCfg(node.id,'operator',e.target.value)}>
              <option value="eq">É igual a</option>
              <option value="neq">Não é igual a</option>
              <option value="contains">Contém</option>
              <option value="not_contains">Não contém</option>
              <option value="gt">Maior que</option>
              <option value="lt">Menor que</option>
              <option value="is_empty">Está vazio</option>
              <option value="not_empty">Não está vazio</option>
            </select>
          </div>
          {!['is_empty','not_empty'].includes(c.operator)&&(
            <div style={{marginBottom:10}}>
              <label style={S.label}>Valor de comparação</label>
              <input style={S.input} placeholder="Ex: HOT, GANHO, whatsapp…" value={c.value||''} onChange={e=>onUpdateCfg(node.id,'value',e.target.value)}/>
            </div>
          )}
          <div style={{fontSize:10.5,color:'var(--muted2)',padding:'8px 10px',background:'var(--card2)',borderRadius:7,lineHeight:1.5}}>
            🔀 Clique em <b>✓ Sim</b> ou <b>✗ Não</b> no nó do canvas para conectar cada saída.
          </div>
        </>}

        {node.type==='tag_lead'&&<>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Tags (separadas por vírgula)</label>
            <input style={S.input} placeholder="lead-quente, proposta-enviada"
              value={(c.tags||[]).join(', ')}
              onChange={e=>onUpdateCfg(node.id,'tags',e.target.value.split(',').map(t=>t.trim()).filter(Boolean))}/>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Ação</label>
            <select style={S.input} value={c.action||'add'} onChange={e=>onUpdateCfg(node.id,'action',e.target.value)}>
              <option value="add">Adicionar tag</option>
              <option value="remove">Remover tag</option>
              <option value="replace">Substituir todas</option>
            </select>
          </div>
        </>}

        {node.type==='assign_agent'&&<>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Estratégia de atribuição</label>
            <select style={S.input} value={c.strategy||'round_robin'} onChange={e=>onUpdateCfg(node.id,'strategy',e.target.value)}>
              <option value="round_robin">Round Robin (alternado)</option>
              <option value="least_busy">Menos ocupado</option>
              <option value="specific">Agente específico</option>
              <option value="ai">IA decide</option>
            </select>
          </div>
          {c.strategy==='specific'&&(
            <div style={{marginBottom:10}}>
              <label style={S.label}>Nome do agente</label>
              <input style={S.input} placeholder="Ana Costa" value={c.agentName||''} onChange={e=>onUpdateCfg(node.id,'agentName',e.target.value)}/>
            </div>
          )}
          <div style={{marginBottom:10}}>
            <label style={S.label}>Equipe (opcional)</label>
            <input style={S.input} placeholder="Vendas, Suporte…" value={c.team||''} onChange={e=>onUpdateCfg(node.id,'team',e.target.value)}/>
          </div>
        </>}

        {node.type==='update_lead'&&<>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Campo a atualizar</label>
            <select style={S.input} value={c.field||''} onChange={e=>onUpdateCfg(node.id,'field',e.target.value)}>
              <option value="">Selecione…</option>
              <option value="status">Status do lead</option>
              <option value="valor">Valor do lead</option>
              <option value="owner">Responsável</option>
              <option value="canal">Canal</option>
            </select>
          </div>
          {c.field==='status'?(
            <div style={{marginBottom:10}}>
              <label style={S.label}>Novo status</label>
              <select style={S.input} value={c.value||''} onChange={e=>onUpdateCfg(node.id,'value',e.target.value)}>
                <option value="NOVO">Novo</option>
                <option value="CONTATADO">Contatado</option>
                <option value="QUALIFICADO">Qualificado</option>
                <option value="PROPOSTA">Proposta</option>
                <option value="NEGOCIACAO">Negociação</option>
                <option value="GANHO">Ganho ✅</option>
                <option value="PERDIDO">Perdido ❌</option>
              </select>
            </div>
          ):(
            <div style={{marginBottom:10}}>
              <label style={S.label}>Novo valor</label>
              <input style={S.input} placeholder="Novo valor" value={c.value||''} onChange={e=>onUpdateCfg(node.id,'value',e.target.value)}/>
            </div>
          )}
        </>}

        {node.type==='ai_response'&&<>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Modelo de IA</label>
            <select style={S.input} value={c.model||'gpt-4o-mini'} onChange={e=>onUpdateCfg(node.id,'model',e.target.value)}>
              <option value="gpt-4o-mini">GPT-4o Mini (rápido)</option>
              <option value="gpt-4o">GPT-4o (mais capaz)</option>
              <option value="claude-3-haiku">Claude 3 Haiku</option>
              <option value="claude-3-sonnet">Claude 3 Sonnet</option>
            </select>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Prompt do sistema</label>
            <textarea style={{...S.input,resize:'vertical',minHeight:90,lineHeight:1.5}}
              placeholder="Você é um assistente de vendas. Responda em português de forma objetiva."
              value={c.systemPrompt||''} onChange={e=>onUpdateCfg(node.id,'systemPrompt',e.target.value)}/>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Salvar resposta em (variável)</label>
            <input style={S.input} placeholder="aiReply" value={c.saveAs||'aiReply'} onChange={e=>onUpdateCfg(node.id,'saveAs',e.target.value)}/>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Temperatura: {c.temperature??0.7}</label>
            <input type="range" min="0" max="1" step="0.1" value={c.temperature??0.7}
              style={{width:'100%',accentColor:'var(--accent)'}}
              onChange={e=>onUpdateCfg(node.id,'temperature',+e.target.value)}/>
            <div style={{display:'flex',justifyContent:'space-between',fontSize:9.5,color:'var(--muted)',marginTop:2}}>
              <span>Preciso</span><span>Criativo</span>
            </div>
          </div>
        </>}

        {node.type==='webhook'&&<>
          <div style={{marginBottom:10}}>
            <label style={S.label}>URL do endpoint</label>
            <input style={S.input} placeholder="https://meu-sistema.com/webhook" value={c.url||''} onChange={e=>onUpdateCfg(node.id,'url',e.target.value)}/>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Método HTTP</label>
            <select style={S.input} value={c.method||'POST'} onChange={e=>onUpdateCfg(node.id,'method',e.target.value)}>
              <option value="POST">POST</option>
              <option value="GET">GET</option>
              <option value="PUT">PUT</option>
              <option value="PATCH">PATCH</option>
            </select>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Headers (JSON)</label>
            <textarea style={{...S.input,resize:'vertical',minHeight:60,fontSize:11,fontFamily:'monospace'}}
              placeholder={'{"Authorization": "Bearer token"}'}
              value={c.headers||''} onChange={e=>onUpdateCfg(node.id,'headers',e.target.value)}/>
          </div>
          <div style={{marginBottom:10}}>
            <label style={S.label}>Payload (JSON)</label>
            <textarea style={{...S.input,resize:'vertical',minHeight:70,fontSize:11,fontFamily:'monospace'}}
              placeholder={'{"nome": "{{nome}}", "canal": "{{canal}}"}'}
              value={c.payload||''} onChange={e=>onUpdateCfg(node.id,'payload',e.target.value)}/>
          </div>
        </>}

        {node.type==='end'&&(
          <div style={{padding:'12px',background:'var(--card2)',borderRadius:9,fontSize:12,color:'var(--muted2)',lineHeight:1.6,textAlign:'center'}}>
            🏁 Fim do fluxo.<br/>Nenhuma configuração necessária.
          </div>
        )}

        <div style={{marginTop:16,paddingTop:12,borderTop:'1px solid var(--border)'}}>
          <div style={{fontSize:10,fontWeight:700,color:'var(--muted)',textTransform:'uppercase',marginBottom:7,letterSpacing:.5}}>Conexões de saída</div>
          {(node.next||[]).length===0&&!node.nextTrue&&!node.nextFalse?(
            <div style={{fontSize:11,color:'var(--muted2)'}}>Nenhuma conexão configurada.</div>
          ):(
            <>
              {(node.next||[]).map(id=><div key={id} style={{fontSize:11,color:'var(--muted2)',marginBottom:3}}>→ {id}</div>)}
              {node.nextTrue&&<div style={{fontSize:11,color:'#34d399'}}>✓ Sim → {node.nextTrue}</div>}
              {node.nextFalse&&<div style={{fontSize:11,color:'#f87171'}}>✗ Não → {node.nextFalse}</div>}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── EmptyCanvas ──────────────────────────────────────────────────────────────
function EmptyCanvas({onNew,onTemplates}) {
  return (
    <div style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',gap:14,color:'var(--muted)',backgroundImage:'radial-gradient(circle,var(--border) 1px,transparent 1px)',backgroundSize:'22px 22px'}}>
      <div style={{fontSize:60,opacity:.2}}>⚡</div>
      <div style={{fontSize:16,fontWeight:900,color:'var(--text)'}}>Selecione ou crie uma automação</div>
      <div style={{fontSize:12.5,color:'var(--muted)',textAlign:'center',maxWidth:360,lineHeight:1.7}}>
        Monte fluxos visuais de atendimento, qualificação e follow-up<br/>sem escrever nenhuma linha de código.
      </div>
      <div style={{display:'flex',gap:10,marginTop:6}}>
        <button style={S.btnPrimary} onClick={onNew}>+ Nova Automação</button>
        <button style={S.btnGhost} onClick={onTemplates}>📚 Ver Templates</button>
      </div>
    </div>
  );
}

// ─── Modal ────────────────────────────────────────────────────────────────────
function Modal({title,children,onClose,wide}) {
  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.65)',backdropFilter:'blur(6px)',zIndex:200,display:'flex',alignItems:'center',justifyContent:'center'}}
      onClick={e=>{if(e.target===e.currentTarget)onClose();}}>
      <div style={{background:'var(--card)',border:'1px solid var(--border2)',borderRadius:16,width:wide?780:460,maxWidth:'96vw',maxHeight:'92vh',overflowY:'auto',boxShadow:'0 28px 70px rgba(0,0,0,.65)'}}>
        <div style={{padding:'18px 24px',display:'flex',alignItems:'center',justifyContent:'space-between',borderBottom:'1px solid var(--border)'}}>
          <div style={{fontSize:15,fontWeight:800}}>{title}</div>
          <button onClick={onClose} style={{background:'var(--card2)',border:'1px solid var(--border)',color:'var(--muted2)',width:30,height:30,borderRadius:8,cursor:'pointer',fontSize:15,display:'flex',alignItems:'center',justifyContent:'center'}}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
