// ═══════════════════════════════════════════════════
// CONTATOS
// ═══════════════════════════════════════════════════
const express = require('express');
const prisma = require('../database/prisma');
const { auth, requireAdmin } = require('../middleware/auth');

// ─── Contatos ─────────────────────────────────────
const contatos = express.Router();
contatos.use(auth);

contatos.get('/', async (req, res) => {
  try {
    const { search, canal } = req.query;
    const where = {};
    if (canal) where.canal = canal;
    if (search) where.OR = [
      { nome:    { contains: search, mode: 'insensitive' } },
      { empresa: { contains: search, mode: 'insensitive' } },
      { email:   { contains: search, mode: 'insensitive' } },
    ];
    const data = await prisma.contato.findMany({ where, orderBy: { createdAt: 'desc' } });
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

contatos.get('/:id', async (req, res) => {
  try {
    const c = await prisma.contato.findUnique({ where: { id: req.params.id }, include: { leads: true, conversations: true } });
    if (!c) return res.status(404).json({ error: 'Contato não encontrado' });
    res.json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

contatos.post('/', async (req, res) => {
  try {
    const { nome, empresa, phone, email, canal = 'WHATSAPP', tags = [] } = req.body;
    if (!nome) return res.status(400).json({ error: 'Nome é obrigatório' });
    const c = await prisma.contato.create({ data: { nome, empresa, phone, email, canal, tags } });
    res.status(201).json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

contatos.put('/:id', async (req, res) => {
  try {
    const { nome, empresa, phone, email, canal, tags } = req.body;
    const c = await prisma.contato.update({
      where: { id: req.params.id },
      data: { ...(nome && { nome }), ...(empresa !== undefined && { empresa }), ...(phone !== undefined && { phone }), ...(email !== undefined && { email }), ...(canal && { canal }), ...(tags && { tags }) },
    });
    res.json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

contatos.delete('/:id', async (req, res) => {
  try {
    await prisma.contato.delete({ where: { id: req.params.id } });
    res.json({ message: 'Contato removido' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Conversas ────────────────────────────────────
const conversations = express.Router();
conversations.use(auth);

conversations.get('/', async (req, res) => {
  try {
    const { status, canal } = req.query;
    const where = {};
    if (status) where.status = status;
    if (canal)  where.canal  = canal;
    const data = await prisma.conversation.findMany({
      where,
      include: {
        agente:   { select: { nome: true } },
        messages: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
      orderBy: { updatedAt: 'desc' },
    });
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

conversations.get('/:id', async (req, res) => {
  try {
    const c = await prisma.conversation.findUnique({
      where: { id: req.params.id },
      include: {
        messages: { include: { agente: { select: { nome: true } } }, orderBy: { createdAt: 'asc' } },
        agente:   { select: { nome: true, email: true } },
        contato:  true,
      },
    });
    if (!c) return res.status(404).json({ error: 'Conversa não encontrada' });
    res.json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

conversations.post('/', async (req, res) => {
  try {
    const { nome, phone, canal = 'WHATSAPP', empresa, email, origem, prioridade = 'MEDIA', contatoId, agenteId } = req.body;
    const c = await prisma.conversation.create({ data: { nome, phone, canal, empresa, email, origem, prioridade, contatoId, agenteId } });
    res.status(201).json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PUT /api/conversations/:id — atualizar conversa (status, agente, tags, notas)
conversations.put('/:id', async (req, res) => {
  try {
    const { status, agenteId, tags, notas, prioridade } = req.body;
    const c = await prisma.conversation.update({
      where: { id: req.params.id },
      data: {
        ...(status     && { status }),
        ...(agenteId   !== undefined && { agenteId }),
        ...(tags       && { tags }),
        ...(notas      !== undefined && { notas }),
        ...(prioridade && { prioridade }),
      },
    });
    res.json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/conversations/:id/messages — enviar mensagem
conversations.post('/:id/messages', async (req, res) => {
  try {
    const { txt, dir = 'OUT' } = req.body;
    if (!txt) return res.status(400).json({ error: 'Texto obrigatório' });

    const hora = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    const msg = await prisma.message.create({
      data: {
        conversationId: req.params.id,
        dir,
        txt,
        hora,
        status: 'SENT',
        agenteId: dir === 'OUT' ? req.user.id : null,
      },
      include: { agente: { select: { nome: true } } },
    });

    // Atualiza última mensagem da conversa
    await prisma.conversation.update({
      where: { id: req.params.id },
      data: { updatedAt: new Date(), unread: dir === 'IN' ? { increment: 1 } : 0 },
    });

    res.status(201).json(msg);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/conversations/:id/resolve
conversations.post('/:id/resolve', async (req, res) => {
  try {
    const c = await prisma.conversation.update({
      where: { id: req.params.id },
      data: { status: 'RESOLVED', unread: 0 },
    });
    res.json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Campanhas ─────────────────────────────────────
const campanhas = express.Router();
campanhas.use(auth);

campanhas.get('/', async (req, res) => {
  try {
    const data = await prisma.campanha.findMany({ orderBy: { createdAt: 'desc' } });
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

campanhas.get('/:id', async (req, res) => {
  try {
    const c = await prisma.campanha.findUnique({ where: { id: req.params.id } });
    if (!c) return res.status(404).json({ error: 'Campanha não encontrada' });
    res.json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

campanhas.post('/', async (req, res) => {
  try {
    const { nome, canal = 'WHATSAPP', segmento, mensagem, template, scheduledAt } = req.body;
    if (!nome) return res.status(400).json({ error: 'Nome é obrigatório' });
    const c = await prisma.campanha.create({ data: { nome, canal, segmento, mensagem, template, scheduledAt: scheduledAt ? new Date(scheduledAt) : null } });
    res.status(201).json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

campanhas.put('/:id', async (req, res) => {
  try {
    const { nome, status, mensagem, scheduledAt, sent, delivered, read, replies, failed } = req.body;
    const c = await prisma.campanha.update({
      where: { id: req.params.id },
      data: {
        ...(nome        && { nome }),
        ...(status      && { status }),
        ...(mensagem    !== undefined && { mensagem }),
        ...(scheduledAt && { scheduledAt: new Date(scheduledAt) }),
        ...(sent        !== undefined && { sent }),
        ...(delivered   !== undefined && { delivered }),
        ...(read        !== undefined && { read }),
        ...(replies     !== undefined && { replies }),
        ...(failed      !== undefined && { failed }),
      },
    });
    res.json(c);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

campanhas.delete('/:id', async (req, res) => {
  try {
    await prisma.campanha.delete({ where: { id: req.params.id } });
    res.json({ message: 'Campanha removida' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Agenda ─────────────────────────────────────────
const agenda = express.Router();
agenda.use(auth);

agenda.get('/', async (req, res) => {
  try {
    const { data } = req.query;
    const where = {};
    if (data) where.data = data;
    const items = await prisma.agendaItem.findMany({
      where,
      include: { user: { select: { nome: true } } },
      orderBy: { hora: 'asc' },
    });
    res.json(items);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

agenda.post('/', async (req, res) => {
  try {
    const { titulo, tipo = 'TAREFA', hora, data, lead, leadId } = req.body;
    if (!titulo || !hora || !data) return res.status(400).json({ error: 'Título, hora e data são obrigatórios' });
    const item = await prisma.agendaItem.create({
      data: { titulo, tipo, hora, data, lead, leadId, userId: req.user.id },
    });
    res.status(201).json(item);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

agenda.put('/:id', async (req, res) => {
  try {
    const { titulo, tipo, hora, data, status, lead } = req.body;
    const item = await prisma.agendaItem.update({
      where: { id: req.params.id },
      data: { ...(titulo && { titulo }), ...(tipo && { tipo }), ...(hora && { hora }), ...(data && { data }), ...(status && { status }), ...(lead !== undefined && { lead }) },
    });
    res.json(item);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

agenda.delete('/:id', async (req, res) => {
  try {
    await prisma.agendaItem.delete({ where: { id: req.params.id } });
    res.json({ message: 'Item removido' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Financeiro ─────────────────────────────────────
const financeiro = express.Router();
financeiro.use(auth);

financeiro.get('/', async (req, res) => {
  try {
    const { tipo } = req.query;
    const where = tipo ? { tipo } : {};
    const data = await prisma.lancamento.findMany({ where, orderBy: { createdAt: 'desc' } });

    const entradas = data.filter(f => f.tipo === 'ENTRADA').reduce((a, f) => a + f.valor, 0);
    const saidas   = data.filter(f => f.tipo === 'SAIDA').reduce((a, f) => a + f.valor, 0);

    res.json({ lancamentos: data, entradas, saidas, saldo: entradas - saidas });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

financeiro.post('/', async (req, res) => {
  try {
    const { desc, tipo, valor, status = 'PENDENTE', cat, data } = req.body;
    if (!desc || !tipo || !valor) return res.status(400).json({ error: 'Desc, tipo e valor são obrigatórios' });
    const l = await prisma.lancamento.create({ data: { desc, tipo, valor: Number(valor), status, cat, data: data || new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) } });
    res.status(201).json(l);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

financeiro.put('/:id', async (req, res) => {
  try {
    const { desc, tipo, valor, status, cat } = req.body;
    const l = await prisma.lancamento.update({
      where: { id: req.params.id },
      data: { ...(desc && { desc }), ...(tipo && { tipo }), ...(valor !== undefined && { valor: Number(valor) }), ...(status && { status }), ...(cat !== undefined && { cat }) },
    });
    res.json(l);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

financeiro.delete('/:id', async (req, res) => {
  try {
    await prisma.lancamento.delete({ where: { id: req.params.id } });
    res.json({ message: 'Lançamento removido' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Usuários ────────────────────────────────────────
const bcrypt = require('bcryptjs');
const usuarios = express.Router();
usuarios.use(auth);

usuarios.get('/', requireAdmin, async (req, res) => {
  try {
    const data = await prisma.user.findMany({ select: { id: true, nome: true, email: true, cargo: true, role: true, status: true, createdAt: true }, orderBy: { createdAt: 'asc' } });
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

usuarios.post('/invite', requireAdmin, async (req, res) => {
  try {
    const { email, role = 'USER', cargo } = req.body;
    if (!email) return res.status(400).json({ error: 'E-mail obrigatório' });

    const exists = await prisma.user.findUnique({ where: { email } });
    if (exists) return res.status(409).json({ error: 'E-mail já cadastrado' });

    const user = await prisma.user.create({
      data: { nome: email.split('@')[0], email, senha: await bcrypt.hash(Math.random().toString(36), 10), role, cargo, status: 'CONVIDADO' },
      select: { id: true, nome: true, email: true, role: true, status: true },
    });
    // Em produção: enviar e-mail de convite aqui
    res.status(201).json(user);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

usuarios.put('/:id', requireAdmin, async (req, res) => {
  try {
    const { nome, cargo, role, status } = req.body;
    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: { ...(nome && { nome }), ...(cargo !== undefined && { cargo }), ...(role && { role }), ...(status && { status }) },
      select: { id: true, nome: true, email: true, cargo: true, role: true, status: true },
    });
    res.json(user);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

usuarios.delete('/:id', requireAdmin, async (req, res) => {
  try {
    if (req.params.id === req.user.id) return res.status(400).json({ error: 'Não é possível remover seu próprio usuário' });
    await prisma.user.delete({ where: { id: req.params.id } });
    res.json({ message: 'Usuário removido' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Billing ─────────────────────────────────────────
const billing = express.Router();
billing.use(auth);

billing.get('/', async (req, res) => {
  try {
    const b = await prisma.billing.findFirst({ include: { invoices: { orderBy: { createdAt: 'desc' } } } });
    res.json(b);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

billing.post('/upgrade', requireAdmin, async (req, res) => {
  try {
    const { planId } = req.body;
    const planMap = {
      starter: { plan: 'Starter', mrr: 197, seatsLimit: 3, msgsLimit: 10000 },
      pro:     { plan: 'Pro',     mrr: 497, seatsLimit: 10, msgsLimit: 30000 },
      enterprise: { plan: 'Enterprise', mrr: 997, seatsLimit: -1, msgsLimit: -1 },
    };
    const planData = planMap[planId];
    if (!planData) return res.status(400).json({ error: 'Plano inválido' });

    const b = await prisma.billing.updateMany({
      data: { ...planData, status: 'Ativo', trialDays: 14 },
    });
    // Em produção: redirecionar para Stripe
    res.json({ message: `Upgrade para ${planData.plan} realizado`, redirectUrl: 'https://billing.stripe.com' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Conexões ─────────────────────────────────────────
const conexoes = express.Router();
conexoes.use(auth);

conexoes.get('/', async (req, res) => {
  try {
    const data = await prisma.conexao.findMany({ orderBy: { createdAt: 'desc' } });
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

conexoes.post('/', requireAdmin, async (req, res) => {
  try {
    const { nome, tipo = 'WHATSAPP', numero, instance } = req.body;
    if (!nome) return res.status(400).json({ error: 'Nome é obrigatório' });
    const c = await prisma.conexao.create({ data: { nome, tipo, numero, instance, status: 'DISCONNECTED' } });
    // Em produção: chamar Evolution API para criar instância
    res.status(201).json({ ...c, qrCode: 'Em produção, QR Code seria retornado aqui' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

conexoes.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await prisma.conexao.delete({ where: { id: req.params.id } });
    res.json({ message: 'Conexão removida' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Automações ───────────────────────────────────────
// ═══════════════════════════════════════════════════
// AUTOMAÇÕES — rotas completas
// ═══════════════════════════════════════════════════
const automacoes = express.Router();
automacoes.use(auth);

// GET / — listar com stats resumidas
automacoes.get('/', async (req, res) => {
  try {
    const { status } = req.query;
    const where = status ? { status } : {};
    const data = await prisma.automacao.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
    });
    // Calcular passos a partir dos nodes
    const enriched = data.map(a => ({
      ...a,
      passos: Array.isArray(a.nodes) ? a.nodes.length : 0,
    }));
    res.json({ ok: true, data: enriched });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /stats — dashboard de automações
automacoes.get('/stats', async (req, res) => {
  try {
    const all = await prisma.automacao.findMany();
    const active  = all.filter(a => a.status === 'ACTIVE').length;
    const paused  = all.filter(a => a.status === 'PAUSED').length;
    const draft   = all.filter(a => a.status === 'DRAFT').length;
    const total   = all.reduce((s, a) => s + (a.execucoes || 0), 0);
    res.json({ ok: true, data: { active, paused, draft, total, successRate: 99.1 } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /:id — buscar com nodes
automacoes.get('/:id', async (req, res) => {
  try {
    const a = await prisma.automacao.findUnique({ where: { id: req.params.id } });
    if (!a) return res.status(404).json({ error: 'Automação não encontrada' });
    res.json({ ok: true, data: { ...a, passos: Array.isArray(a.nodes) ? a.nodes.length : 0 } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST / — criar nova automação
automacoes.post('/', async (req, res) => {
  try {
    const { nome, trigger, nodes = [], status = 'DRAFT' } = req.body;
    if (!nome || !trigger) return res.status(400).json({ error: 'Nome e trigger são obrigatórios' });
    const a = await prisma.automacao.create({
      data: { nome, trigger, nodes, status },
    });
    res.status(201).json({ ok: true, data: { ...a, passos: nodes.length } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PUT /:id — atualizar automação
automacoes.put('/:id', async (req, res) => {
  try {
    const { nome, trigger, status, nodes } = req.body;
    const update = {};
    if (nome    !== undefined) update.nome    = nome;
    if (trigger !== undefined) update.trigger = trigger;
    if (status  !== undefined) update.status  = status;
    if (nodes   !== undefined) update.nodes   = nodes;
    const a = await prisma.automacao.update({
      where: { id: req.params.id },
      data: update,
    });
    res.json({ ok: true, data: { ...a, passos: Array.isArray(a.nodes) ? a.nodes.length : 0 } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH /:id/toggle — ativar/pausar
automacoes.patch('/:id/toggle', async (req, res) => {
  try {
    const current = await prisma.automacao.findUnique({ where: { id: req.params.id } });
    if (!current) return res.status(404).json({ error: 'Automação não encontrada' });
    const next = current.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE';
    const a = await prisma.automacao.update({
      where: { id: req.params.id },
      data: { status: next },
    });
    res.json({ ok: true, data: a, message: next === 'ACTIVE' ? 'Automação ativada' : 'Automação pausada' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /:id/duplicate — duplicar automação
automacoes.post('/:id/duplicate', async (req, res) => {
  try {
    const original = await prisma.automacao.findUnique({ where: { id: req.params.id } });
    if (!original) return res.status(404).json({ error: 'Automação não encontrada' });
    const copy = await prisma.automacao.create({
      data: {
        nome: `${original.nome} (cópia)`,
        trigger: original.trigger,
        nodes: original.nodes,
        status: 'DRAFT',
      },
    });
    res.status(201).json({ ok: true, data: copy });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /:id/execute — executar teste (simula execução)
automacoes.post('/:id/execute', async (req, res) => {
  try {
    const { payload = {} } = req.body;
    const a = await prisma.automacao.findUnique({ where: { id: req.params.id } });
    if (!a) return res.status(404).json({ error: 'Automação não encontrada' });

    const nodes = Array.isArray(a.nodes) ? a.nodes : [];
    const log = [];

    // Simula execução nó a nó
    for (const node of nodes) {
      const start = Date.now();
      let status = 'success', output = null, error = null;

      try {
        switch (node.type) {
          case 'trigger':      output = { triggered: true, payload }; break;
          case 'delay':        output = { waited: `${node.config?.value || 0} ${node.config?.unit || 'min'}` }; break;
          case 'send_message': output = { sent: true, preview: (node.config?.content || '').slice(0, 80) }; break;
          case 'condition':    output = { result: Math.random() > 0.5 ? 'true' : 'false' }; break;
          case 'tag_lead':     output = { tags: node.config?.tags || [], action: node.config?.action }; break;
          case 'assign_agent': output = { assigned: 'Ana Costa', strategy: node.config?.strategy }; break;
          case 'update_lead':  output = { field: node.config?.field, value: node.config?.value }; break;
          case 'ai_response':  output = { reply: 'Olá! Posso te ajudar com isso. [resposta simulada da IA]' }; break;
          case 'webhook':      output = { url: node.config?.url, statusCode: 200 }; break;
          case 'end':          output = { finished: true }; break;
          default:             output = {};
        }
      } catch (err) {
        status = 'error';
        error = err.message;
      }

      log.push({
        nodeId:   node.id,
        type:     node.type,
        label:    node.label,
        status,
        output,
        error,
        duration: Date.now() - start,
      });

      if (node.type === 'end') break;
    }

    // Incrementar contador de execuções
    await prisma.automacao.update({
      where: { id: req.params.id },
      data: { execucoes: { increment: 1 } },
    });

    res.json({ ok: true, data: { executedAt: new Date().toISOString(), log, success: log.every(l => l.status !== 'error') } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// DELETE /:id — excluir
automacoes.delete('/:id', async (req, res) => {
  try {
    await prisma.automacao.delete({ where: { id: req.params.id } });
    res.json({ ok: true, message: 'Automação removida' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Base de Conhecimento / IA ────────────────────────
const kbRouter = express.Router();
kbRouter.use(auth);

kbRouter.get('/', async (req, res) => {
  try {
    const data = await prisma.kbDocument.findMany({ orderBy: { createdAt: 'desc' } });
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

kbRouter.post('/', async (req, res) => {
  try {
    const { titulo, cat, conteudo, tipo = 'text' } = req.body;
    if (!titulo || !conteudo) return res.status(400).json({ error: 'Título e conteúdo são obrigatórios' });
    const palavras = conteudo.split(/\s+/).length;
    const doc = await prisma.kbDocument.create({ data: { titulo, cat, conteudo, tipo, palavras, status: 'indexed' } });
    res.status(201).json(doc);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

kbRouter.delete('/:id', async (req, res) => {
  try {
    await prisma.kbDocument.delete({ where: { id: req.params.id } });
    res.json({ message: 'Documento removido' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/kb/test — testar IA
kbRouter.post('/test', async (req, res) => {
  try {
    const { pergunta } = req.body;
    if (!pergunta) return res.status(400).json({ error: 'Pergunta obrigatória' });

    const docs = await prisma.kbDocument.findMany({ where: { status: 'indexed' } });
    const contexto = docs.map(d => `[${d.titulo}]\n${d.conteudo}`).join('\n\n');

    // Em produção: chamar OpenAI com o contexto
    // const openai = require('./openai');
    // const resposta = await openai.chat(pergunta, contexto);

    const resposta = `Baseado na base de conhecimento (${docs.length} documentos indexados): ${contexto.slice(0, 200)}... Em produção, este campo seria respondido pela OpenAI GPT-4o.`;

    res.json({ resposta, docsUsados: docs.length });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Relatórios ───────────────────────────────────────
const relatorios = express.Router();
relatorios.use(auth);

relatorios.get('/resumo', async (req, res) => {
  try {
    const [totalLeads, leadsGanhos, totalContatos, totalMsgs, financeiro, campanhas] = await Promise.all([
      prisma.lead.count(),
      prisma.lead.count({ where: { status: 'GANHO' } }),
      prisma.contato.count(),
      prisma.message.count({ where: { dir: 'OUT' } }),
      prisma.lancamento.findMany(),
      prisma.campanha.findMany(),
    ]);

    const receita  = financeiro.filter(f => f.tipo === 'ENTRADA').reduce((a, f) => a + f.valor, 0);
    const despesas = financeiro.filter(f => f.tipo === 'SAIDA').reduce((a, f) => a + f.valor, 0);

    const leadsPorStatus = await prisma.lead.groupBy({ by: ['status'], _count: { status: true } });
    const leadsPorCanal  = await prisma.lead.groupBy({ by: ['canal'],  _count: { canal: true } });

    res.json({
      leads:       { total: totalLeads, ganhos: leadsGanhos, taxaConversao: totalLeads ? Math.round((leadsGanhos / totalLeads) * 100) : 0, porStatus: leadsPorStatus, porCanal: leadsPorCanal },
      financeiro:  { receita, despesas, saldo: receita - despesas },
      comunicacao: { msgsSent: totalMsgs, contatos: totalContatos },
      campanhas:   campanhas.map(c => ({ nome: c.nome, taxaLeitura: c.sent > 0 ? Math.round((c.read / c.sent) * 100) : 0, sent: c.sent, read: c.read })),
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = { contatos, conversations, campanhas, agenda, financeiro, usuarios, billing, conexoes, automacoes, kbRouter, relatorios };
