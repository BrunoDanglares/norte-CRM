require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const morgan  = require('morgan');
const authRoutes = require('./routes/auth');
const leadsRoutes = require('./routes/leads');
const {
  contatos, conversations, campanhas, agenda,
  financeiro, usuarios, billing, conexoes,
  automacoes, kbRouter, relatorios,
} = require('./routes/index');

const app  = express();
const PORT = process.env.PORT || 3001;

const corsOptions = {
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
};

// CORS antes do helmet para não ser bloqueado
app.use(cors(corsOptions));
app.options('*', cors(corsOptions)); // preflight em todas as rotas

// ── Segurança ──────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: false }));

// ── Middlewares ────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── Rotas ──────────────────────────────────────────────
app.use('/api/auth',          authRoutes);
app.use('/api/leads',         leadsRoutes);
app.use('/api/contatos',      contatos);
app.use('/api/conversations', conversations);
app.use('/api/campanhas',     campanhas);
app.use('/api/agenda',        agenda);
app.use('/api/financeiro',    financeiro);
app.use('/api/usuarios',      usuarios);
app.use('/api/billing',       billing);
app.use('/api/conexoes',      conexoes);
app.use('/api/automacoes',    automacoes);
app.use('/api/kb',            kbRouter);
app.use('/api/relatorios',    relatorios);
app.use('/api/webhook',       require('./routes/webhook'));

// ── Health check ───────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', env: process.env.NODE_ENV, timestamp: new Date().toISOString() });
});

// ── Dev: escrever arquivos diretamente no projeto ───────
// Só ativo em desenvolvimento — Claude usa isso para deploy automático
if (process.env.NODE_ENV !== 'production') {
  const fs   = require('fs');
  const path = require('path');

  app.post('/dev/write-file', (req, res) => {
    try {
      const { filePath, content } = req.body;
      if (!filePath || content === undefined) {
        return res.status(400).json({ error: 'filePath e content são obrigatórios' });
      }
      // Só permite escrever dentro das pastas do projeto
      const resolved = path.resolve(filePath);
      fs.mkdirSync(path.dirname(resolved), { recursive: true });
      fs.writeFileSync(resolved, content, 'utf8');
      console.log(`✍️  Arquivo atualizado: ${resolved}`);
      res.json({ ok: true, path: resolved });
    } catch (err) {
      console.error('write-file error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/dev/read-file', (req, res) => {
    try {
      const { filePath } = req.query;
      const content = require('fs').readFileSync(path.resolve(filePath), 'utf8');
      res.json({ ok: true, content });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  console.log('🛠️  Rotas DEV ativas: POST /dev/write-file | GET /dev/read-file');
}

// ── 404 ────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Rota ${req.method} ${req.path} não encontrada` });
});

// ── Error Handler ──────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌ Erro:', err);
  res.status(500).json({ error: process.env.NODE_ENV === 'production' ? 'Erro interno do servidor' : err.message });
});

// ── Start ──────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 CRM SaaS Backend rodando na porta ${PORT}`);
  console.log(`📡 Ambiente: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔗 Health: http://localhost:${PORT}/health`);
  console.log(`📖 API: http://localhost:${PORT}/api`);

  if (process.env.NODE_ENV !== 'production') {
    console.log('\n📋 Rotas disponíveis:');
    [
      'POST   /api/auth/login',
      'GET    /api/auth/me',
      'GET    /api/leads',
      'POST   /api/leads',
      'PUT    /api/leads/:id',
      'DELETE /api/leads/:id',
      'GET    /api/contatos',
      'POST   /api/contatos',
      'GET    /api/conversations',
      'POST   /api/conversations/:id/messages',
      'POST   /api/conversations/:id/resolve',
      'GET    /api/campanhas',
      'POST   /api/campanhas',
      'GET    /api/agenda',
      'POST   /api/agenda',
      'GET    /api/financeiro',
      'POST   /api/financeiro',
      'GET    /api/usuarios',
      'POST   /api/usuarios/invite',
      'GET    /api/billing',
      'POST   /api/billing/upgrade',
      'GET    /api/conexoes',
      'POST   /api/conexoes',
      'GET    /api/automacoes',
      'GET    /api/kb',
      'POST   /api/kb/test',
      'GET    /api/relatorios/resumo',
    ].forEach(r => console.log('  ' + r));
  }
});

module.exports = app;
// já importado acima — não duplicar
