import { useState, useMemo } from 'react';
import { useStore } from '../../store/useStore';

const STAGES = {
  novo:       { label:'Novo',        color:'#60a5fa' },
  contatado:  { label:'Contatado',   color:'#818cf8' },
  qualificado:{ label:'Qualificado', color:'#a78bfa' },
  proposta:   { label:'Proposta',    color:'#c084fc' },
  negociacao: { label:'Negociação',  color:'#f59e0b' },
  ganho:      { label:'Ganho',       color:'#34d399' },
  perdido:    { label:'Perdido',     color:'#f87171' },
};

function fmt(n) { return (+n).toLocaleString('pt-BR'); }
function cIco(c) { const m={whatsapp:'💚',instagram:'📸',chat:'💬',email:'📧'}; return m[(c||'').toLowerCase()]||'💬'; }
function StBadge({ s }) {
  const stg = STAGES[(s||'').toLowerCase()];
  if (!stg) return <span>{s}</span>;
  return (
    <span style={{ padding:'3px 9px', borderRadius:20, fontSize:10.5, fontWeight:700,
      background: stg.color+'22', color: stg.color, border:`1px solid ${stg.color}44` }}>
      {stg.label}
    </span>
  );
}

function LeadModal({ lead, onClose, onSave, onDelete, onHistory, usuarios }) {
  const isNew = !lead?.id;
  const [form, setForm] = useState({
    nome: lead?.nome || '',
    contato: lead?.contato || '',
    valor: lead?.valor || '',
    status: lead?.status || 'novo',
    canal: lead?.canal || 'WhatsApp',
    owner: lead?.owner || (usuarios?.[0]?.nome || 'Ana Costa'),
    obs: lead?.obs || '',
  });
  const f = (k) => (e) => setForm(p => ({ ...p, [k]: e.target.value }));

  return (
    <div className="overlay" onClick={(e) => e.target===e.currentTarget && onClose()}>
      <div className="modal">
        <div className="m-head">
          <div className="m-title">{isNew ? '+ Novo Lead' : `✏️ ${lead.nome}`}</div>
          <button className="m-close" onClick={onClose}>✕</button>
        </div>
        <div className="m-body">
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            <div className="fg" style={{ gridColumn:'1/-1' }}>
              <label className="fl">Empresa / Nome do Lead *</label>
              <input className="fc" value={form.nome} onChange={f('nome')} placeholder="Ex: Clínica Dr. João" autoFocus />
            </div>
            <div className="fg">
              <label className="fl">Responsável pelo contato</label>
              <input className="fc" value={form.contato} onChange={f('contato')} placeholder="Nome do contato" />
            </div>
            <div className="fg">
              <label className="fl">Valor estimado (R$)</label>
              <input className="fc" type="number" value={form.valor} onChange={f('valor')} placeholder="0,00" />
            </div>
            <div className="fg">
              <label className="fl">Status / Etapa</label>
              <select className="fc" value={form.status} onChange={f('status')}>
                {Object.entries(STAGES).map(([k,s]) => <option key={k} value={k}>{s.label}</option>)}
              </select>
            </div>
            <div className="fg">
              <label className="fl">Canal de entrada</label>
              <select className="fc" value={form.canal} onChange={f('canal')}>
                {['WhatsApp','Instagram','Chat','Email','Indicação','Site'].map(ch => <option key={ch}>{ch}</option>)}
              </select>
            </div>
            <div className="fg">
              <label className="fl">Responsável (vendedor)</label>
              <select className="fc" value={form.owner} onChange={f('owner')}>
                {(usuarios||[]).map(u => <option key={u.nome || u.id}>{u.nome}</option>)}
              </select>
            </div>
            <div className="fg" style={{ gridColumn:'1/-1' }}>
              <label className="fl">Observações</label>
              <textarea className="fc" rows={3} value={form.obs} onChange={f('obs')} placeholder="Anotações sobre o lead…" />
            </div>
          </div>
          {!isNew && (
            <div style={{ marginTop:12, padding:10, background:'var(--card2)', borderRadius:8, display:'flex', gap:8, flexWrap:'wrap' }}>
              <button className="btn btn-ghost btn-sm" onClick={onClose}>💬 Abrir Inbox</button>
              <button className="btn btn-ghost btn-sm" onClick={() => onHistory && onHistory(lead)}>📋 Histórico</button>
            </div>
          )}
          <div style={{ marginTop:14, display:'flex', justifyContent:'space-between' }}>
            <div>
              {!isNew && <button className="btn btn-ghost btn-sm" style={{ color:'#ef4444' }} onClick={() => { onDelete(lead); onClose(); }}>🗑 Excluir</button>}
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <button className="btn btn-ghost" onClick={onClose}>Cancelar</button>
              <button className="btn-primary" onClick={() => onSave(form)}>💾 Salvar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function HistoryModal({ lead, onClose, onEdit }) {
  const [note, setNote] = useState('');
  const [extras, setExtras] = useState([]);
  const acts = [
    { icon:'🆕', txt:`Lead criado via ${lead.canal}`, time:'há 12 dias', color:'var(--accent3)' },
    { icon:'📞', txt:`Primeiro contato — ${lead.contato}`, time:'há 10 dias', color:'var(--blue)' },
    { icon:'💬', txt:'Mensagem enviada pelo WhatsApp', time:'há 9 dias', color:'var(--green)' },
    { icon:'📧', txt:'Email de apresentação enviado', time:'há 7 dias', color:'var(--accent)' },
    { icon:'🔄', txt:`Status: ${STAGES[lead.status]?.label||lead.status}`, time:'há 5 dias', color:'var(--accent3)' },
    { icon:'📅', txt:'Reunião agendada', time:'há 3 dias', color:'var(--yellow)' },
    { icon:'💬', txt:'Follow-up realizado', time:'ontem', color:'var(--green)' },
    { icon:'📝', txt:`Proposta R$ ${fmt(lead.valor)} preparada`, time:'hoje', color:'var(--accent2)' },
  ];
  return (
    <div className="overlay" onClick={(e) => e.target===e.currentTarget && onClose()}>
      <div className="modal">
        <div className="m-head">
          <div className="m-title">📋 Histórico — {lead.nome}</div>
          <button className="m-close" onClick={onClose}>✕</button>
        </div>
        <div className="m-body">
          <div style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 12px', background:'var(--card2)', borderRadius:10, marginBottom:14 }}>
            <span style={{ fontSize:22 }}>{cIco(lead.canal)}</span>
            <div>
              <div style={{ fontWeight:700 }}>{lead.nome}</div>
              <div style={{ fontSize:11.5, color:'var(--muted2)' }}>{lead.contato}</div>
            </div>
            <div style={{ marginLeft:'auto', fontSize:16, fontWeight:900, color:'var(--green)' }}>R$ {fmt(lead.valor)}</div>
          </div>
          <div style={{ display:'flex', gap:8, marginBottom:14 }}>
            <input className="fc" value={note} onChange={e=>setNote(e.target.value)}
              placeholder="Adicionar anotação…" style={{ flex:1 }}
              onKeyDown={e=>{ if(e.key==='Enter' && note.trim()) { setExtras(p=>[...p,note]); setNote(''); }}} />
            <button className="btn-primary btn-sm" onClick={() => { if(note.trim()) { setExtras(p=>[...p,note]); setNote(''); }}}>+ Nota</button>
          </div>
          <div style={{ position:'relative', paddingLeft:20 }}>
            <div style={{ position:'absolute', left:7, top:0, bottom:0, width:2, background:'var(--border)' }} />
            {[...acts, ...extras.map(n=>({ icon:'📝', txt:n, time:'agora', color:'var(--accent)', extra:true }))].map((a,i) => (
              <div key={i} style={{ position:'relative', marginBottom:12 }}>
                <div style={{ position:'absolute', left:-16, width:14, height:14, borderRadius:'50%', background:a.color, border:'2px solid var(--card)', top:2 }} />
                <div style={{ background: a.extra?'var(--accentBg)':'var(--card2)', border:`1px solid ${a.extra?'var(--accentBd)':'var(--border)'}`, borderRadius:8, padding:'8px 12px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                    <span style={{ fontSize:13 }}>{a.icon}</span>
                    <span style={{ fontSize:12, fontWeight:600, flex:1 }}>{a.txt}</span>
                    <span style={{ fontSize:10, color:'var(--muted)', flexShrink:0 }}>{a.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ marginTop:14, display:'flex', justifyContent:'flex-end', gap:8 }}>
            <button className="btn btn-ghost btn-sm" onClick={() => onEdit(lead)}>✏️ Editar Lead</button>
            <button className="btn btn-ghost" onClick={onClose}>Fechar</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Leads() {
  const leads = useStore(s => s.data.leads) || [];
  const usuarios = useStore(s => s.data.usuarios) || [];
  const addLead = useStore(s => s.addLead);
  const updateLead = useStore(s => s.updateLead);
  const deleteLead = useStore(s => s.deleteLead);
  const notify = useStore(s => s.notify);
  const setPage = useStore(s => s.setPage);

  const [view, setView] = useState('tbl');
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterCanal, setFilterCanal] = useState('');
  const [sortKey, setSortKey] = useState(null);
  const [sortAsc, setSortAsc] = useState(true);
  const [modal, setModal] = useState(null);
  const [dragIdx, setDragIdx] = useState(null);

  const filtered = useMemo(() => {
    let f = [...leads];
    if (search) f = f.filter(l => l.nome?.toLowerCase().includes(search.toLowerCase()) || l.contato?.toLowerCase().includes(search.toLowerCase()));
    if (filterStatus) f = f.filter(l => l.status === filterStatus);
    if (filterCanal) f = f.filter(l => l.canal === filterCanal);
    if (sortKey) f.sort((a,b) => sortAsc ? (a[sortKey]>b[sortKey]?1:-1) : (a[sortKey]<b[sortKey]?1:-1));
    return f;
  }, [leads, search, filterStatus, filterCanal, sortKey, sortAsc]);

  function handleSort(key) {
    if (sortKey === key) setSortAsc(p => !p);
    else { setSortKey(key); setSortAsc(true); }
  }

  function handleSave(form) {
    if (!form.nome) return notify('⚠️ Preencha o nome do lead');
    const payload = { ...form, valor: parseFloat(form.valor)||0 };
    if (modal?.lead?.id) {
      updateLead(modal.lead.id, payload);
      notify('✅ Lead atualizado!');
    } else {
      addLead({ ...payload, data: new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'}) });
      notify('✅ Lead criado!');
    }
    setModal(null);
  }

  function handleDelete(lead) { deleteLead(lead.id); notify('🗑 Lead excluído'); }

  function exportCSV() {
    const rows = [['ID','Nome','Contato','Valor','Status','Canal','Responsável','Data']];
    leads.forEach(l => rows.push([l.id,l.nome,l.contato,l.valor,l.status,l.canal,l.owner,l.data]));
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,'+encodeURIComponent(rows.map(r=>r.join(',')).join('\n'));
    a.download = 'leads.csv'; a.click();
    notify('📥 CSV exportado!');
  }

  function onDragStart(e, idx) { setDragIdx(idx); e.dataTransfer.setData('text/plain', String(idx)); }
  function onDragOver(e) { e.preventDefault(); }
  function onDrop(e, stageKey) {
    e.preventDefault();
    const idx = dragIdx ?? parseInt(e.dataTransfer.getData('text/plain'));
    const lead = leads[idx];
    if (!lead || lead.status === stageKey) { setDragIdx(null); return; }
    updateLead(lead.id, { status: stageKey });
    notify(`✅ ${lead.nome} → ${STAGES[stageKey].label}`);
    setDragIdx(null);
  }

  return (
    <div style={{ padding:0, height:'100%', display:'flex', flexDirection:'column' }}>
      {/* Toolbar */}
      <div style={{ padding:'12px 18px', borderBottom:'1px solid var(--border)', display:'flex', gap:8, alignItems:'center', flexWrap:'wrap', flexShrink:0 }}>
        <div className="search-wrap" style={{ flex:1, minWidth:180 }}>
          <span className="search-icon">⌕</span>
          <input placeholder="Buscar leads…" value={search} onChange={e=>setSearch(e.target.value)} />
        </div>
        <select className="fc" style={{ width:155 }} value={filterStatus} onChange={e=>setFilterStatus(e.target.value)}>
          <option value="">Todos os status</option>
          {Object.entries(STAGES).map(([k,s]) => <option key={k} value={k}>{s.label}</option>)}
        </select>
        <select className="fc" style={{ width:145 }} value={filterCanal} onChange={e=>setFilterCanal(e.target.value)}>
          <option value="">Todos os canais</option>
          <option>WhatsApp</option><option>Instagram</option><option>Chat</option><option>Email</option>
        </select>
        <div style={{ display:'flex', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden' }}>
          <button onClick={()=>setView('tbl')} style={{ padding:'6px 12px', border:'none', background:view==='tbl'?'var(--accent)':'transparent', color:view==='tbl'?'#fff':'var(--muted)', fontSize:11.5, cursor:'pointer' }}>≡ Tabela</button>
          <button onClick={()=>setView('kan')} style={{ padding:'6px 12px', border:'none', background:view==='kan'?'var(--accent)':'transparent', color:view==='kan'?'#fff':'var(--muted)', fontSize:11.5, cursor:'pointer' }}>⬛ Kanban</button>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={exportCSV}>↓ CSV</button>
        <button className="btn-primary btn-sm" onClick={()=>setModal({ type:'edit', lead:null })}>+ Novo Lead</button>
      </div>

      {/* Stats bar */}
      <div style={{ display:'flex', borderBottom:'1px solid var(--border)', flexShrink:0 }}>
        {Object.entries(STAGES).slice(0,5).map(([k,s]) => {
          const n = leads.filter(l=>l.status===k).length;
          const v = leads.filter(l=>l.status===k).reduce((a,l)=>a+(l.valor||0),0);
          return (
            <div key={k} onClick={()=>setFilterStatus(filterStatus===k?'':k)}
              style={{ flex:1, padding:'8px 12px', borderRight:'1px solid var(--border)', minWidth:0, cursor:'pointer',
                background: filterStatus===k ? s.color+'11' : 'transparent' }}>
              <div style={{ fontSize:10, fontWeight:700, color:s.color, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{s.label}</div>
              <div style={{ fontSize:13, fontWeight:900 }}>{n}</div>
              <div style={{ fontSize:9.5, color:'var(--muted)' }}>R${fmt(v)}</div>
            </div>
          );
        })}
        <div style={{ flex:1, padding:'8px 12px', minWidth:0 }}>
          <div style={{ fontSize:10, fontWeight:700, color:'var(--muted)' }}>TOTAL</div>
          <div style={{ fontSize:13, fontWeight:900 }}>{leads.length}</div>
          <div style={{ fontSize:9.5, color:'var(--green)' }}>R${fmt(leads.reduce((a,l)=>a+(l.valor||0),0))}</div>
        </div>
      </div>

      {/* TABLE VIEW */}
      {view === 'tbl' && (
        <div style={{ flex:1, overflowY:'auto' }}>
          <table style={{ width:'100%', borderCollapse:'collapse' }}>
            <thead style={{ position:'sticky', top:0, zIndex:1, background:'var(--card2)' }}>
              <tr style={{ borderBottom:'1.5px solid var(--border)' }}>
                <th onClick={()=>handleSort('nome')} style={{ textAlign:'left', padding:'10px 14px', fontSize:11, fontWeight:700, color:'var(--muted)', cursor:'pointer' }}>
                  LEAD {sortKey==='nome'?(sortAsc?'↑':'↓'):'↕'}
                </th>
                <th style={{ textAlign:'left', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>CONTATO</th>
                <th onClick={()=>handleSort('valor')} style={{ textAlign:'right', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)', cursor:'pointer' }}>
                  VALOR {sortKey==='valor'?(sortAsc?'↑':'↓'):'↕'}
                </th>
                <th style={{ textAlign:'center', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>STATUS</th>
                <th style={{ textAlign:'center', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>CANAL</th>
                <th style={{ textAlign:'left', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>RESP.</th>
                <th style={{ textAlign:'center', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>DATA</th>
                <th style={{ padding:'10px 14px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>AÇÕES</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((l, i) => (
                <tr key={l.id || i} style={{ borderBottom:'1px solid var(--border)', transition:'background .12s' }}
                  onMouseEnter={e=>e.currentTarget.style.background='var(--card2)'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={{ padding:'10px 14px', cursor:'pointer' }} onClick={()=>setModal({ type:'edit', lead:l })}>
                    <div style={{ fontWeight:700, fontSize:13 }}>{l.nome}</div>
                    <div style={{ fontSize:10.5, color:'var(--muted)' }}>ID #{l.id}</div>
                  </td>
                  <td style={{ padding:'10px 10px', fontSize:12 }}>{l.contato}</td>
                  <td style={{ padding:'10px 10px', textAlign:'right', fontWeight:800, color:'var(--green)', fontSize:13 }}>R${fmt(l.valor||0)}</td>
                  <td style={{ padding:'10px 10px', textAlign:'center' }}><StBadge s={l.status} /></td>
                  <td style={{ padding:'10px 10px', textAlign:'center', fontSize:18 }}>{cIco(l.canal)}</td>
                  <td style={{ padding:'10px 10px' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:5 }}>
                      <div className="ava" style={{ width:22, height:22, fontSize:9, borderRadius:6 }}>{(l.owner||'?')[0]}</div>
                      <span style={{ fontSize:11.5, color:'var(--muted2)' }}>{(l.owner||'').split(' ')[0]}</span>
                    </div>
                  </td>
                  <td style={{ padding:'10px 10px', textAlign:'center', fontSize:11.5, color:'var(--muted)' }}>{l.data}</td>
                  <td style={{ padding:'10px 14px' }}>
                    <div style={{ display:'flex', gap:4 }}>
                      <button className="btn btn-ghost btn-sm" title="Editar" onClick={()=>setModal({ type:'edit', lead:l })}>✏️</button>
                      <button className="btn btn-ghost btn-sm" title="Inbox" onClick={()=>setPage('inbox')}>💬</button>
                      <button className="btn btn-ghost btn-sm" title="Histórico" onClick={()=>setModal({ type:'history', lead:l })}>📋</button>
                      <button className="btn btn-ghost btn-sm" title="Excluir" style={{ color:'#ef4444' }} onClick={()=>handleDelete(l)}>🗑</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div style={{ textAlign:'center', padding:'40px', color:'var(--muted)' }}>
              <div style={{ fontSize:28, marginBottom:8 }}>🔍</div>
              Nenhum lead encontrado
            </div>
          )}
        </div>
      )}

      {/* KANBAN VIEW */}
      {view === 'kan' && (
        <div style={{ flex:1, overflowX:'auto', overflowY:'hidden', padding:16 }}>
          <div style={{ display:'flex', gap:12, minWidth:'max-content', height:'100%' }}>
            {Object.entries(STAGES).map(([k,s]) => {
              const colLeads = leads.filter(l=>l.status===k);
              const colTotal = colLeads.reduce((a,l)=>a+(l.valor||0),0);
              return (
                <div key={k} className="k-col" style={{ height:'100%', display:'flex', flexDirection:'column', minWidth:230, maxWidth:230 }}
                  onDragOver={onDragOver} onDrop={e=>onDrop(e,k)}>
                  <div className="k-head" style={{ borderTop:`3px solid ${s.color}`, flexShrink:0 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', width:'100%', alignItems:'center', marginBottom:4 }}>
                      <span style={{ color:s.color, fontWeight:800, fontSize:12 }}>{s.label}</span>
                      <span className="k-cnt">{colLeads.length}</span>
                    </div>
                    <div style={{ fontSize:10.5, color:'var(--muted2)' }}>R$ {fmt(colTotal)}</div>
                  </div>
                  <div className="k-body" style={{ flex:1, overflowY:'auto' }}>
                    {colLeads.map(l => {
                      const idx = leads.indexOf(l);
                      return (
                        <div key={l.id} className="k-card"
                          draggable onDragStart={e=>onDragStart(e,idx)}
                          onClick={()=>setModal({ type:'edit', lead:l })}
                          style={{ cursor:'grab' }}>
                          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5, alignItems:'flex-start' }}>
                            <div style={{ flex:1, minWidth:0, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', fontSize:12.5, fontWeight:600 }}>{l.nome}</div>
                            <span style={{ fontSize:15, flexShrink:0, marginLeft:4 }}>{cIco(l.canal)}</span>
                          </div>
                          <div className="k-card-meta">{l.contato}</div>
                          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:8 }}>
                            <div className="k-card-val">R$ {fmt(l.valor||0)}</div>
                            <div className="ava" style={{ width:22, height:22, fontSize:9, borderRadius:6 }}>{(l.owner||'?')[0]}</div>
                          </div>
                          <div style={{ fontSize:10, color:'var(--muted)', marginTop:5 }}>📅 {l.data}</div>
                        </div>
                      );
                    })}
                    <button onClick={()=>setModal({ type:'edit', lead:{ status:k } })}
                      style={{ width:'100%', padding:8, border:'1.5px dashed var(--border)', borderRadius:8, background:'transparent', color:'var(--muted)', fontSize:11.5, cursor:'pointer', marginTop:4 }}
                      onMouseEnter={e=>e.currentTarget.style.borderColor='var(--accent)'}
                      onMouseLeave={e=>e.currentTarget.style.borderColor='var(--border)'}>
                      + Adicionar
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* MODALS */}
      {modal?.type === 'edit' && (
        <LeadModal lead={modal.lead} usuarios={usuarios}
          onClose={()=>setModal(null)} onSave={handleSave} onDelete={handleDelete}
          onHistory={lead=>setModal({ type:'history', lead })} />
      )}
      {modal?.type === 'history' && (
        <HistoryModal lead={modal.lead}
          onClose={()=>setModal(null)} onEdit={lead=>setModal({ type:'edit', lead })} />
      )}
    </div>
  );
}
