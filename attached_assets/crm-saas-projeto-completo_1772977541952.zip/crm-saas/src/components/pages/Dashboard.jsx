import { useStore } from '../../store/useStore';

const STAGES = {
  novo:       { label: 'Novo',       color: '#60a5fa' },
  contatado:  { label: 'Contatado',  color: '#818cf8' },
  qualificado:{ label: 'Qualificado',color: '#a78bfa' },
  proposta:   { label: 'Proposta',   color: '#c084fc' },
  negociacao: { label: 'Negociação', color: '#e879f9' },
  ganho:      { label: 'Ganho',      color: '#34d399' },
  perdido:    { label: 'Perdido',    color: '#f87171' },
};

function fmt(n) { return (+n).toLocaleString('pt-BR'); }
function cIco(c) {
  return { WhatsApp:'💚', whatsapp:'💚', Instagram:'📸', instagram:'📸', Chat:'💬', chat:'💬', Email:'📧' }[c] || '💬';
}

function setPage(page) {
  useStore.getState().setCurrentPage?.(page);
}

function SCard({ title, value, sub, dirUp = true, icon, bg, color }) {
  return (
    <div style={{ background:'var(--card)', border:'1.5px solid var(--border)', borderRadius:12, padding:16 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:10 }}>
        <div style={{ fontSize:10.5, fontWeight:700, color:'var(--muted)', textTransform:'uppercase' }}>{title}</div>
        <div style={{ width:32, height:32, borderRadius:9, background:bg, display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, color }}>{icon}</div>
      </div>
      <div style={{ fontSize:22, fontWeight:900, marginBottom:4 }}>{value}</div>
      <div style={{ fontSize:11, color: dirUp ? 'var(--green)' : '#ef4444' }}>{sub}</div>
    </div>
  );
}

export default function Dashboard() {
  const { leads = [], conversations = [], agenda = [], financeiro = [], user } = useStore();

  const totalLeads  = leads.length;
  const ganhos      = leads.filter(l => l.status === 'ganho').length;
  const mrr         = (financeiro || []).filter(t => t.tipo === 'entrada' && t.status === 'pago').reduce((s, t) => s + (t.valor || 0), 0);
  const totalMsgs   = (conversations || []).reduce((s, cv) => s + (cv.unread || 0), 0);
  const winRate     = totalLeads ? Math.round(ganhos / totalLeads * 100) : 0;
  const pipeValue   = leads.filter(l => !['ganho','perdido'].includes(l.status)).reduce((a, l) => a + (l.valor || 0), 0);
  const openConvs   = (conversations || []).filter(cv => cv.status === 'open').length;
  const firstName   = user?.nome?.split(' ')[0] || 'Usuário';
  const today       = new Date().toLocaleDateString('pt-BR', { weekday:'long', day:'numeric', month:'long' });

  const activeLeads = leads.filter(l => !['ganho','perdido'].includes(l.status)).slice(0, 5);
  const recentConvs = conversations.slice(0, 3);
  const todayEvents = (agenda || []).filter(e => e.data === 'Hoje' || e.data === 'Amanhã').slice(0, 3);

  const ganhoLead = leads.find(l => l.status === 'ganho');
  const pagamento = (financeiro || []).find(f => f.status === 'pago');
  const activities = [
    { ico:'🆕', color:'var(--accent3)', txt: leads[0] ? `Lead "${leads[0].nome}" criado`                     : 'Novo lead criado',      time:'agora' },
    { ico:'💬', color:'var(--green)',   txt: conversations[0] ? `Msg de ${conversations[0].nome}`             : 'Mensagem recebida',     time:'há 2m' },
    { ico:'✅', color:'var(--green)',   txt: ganhoLead ? `"${ganhoLead.nome}" marcado como ganho`              : 'Deal fechado',          time:'há 5m' },
    { ico:'📅', color:'var(--yellow)',  txt: agenda[0] ? `Reunião: ${agenda[0].titulo}`                       : 'Reunião agendada',      time:'há 8m' },
    { ico:'🤖', color:'#2dd4bf',        txt:'IA respondeu 3 conversas automaticamente',                                                  time:'há 12m' },
    { ico:'📊', color:'var(--accent)',  txt:'Campanha em andamento',                                                                     time:'há 15m' },
    { ico:'💰', color:'var(--green)',   txt:`Pagamento de R$ ${fmt(pagamento?.valor || 0)} confirmado`,                                  time:'há 22m' },
    { ico:'🔄', color:'var(--blue)',    txt: leads[1] ? `Automação disparada para ${leads[1].nome}`           : 'Automação disparada',   time:'há 30m' },
  ];

  return (
    <div style={{ height:'100%', display:'flex', flexDirection:'column', overflow:'hidden' }}>

      {/* Welcome bar */}
      <div style={{ padding:'13px 22px', background:'linear-gradient(135deg,var(--accentBg) 0%,transparent 100%)', borderBottom:'1px solid var(--border)', flexShrink:0, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <div style={{ fontSize:14, fontWeight:900 }}>Bom dia, {firstName} 👋</div>
          <div style={{ fontSize:11.5, color:'var(--muted)', marginTop:2 }}>{today}</div>
        </div>
        <div style={{ display:'flex', gap:7 }}>
          <button style={btnGhost} onClick={() => setPage('leads')}>+ Lead</button>
          <button style={btnGhost} onClick={() => setPage('inbox')}>
            💬 Inbox {totalMsgs > 0 && <span style={{ background:'#ef4444', color:'#fff', borderRadius:10, padding:'1px 5px', fontSize:9.5, marginLeft:3 }}>{totalMsgs}</span>}
          </button>
          <button style={btnPrimary} onClick={() => setPage('campanhas')}>📢 Campanha</button>
        </div>
      </div>

      {/* Main: 2 columns */}
      <div style={{ flex:1, overflowY:'auto', padding:'18px 20px', display:'grid', gridTemplateColumns:'1fr 320px', gap:16, alignContent:'start' }}>

        {/* LEFT */}
        <div style={{ display:'flex', flexDirection:'column', gap:14, minWidth:0 }}>

          {/* KPIs */}
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14 }}>
            <SCard title="Total de Leads"  value={totalLeads}       sub="↑ 12% vs mês anterior" icon="◎" bg="var(--blueDim)"              color="#60a5fa" />
            <SCard title="MRR"             value={`R$${fmt(mrr)}`}  sub="↑ 8% vs mês anterior"  icon="◇" bg="var(--greenDim)"             color="#34d399" />
            <SCard title="Msgs não lidas"  value={totalMsgs}        sub={`${openConvs} conversas abertas`} icon="✉" bg="rgba(124,92,191,.2)" color="var(--accent3)" />
            <SCard title="Taxa Conversão"  value={`${winRate}%`}    sub={`${ganhos} leads ganhos`} icon="◉" bg="rgba(251,191,36,.15)"    color="#fbbf24" />
          </div>

          {/* Pipeline + MRR */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>

            <div style={{ background:'var(--card)', border:'1.5px solid var(--border)', borderRadius:12, padding:16 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
                <div style={{ fontSize:12.5, fontWeight:800 }}>Pipeline</div>
                <div style={{ fontSize:11, fontWeight:800, color:'var(--accent3)' }}>R$ {fmt(pipeValue)}</div>
              </div>
              {Object.entries(STAGES).filter(([k]) => !['ganho','perdido'].includes(k)).map(([k, s]) => {
                const cnt = leads.filter(l => l.status === k).length;
                const val = leads.filter(l => l.status === k).reduce((a, l) => a + (l.valor || 0), 0);
                const pct = totalLeads ? Math.round(cnt / totalLeads * 100) : 0;
                return (
                  <div key={k} style={{ marginBottom:9, cursor:'pointer' }} onClick={() => setPage('pipeline')}>
                    <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, marginBottom:3 }}>
                      <span style={{ color:s.color, fontWeight:700 }}>{s.label}</span>
                      <span><strong>{cnt}</strong> <span style={{ color:'var(--muted)' }}>· R${fmt(val)}</span></span>
                    </div>
                    <div style={{ height:6, background:'var(--card2)', borderRadius:3 }}>
                      <div style={{ width:`${Math.min(pct * 2, 100)}%`, height:'100%', background:s.color, borderRadius:3 }} />
                    </div>
                  </div>
                );
              })}
              <div style={{ marginTop:10, textAlign:'right' }}>
                <button style={btnGhost} onClick={() => setPage('pipeline')}>Ver pipeline completo →</button>
              </div>
            </div>

            <div style={{ background:'var(--card)', border:'1.5px solid var(--border)', borderRadius:12, padding:16 }}>
              <div style={{ fontSize:12.5, fontWeight:800, marginBottom:4 }}>Receita mensal</div>
              <div style={{ fontSize:22, fontWeight:900, color:'var(--green)' }}>R$ {fmt(mrr)}</div>
              <div style={{ fontSize:10.5, color:'var(--muted)', marginBottom:14 }}>Meta: R$ 60.000 · {Math.round(mrr / 60000 * 100)}% atingido</div>
              <div style={{ height:8, background:'var(--card2)', borderRadius:4, marginBottom:14 }}>
                <div style={{ width:`${Math.min(Math.round(mrr / 60000 * 100), 100)}%`, height:'100%', background:'var(--green)', borderRadius:4 }} />
              </div>
              <div style={{ display:'flex', alignItems:'flex-end', gap:3, height:50 }}>
                {[28,34,31,42,38,45, Math.max(mrr/1000, 10)].map((v, i) => (
                  <div key={i} style={{ flex:1, borderRadius:'2px 2px 0 0', background: i===6 ? 'var(--green)' : 'var(--accentBg)', border: i===6 ? 'none' : '1px solid var(--accentBd)', height:`${Math.round(v/50*50)}px` }} />
                ))}
              </div>
              <div style={{ display:'flex', justifyContent:'space-between', fontSize:9, color:'var(--muted)', marginTop:4 }}>
                {['Set','Out','Nov','Dez','Jan','Fev','Mar'].map(m => <span key={m}>{m}</span>)}
              </div>
            </div>
          </div>

          {/* Leads table */}
          <div style={{ background:'var(--card)', border:'1.5px solid var(--border)', borderRadius:12, overflow:'hidden' }}>
            <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div style={{ fontSize:12.5, fontWeight:800 }}>Leads prioritários</div>
              <button style={btnGhost} onClick={() => setPage('leads')}>Ver todos →</button>
            </div>
            <table style={{ width:'100%', borderCollapse:'collapse' }}>
              <tbody>
                {activeLeads.length === 0 ? (
                  <tr><td colSpan={5} style={{ padding:'24px 16px', textAlign:'center', color:'var(--muted)', fontSize:12 }}>Nenhum lead ativo no momento</td></tr>
                ) : activeLeads.map((l, i) => (
                  <tr key={l.id ?? i} style={{ borderBottom:'1px solid var(--border)', cursor:'pointer', transition:'background .1s' }}
                    onMouseOver={e => e.currentTarget.style.background = 'var(--card2)'}
                    onMouseOut={e  => e.currentTarget.style.background = ''}>
                    <td style={{ padding:'10px 16px', fontSize:12.5, fontWeight:700 }}>{l.nome}</td>
                    <td style={{ padding:'10px 8px', fontSize:11, color:'var(--muted)' }}>{l.contato || l.email || ''}</td>
                    <td style={{ padding:'10px 8px' }}>{cIco(l.canal)}</td>
                    <td style={{ padding:'10px 8px' }}>
                      <span style={{ padding:'2px 8px', borderRadius:6, fontSize:10, fontWeight:700, background:`${STAGES[l.status]?.color || '#888'}22`, color: STAGES[l.status]?.color || 'var(--muted)' }}>
                        {STAGES[l.status]?.label || l.status}
                      </span>
                    </td>
                    <td style={{ padding:'10px 16px', textAlign:'right', fontSize:12.5, fontWeight:800, color:'var(--accent3)' }}>
                      {l.valor ? `R$${fmt(l.valor)}` : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* RIGHT */}
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

          {/* Inbox */}
          <div style={{ background:'var(--card)', border:'1.5px solid var(--border)', borderRadius:12, overflow:'hidden' }}>
            <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div style={{ fontSize:12, fontWeight:800 }}>Inbox</div>
              {totalMsgs > 0 && <span style={{ background:'#ef4444', color:'#fff', borderRadius:10, padding:'2px 8px', fontSize:10.5, fontWeight:700 }}>{totalMsgs} não lidas</span>}
            </div>
            {recentConvs.map((cv, i) => (
              <div key={cv.id ?? i} style={{ padding:'10px 14px', borderBottom:'1px solid var(--border)', cursor:'pointer', display:'flex', gap:9 }}
                onClick={() => setPage('inbox')}
                onMouseOver={e => e.currentTarget.style.background = 'var(--card2)'}
                onMouseOut={e  => e.currentTarget.style.background = ''}>
                <div style={{ width:30, height:30, borderRadius:9, background:'var(--accentBg)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:13, flexShrink:0 }}>
                  {cIco(cv.canal)}
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:12, fontWeight:700, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{cv.nome || cv.name}</div>
                  <div style={{ fontSize:10.5, color:'var(--muted)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{cv.ultima || cv.last || '...'}</div>
                </div>
                {cv.unread > 0 && <span style={{ background:'#ef4444', color:'#fff', borderRadius:10, padding:'1px 6px', fontSize:10, fontWeight:700, flexShrink:0, alignSelf:'center' }}>{cv.unread}</span>}
              </div>
            ))}
            {recentConvs.length === 0 && <div style={{ padding:16, textAlign:'center', color:'var(--muted)', fontSize:12 }}>Nenhuma conversa</div>}
            <div style={{ padding:10, textAlign:'center' }}>
              <button style={btnGhost} onClick={() => setPage('inbox')}>Ver inbox completo →</button>
            </div>
          </div>

          {/* Activity */}
          <div style={{ background:'var(--card)', border:'1.5px solid var(--border)', borderRadius:12, overflow:'hidden' }}>
            <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)' }}>
              <div style={{ fontSize:12, fontWeight:800 }}>Atividade recente</div>
            </div>
            <div style={{ overflowY:'auto', maxHeight:320 }}>
              {activities.map((a, i) => (
                <div key={i} style={{ padding:'10px 14px', borderBottom:'1px solid var(--border)', display:'flex', gap:9, cursor:'pointer' }}
                  onMouseOver={e => e.currentTarget.style.background = 'var(--card2)'}
                  onMouseOut={e  => e.currentTarget.style.background = ''}>
                  <div style={{ width:28, height:28, borderRadius:8, background:`${a.color}22`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:13, flexShrink:0 }}>{a.ico}</div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:11.5, lineHeight:1.4 }}>{a.txt}</div>
                    <div style={{ fontSize:10, color:'var(--muted)', marginTop:2 }}>{a.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Agenda */}
          <div style={{ background:'var(--card)', border:'1.5px solid var(--border)', borderRadius:12, overflow:'hidden' }}>
            <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div style={{ fontSize:12, fontWeight:800 }}>Agenda de hoje</div>
              <button style={btnGhost} onClick={() => setPage('agenda')}>Ver →</button>
            </div>
            {todayEvents.length === 0
              ? <div style={{ padding:16, textAlign:'center', color:'var(--muted)', fontSize:12 }}>Nenhum compromisso hoje</div>
              : todayEvents.map((e, i) => (
                <div key={i} style={{ padding:'10px 14px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:9 }}>
                  <div style={{ width:3, height:36, borderRadius:2, background:'var(--accent)', flexShrink:0 }} />
                  <div>
                    <div style={{ fontSize:12, fontWeight:700 }}>{e.titulo}</div>
                    <div style={{ fontSize:10.5, color:'var(--muted)' }}>{e.data} · {e.hora}</div>
                  </div>
                </div>
              ))
            }
          </div>
        </div>

      </div>
    </div>
  );
}

const btnGhost = {
  display:'inline-flex', alignItems:'center', gap:6, padding:'5px 10px', borderRadius:8,
  border:'1px solid var(--border)', background:'transparent', color:'var(--muted2)',
  fontSize:11, fontWeight:500, cursor:'pointer', fontFamily:'inherit',
};
const btnPrimary = {
  display:'inline-flex', alignItems:'center', gap:6, padding:'7px 14px', borderRadius:9,
  background:'linear-gradient(135deg,var(--accent),var(--accent2))', border:'none', color:'#fff',
  fontSize:12, fontWeight:600, cursor:'pointer', fontFamily:'inherit',
};
