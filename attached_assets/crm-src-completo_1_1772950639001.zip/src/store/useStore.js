import { create } from 'zustand';
import {
  leadsService, contatosService, conversationsService,
  campanhasService, agendaService, financeiroService,
  usuariosService, billingService, conexoesService,
  automacoesService, kbService,
} from '../services';
import { getToken, removeToken } from '../services/api';

export const useStore = create((set, get) => ({
  // ── Auth ──────────────────────────────────────────────
  user:  null,
  token: getToken(),

  setUser: (user) => set({ user }),
  logout:  ()     => { removeToken(); set({ user: null, token: null }); },

  // ── Navigation ────────────────────────────────────────
  currentPage: 'dashboard',
  setPage: (page) => set({ currentPage: page }),

  // ── Theme ─────────────────────────────────────────────
  theme: 'dark',
  toggleTheme: () => set((s) => {
    const next = s.theme === 'dark' ? 'light' : 'dark';
    document.body.classList.toggle('light', next === 'light');
    return { theme: next };
  }),

  // ── Notifications ─────────────────────────────────────
  notifications: [],
  notify: (msg) => {
    const id = Date.now();
    set((s) => ({ notifications: [...s.notifications, { id, msg }] }));
    setTimeout(() => set((s) => ({ notifications: s.notifications.filter(n => n.id !== id) })), 3000);
  },

  // ── Loading ───────────────────────────────────────────
  loading: {},
  setLoading: (key, val) => set(s => ({ loading: { ...s.loading, [key]: val } })),

  // ── DATA ──────────────────────────────────────────────
  data: {
    leads: [], contatos: [], conversations: [], campanhas: [],
    agenda: [], financeiro: [], usuarios: [], automacoes: [],
    kb: [], conexoes: [], billing: null,
  },

  // ── Leads ─────────────────────────────────────────────
  fetchLeads: async (params) => {
    get().setLoading('leads', true);
    try {
      const res = await leadsService.list(params);
      set(s => ({ data: { ...s.data, leads: res.leads || res } }));
    } catch (e) { get().notify('Erro ao carregar leads'); }
    finally { get().setLoading('leads', false); }
  },
  addLead: async (lead) => {
    try {
      const novo = await leadsService.create(lead);
      set(s => ({ data: { ...s.data, leads: [novo, ...s.data.leads] } }));
      get().notify('Lead criado'); return novo;
    } catch (e) { get().notify(e.message); throw e; }
  },
  updateLead: async (id, updates) => {
    try {
      const updated = await leadsService.update(id, updates);
      set(s => ({ data: { ...s.data, leads: s.data.leads.map(l => l.id === id ? updated : l) } }));
      return updated;
    } catch (e) { get().notify(e.message); throw e; }
  },
  deleteLead: async (id) => {
    try {
      await leadsService.remove(id);
      set(s => ({ data: { ...s.data, leads: s.data.leads.filter(l => l.id !== id) } }));
      get().notify('Lead removido');
    } catch (e) { get().notify(e.message); }
  },

  // ── Contatos ──────────────────────────────────────────
  fetchContatos: async (params) => {
    get().setLoading('contatos', true);
    try {
      const res = await contatosService.list(params);
      set(s => ({ data: { ...s.data, contatos: res } }));
    } catch (e) { get().notify('Erro ao carregar contatos'); }
    finally { get().setLoading('contatos', false); }
  },
  addContato: async (data) => {
    try {
      const novo = await contatosService.create(data);
      set(s => ({ data: { ...s.data, contatos: [novo, ...s.data.contatos] } }));
      get().notify('Contato criado'); return novo;
    } catch (e) { get().notify(e.message); throw e; }
  },

  // ── Conversations ─────────────────────────────────────
  fetchConversations: async (params) => {
    get().setLoading('conversations', true);
    try {
      const res = await conversationsService.list(params);
      set(s => ({ data: { ...s.data, conversations: res } }));
    } catch (e) { get().notify('Erro ao carregar inbox'); }
    finally { get().setLoading('conversations', false); }
  },
  fetchConversation: async (id) => {
    try {
      const conv = await conversationsService.get(id);
      set(s => ({ data: { ...s.data, conversations: s.data.conversations.map(c => c.id === id ? conv : c) } }));
      return conv;
    } catch (e) { get().notify(e.message); }
  },
  sendMessage: async (convId, txt) => {
    try {
      const msg = await conversationsService.sendMessage(convId, txt);
      set(s => ({
        data: { ...s.data, conversations: s.data.conversations.map(c =>
          c.id !== convId ? c : { ...c, messages: [...(c.messages || []), msg] }
        )}
      }));
      return msg;
    } catch (e) { get().notify(e.message); throw e; }
  },
  resolveConv: async (id) => {
    try {
      await conversationsService.resolve(id);
      set(s => ({ data: { ...s.data, conversations: s.data.conversations.map(c => c.id === id ? { ...c, status: 'RESOLVED', unread: 0 } : c) } }));
      get().notify('Conversa resolvida');
    } catch (e) { get().notify(e.message); }
  },

  // ── Campanhas ─────────────────────────────────────────
  fetchCampanhas: async () => {
    get().setLoading('campanhas', true);
    try {
      const res = await campanhasService.list();
      set(s => ({ data: { ...s.data, campanhas: res } }));
    } catch (e) { get().notify('Erro ao carregar campanhas'); }
    finally { get().setLoading('campanhas', false); }
  },
  addCampanha: async (data) => {
    try {
      const nova = await campanhasService.create(data);
      set(s => ({ data: { ...s.data, campanhas: [nova, ...s.data.campanhas] } }));
      get().notify('Campanha criada'); return nova;
    } catch (e) { get().notify(e.message); throw e; }
  },

  // ── Agenda ────────────────────────────────────────────
  fetchAgenda: async (params) => {
    get().setLoading('agenda', true);
    try {
      const res = await agendaService.list(params);
      set(s => ({ data: { ...s.data, agenda: res } }));
    } catch (e) { get().notify('Erro ao carregar agenda'); }
    finally { get().setLoading('agenda', false); }
  },
  addAgendaItem: async (item) => {
    try {
      const novo = await agendaService.create(item);
      set(s => ({ data: { ...s.data, agenda: [...s.data.agenda, novo] } }));
      get().notify('Compromisso criado'); return novo;
    } catch (e) { get().notify(e.message); throw e; }
  },

  // ── Financeiro ────────────────────────────────────────
  fetchFinanceiro: async () => {
    get().setLoading('financeiro', true);
    try {
      const res = await financeiroService.list();
      set(s => ({ data: { ...s.data, financeiro: res.lancamentos || res } }));
    } catch (e) { get().notify('Erro ao carregar financeiro'); }
    finally { get().setLoading('financeiro', false); }
  },
  addLancamento: async (item) => {
    try {
      const novo = await financeiroService.create(item);
      set(s => ({ data: { ...s.data, financeiro: [novo, ...s.data.financeiro] } }));
      get().notify('Lançamento criado'); return novo;
    } catch (e) { get().notify(e.message); throw e; }
  },

  // ── Usuários ──────────────────────────────────────────
  fetchUsuarios: async () => {
    get().setLoading('usuarios', true);
    try {
      const res = await usuariosService.list();
      set(s => ({ data: { ...s.data, usuarios: res } }));
    } catch (e) { get().notify('Erro ao carregar usuários'); }
    finally { get().setLoading('usuarios', false); }
  },
  inviteUsuario: async (data) => {
    try {
      const novo = await usuariosService.invite(data);
      set(s => ({ data: { ...s.data, usuarios: [...s.data.usuarios, novo] } }));
      get().notify('Convite enviado'); return novo;
    } catch (e) { get().notify(e.message); throw e; }
  },

  // ── Billing ───────────────────────────────────────────
  fetchBilling: async () => {
    get().setLoading('billing', true);
    try {
      const res = await billingService.get();
      set(s => ({ data: { ...s.data, billing: res } }));
    } catch (e) { get().notify('Erro ao carregar billing'); }
    finally { get().setLoading('billing', false); }
  },
  upgradePlan: async (planId) => {
    try {
      await billingService.upgrade(planId);
      await get().fetchBilling();
      get().notify('Plano atualizado');
    } catch (e) { get().notify(e.message); }
  },

  // ── Conexões ──────────────────────────────────────────
  fetchConexoes: async () => {
    get().setLoading('conexoes', true);
    try {
      const res = await conexoesService.list();
      set(s => ({ data: { ...s.data, conexoes: res } }));
    } catch (e) { get().notify('Erro ao carregar conexões'); }
    finally { get().setLoading('conexoes', false); }
  },
  addConexao: async (data) => {
    try {
      const nova = await conexoesService.create(data);
      set(s => ({ data: { ...s.data, conexoes: [...s.data.conexoes, nova] } }));
      get().notify('Conexão criada'); return nova;
    } catch (e) { get().notify(e.message); throw e; }
  },
  removeConexao: async (id) => {
    try {
      await conexoesService.remove(id);
      set(s => ({ data: { ...s.data, conexoes: s.data.conexoes.filter(c => c.id !== id) } }));
      get().notify('Conexão removida');
    } catch (e) { get().notify(e.message); }
  },

  // ── Automações ────────────────────────────────────────
  fetchAutomacoes: async () => {
    get().setLoading('automacoes', true);
    try {
      const res = await automacoesService.list();
      set(s => ({ data: { ...s.data, automacoes: res } }));
    } catch (e) { get().notify('Erro ao carregar automações'); }
    finally { get().setLoading('automacoes', false); }
  },

  // ── Base de IA ────────────────────────────────────────
  fetchKb: async () => {
    get().setLoading('kb', true);
    try {
      const res = await kbService.list();
      set(s => ({ data: { ...s.data, kb: res } }));
    } catch (e) { get().notify('Erro ao carregar base de IA'); }
    finally { get().setLoading('kb', false); }
  },
  addKbDoc: async (data) => {
    try {
      const novo = await kbService.create(data);
      set(s => ({ data: { ...s.data, kb: [novo, ...s.data.kb] } }));
      get().notify('Documento adicionado'); return novo;
    } catch (e) { get().notify(e.message); throw e; }
  },
  testKb: async (pergunta) => {
    try { return await kbService.test(pergunta); }
    catch (e) { get().notify(e.message); throw e; }
  },
}));
