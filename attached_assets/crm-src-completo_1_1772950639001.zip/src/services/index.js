import { api } from './api';

// ── Auth ──────────────────────────────────────────────────
export const authService = {
  login:       (email, senha)    => api.post('/auth/login', { email, senha }),
  me:          ()                => api.get('/auth/me'),
  updateMe:    (data)            => api.put('/auth/me', data),
  updateSenha: (senhaAtual, novaSenha) => api.put('/auth/senha', { senhaAtual, novaSenha }),
};

// ── Leads ─────────────────────────────────────────────────
export const leadsService = {
  list:       (params = {})   => api.get('/leads?' + new URLSearchParams(params)),
  get:        (id)            => api.get(`/leads/${id}`),
  create:     (data)          => api.post('/leads', data),
  update:     (id, data)      => api.put(`/leads/${id}`, data),
  remove:     (id)            => api.delete(`/leads/${id}`),
  addNota:    (id, conteudo)  => api.post(`/leads/${id}/notas`, { conteudo }),
};

// ── Contatos ──────────────────────────────────────────────
export const contatosService = {
  list:   (params = {}) => api.get('/contatos?' + new URLSearchParams(params)),
  get:    (id)          => api.get(`/contatos/${id}`),
  create: (data)        => api.post('/contatos', data),
  update: (id, data)    => api.put(`/contatos/${id}`, data),
  remove: (id)          => api.delete(`/contatos/${id}`),
};

// ── Conversas / Inbox ─────────────────────────────────────
export const conversationsService = {
  list:        (params = {})  => api.get('/conversations?' + new URLSearchParams(params)),
  get:         (id)           => api.get(`/conversations/${id}`),
  create:      (data)         => api.post('/conversations', data),
  update:      (id, data)     => api.put(`/conversations/${id}`, data),
  sendMessage: (id, txt)      => api.post(`/conversations/${id}/messages`, { txt }),
  resolve:     (id)           => api.post(`/conversations/${id}/resolve`),
};

// ── Campanhas ─────────────────────────────────────────────
export const campanhasService = {
  list:   ()           => api.get('/campanhas'),
  get:    (id)         => api.get(`/campanhas/${id}`),
  create: (data)       => api.post('/campanhas', data),
  update: (id, data)   => api.put(`/campanhas/${id}`, data),
  remove: (id)         => api.delete(`/campanhas/${id}`),
};

// ── Agenda ────────────────────────────────────────────────
export const agendaService = {
  list:   (params = {}) => api.get('/agenda?' + new URLSearchParams(params)),
  create: (data)        => api.post('/agenda', data),
  update: (id, data)    => api.put(`/agenda/${id}`, data),
  remove: (id)          => api.delete(`/agenda/${id}`),
};

// ── Financeiro ────────────────────────────────────────────
export const financeiroService = {
  list:   (params = {}) => api.get('/financeiro?' + new URLSearchParams(params)),
  create: (data)        => api.post('/financeiro', data),
  update: (id, data)    => api.put(`/financeiro/${id}`, data),
  remove: (id)          => api.delete(`/financeiro/${id}`),
};

// ── Usuários ──────────────────────────────────────────────
export const usuariosService = {
  list:   ()             => api.get('/usuarios'),
  invite: (data)         => api.post('/usuarios/invite', data),
  update: (id, data)     => api.put(`/usuarios/${id}`, data),
  remove: (id)           => api.delete(`/usuarios/${id}`),
};

// ── Billing ───────────────────────────────────────────────
export const billingService = {
  get:     ()         => api.get('/billing'),
  upgrade: (planId)   => api.post('/billing/upgrade', { planId }),
};

// ── Conexões ──────────────────────────────────────────────
export const conexoesService = {
  list:   ()       => api.get('/conexoes'),
  create: (data)   => api.post('/conexoes', data),
  remove: (id)     => api.delete(`/conexoes/${id}`),
};

// ── Automações ────────────────────────────────────────────
export const automacoesService = {
  list:   ()           => api.get('/automacoes'),
  get:    (id)         => api.get(`/automacoes/${id}`),
  create: (data)       => api.post('/automacoes', data),
  update: (id, data)   => api.put(`/automacoes/${id}`, data),
  remove: (id)         => api.delete(`/automacoes/${id}`),
};

// ── Base de Conhecimento / IA ─────────────────────────────
export const kbService = {
  list:   ()              => api.get('/kb'),
  create: (data)          => api.post('/kb', data),
  remove: (id)            => api.delete(`/kb/${id}`),
  test:   (pergunta)      => api.post('/kb/test', { pergunta }),
};

// ── Relatórios ────────────────────────────────────────────
export const relatoriosService = {
  resumo: () => api.get('/relatorios/resumo'),
};
