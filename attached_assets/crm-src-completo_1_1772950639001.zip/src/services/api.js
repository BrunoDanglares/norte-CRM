// Base URL da API — em produção mude para https://api.seudominio.com
const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// Chave para guardar o token no localStorage
const TOKEN_KEY = 'crm_token';

// ── Token helpers ──────────────────────────────────────────
export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function removeToken() {
  localStorage.removeItem(TOKEN_KEY);
}

// ── Função base de fetch ───────────────────────────────────
async function request(method, path, body = null) {
  const token = getToken();

  const headers = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
  };

  const config = {
    method,
    headers,
    ...(body && { body: JSON.stringify(body) }),
  };

  const res = await fetch(`${API_BASE}${path}`, config);

  // Token expirado → redirecionar para login
  if (res.status === 401) {
    removeToken();
    window.location.reload();
    throw new Error('Sessão expirada');
  }

  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.error || `Erro ${res.status}`);
  }

  return data;
}

// ── Métodos HTTP ───────────────────────────────────────────
export const api = {
  get:    (path)         => request('GET',    path),
  post:   (path, body)   => request('POST',   path, body),
  put:    (path, body)   => request('PUT',    path, body),
  delete: (path)         => request('DELETE', path),
};
