import { useState } from 'react';
import { authService } from '../../services';
import { setToken } from '../../services/api';

export default function Login({ onLogin }) {
  const [email, setEmail]     = useState('joao@empresa.com');
  const [senha, setSenha]     = useState('senha123');
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { token, user } = await authService.login(email, senha);
      setToken(token);
      onLogin(user);
    } catch (err) {
      setError(err.message || 'Credenciais inválidas');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)',
    }}>
      <div style={{ width: 380 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14,
            background: 'linear-gradient(135deg,#7c5cbf,#9b7ee0)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 24, fontWeight: 900, color: '#fff', margin: '0 auto 12px',
          }}>C</div>
          <h1 style={{ fontSize: 22, fontWeight: 900 }}>CRM SaaS Pro</h1>
          <p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 4 }}>Faça login para continuar</p>
        </div>

        {/* Form */}
        <div className="card" style={{ padding: 28 }}>
          <form onSubmit={handleSubmit}>
            <div className="fg">
              <label className="fl">E-mail</label>
              <input
                className="fc"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                autoFocus
              />
            </div>
            <div className="fg">
              <label className="fl">Senha</label>
              <input
                className="fc"
                type="password"
                placeholder="••••••••"
                value={senha}
                onChange={e => setSenha(e.target.value)}
                required
              />
            </div>

            {error && (
              <div style={{
                background: 'var(--redDim)', border: '1px solid #f8717130',
                borderRadius: 8, padding: '9px 12px', marginBottom: 14,
                fontSize: 12.5, color: 'var(--red)',
              }}>
                ⚠️ {error}
              </div>
            )}

            <button
              type="submit"
              className="btn-primary"
              style={{ width: '100%', justifyContent: 'center', padding: '10px', fontSize: 13.5 }}
              disabled={loading}
            >
              {loading ? '⏳ Entrando...' : '🔒 Entrar'}
            </button>
          </form>

          <div style={{ marginTop: 16, textAlign: 'center', fontSize: 11.5, color: 'var(--muted)' }}>
            Login padrão: joao@empresa.com / senha123
          </div>
        </div>
      </div>
    </div>
  );
}
