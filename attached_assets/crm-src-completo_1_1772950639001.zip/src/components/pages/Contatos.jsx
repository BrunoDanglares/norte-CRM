import { useState, useMemo } from 'react';
import { useStore } from '../../store/useStore';

const PER_PAGE = 15;
function fmt(n) { return (+n).toLocaleString('pt-BR'); }
function cIco(c) { return {WhatsApp:'💚',Instagram:'📸',Chat:'💬',Email:'📧'}[c]||'💬'; }

function ContatoModal({ ct, onClose, onSave, onDelete }) {
  const isNew = !ct?.id;
  const [form, setForm] = useState({
    nome: ct?.nome || '',
    empresa: ct?.empresa || '',
    phone: ct?.phone || '',
    email: ct?.email || '',
    canal: ct?.canal || 'WhatsApp',
    tags: (ct?.tags||[]).join(', '),
    obs: ct?.obs || '',
  });
  const f = k => e => setForm(p=>({ ...p, [k]:e.target.value }));
  return (
    <div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal">
        <div className="m-head">
          <div className="m-title">{isNew ? '+ Novo Contato' : `✏️ ${ct.nome}`}</div>
          <button className="m-close" onClick={onClose}>✕</button>
        </div>
        <div className="m-body">
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            <div className="fg">
              <label className="fl">Nome completo *</label>
              <input className="fc" value={form.nome} onChange={f('nome')} placeholder="Nome do contato" autoFocus />
            </div>
            <div className="fg">
              <label className="fl">Empresa</label>
              <input className="fc" value={form.empresa} onChange={f('empresa')} placeholder="Nome da empresa" />
            </div>
            <div className="fg">
              <label className="fl">Telefone (WhatsApp)</label>
              <input className="fc" value={form.phone} onChange={f('phone')} placeholder="+55 11 99999-0000" />
            </div>
            <div className="fg">
              <label className="fl">Email</label>
              <input className="fc" type="email" value={form.email} onChange={f('email')} placeholder="email@empresa.com" />
            </div>
            <div className="fg">
              <label className="fl">Canal principal</label>
              <select className="fc" value={form.canal} onChange={f('canal')}>
                {['WhatsApp','Instagram','Email','Chat'].map(ch=><option key={ch}>{ch}</option>)}
              </select>
            </div>
            <div className="fg">
              <label className="fl">Tags</label>
              <input className="fc" value={form.tags} onChange={f('tags')} placeholder="cliente, lead-quente, parceiro" />
            </div>
            <div className="fg" style={{ gridColumn:'1/-1' }}>
              <label className="fl">Anotações</label>
              <textarea className="fc" rows={2} value={form.obs} onChange={f('obs')} placeholder="Notas sobre o contato…" />
            </div>
          </div>
          <div style={{ marginTop:14, display:'flex', justifyContent:'space-between' }}>
            <div>
              {!isNew && <button className="btn btn-ghost btn-sm" style={{ color:'#ef4444' }} onClick={()=>{ onDelete(ct); onClose(); }}>🗑 Excluir</button>}
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <button className="btn btn-ghost" onClick={onClose}>Cancelar</button>
              <button className="btn-primary" onClick={()=>onSave({ ...form, tags: form.tags.split(',').map(t=>t.trim()).filter(Boolean) })}>💾 Salvar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ImportModal({ onClose }) {
  return (
    <div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal">
        <div className="m-head">
          <div className="m-title">↑ Importar Contatos via CSV</div>
          <button className="m-close" onClick={onClose}>✕</button>
        </div>
        <div className="m-body">
          <div style={{ border:'2px dashed var(--border)', borderRadius:12, padding:'30px', textAlign:'center', marginBottom:16 }}>
            <div style={{ fontSize:32, marginBottom:8 }}>📂</div>
            <div style={{ fontSize:13, fontWeight:700 }}>Arraste um arquivo CSV aqui</div>
            <div style={{ fontSize:11.5, color:'var(--muted)', marginTop:4 }}>ou</div>
            <button className="btn-primary btn-sm" style={{ marginTop:10 }}>Selecionar arquivo</button>
          </div>
          <div style={{ background:'var(--card2)', borderRadius:8, padding:12, fontSize:11.5, color:'var(--muted2)' }}>
            <strong>Formato esperado:</strong><br/>
            <code style={{ fontSize:10.5 }}>nome,empresa,telefone,email,canal,tags</code><br/>
            <code style={{ fontSize:10.5 }}>João Silva,Acme,+5511999990001,j@acme.com,WhatsApp,cliente</code>
          </div>
          <div style={{ marginTop:14, display:'flex', justifyContent:'flex-end' }}>
            <button className="btn btn-ghost" onClick={onClose}>Fechar</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Contatos() {
  const contatos = useStore(s => s.data.contatos) || [];
  const addContato = useStore(s => s.addContato);
  const notify = useStore(s => s.notify);
  const setPage = useStore(s => s.setPage);

  const [search, setSearch] = useState('');
  const [filterTag, setFilterTag] = useState('');
  const [filterCanal, setFilterCanal] = useState('');
  const [page, setPage2] = useState(1);
  const [modal, setModal] = useState(null);

  // All unique tags
  const allTags = useMemo(() => {
    const t = new Set();
    contatos.forEach(c => (c.tags||[]).forEach(tag=>t.add(tag)));
    return [...t];
  }, [contatos]);

  const filtered = useMemo(() => {
    let f = [...contatos];
    if (search) f = f.filter(c => c.nome?.toLowerCase().includes(search.toLowerCase()) || (c.empresa||'').toLowerCase().includes(search.toLowerCase()) || (c.phone||'').includes(search) || (c.email||'').toLowerCase().includes(search.toLowerCase()));
    if (filterTag) f = f.filter(c => (c.tags||[]).includes(filterTag));
    if (filterCanal) f = f.filter(c => c.canal === filterCanal);
    return f;
  }, [contatos, search, filterTag, filterCanal]);

  const pages = Math.ceil(filtered.length / PER_PAGE);
  const pageData = filtered.slice((page-1)*PER_PAGE, page*PER_PAGE);

  function handleSave(form) {
    if (!form.nome) return notify('⚠️ Preencha o nome');
    if (modal?.ct?.id) {
      notify('✅ Contato atualizado!');
    } else {
      addContato({ ...form, data: new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'}) });
      notify('✅ Contato criado!');
    }
    setModal(null);
  }

  function handleDelete(ct) {
    notify('🗑 Contato excluído');
    setModal(null);
  }

  function exportCSV() {
    const rows = [['Nome','Empresa','Telefone','Email','Canal','Tags']];
    contatos.forEach(c => rows.push([c.nome,c.empresa||'',c.phone||'',c.email||'',c.canal,(c.tags||[]).join(';')]));
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,'+encodeURIComponent(rows.map(r=>r.join(',')).join('\n'));
    a.download = 'contatos.csv'; a.click();
    notify('📥 Contatos exportados!');
  }

  return (
    <div style={{ padding:0, height:'100%', display:'flex', flexDirection:'column' }}>
      {/* Toolbar */}
      <div style={{ padding:'12px 18px', borderBottom:'1px solid var(--border)', display:'flex', gap:8, alignItems:'center', flexWrap:'wrap', flexShrink:0 }}>
        <div className="search-wrap" style={{ flex:1, minWidth:180 }}>
          <span className="search-icon">⌕</span>
          <input placeholder="Buscar contatos…" value={search} onChange={e=>{ setSearch(e.target.value); setPage2(1); }} />
        </div>
        <select className="fc" style={{ width:145 }} value={filterTag} onChange={e=>{ setFilterTag(e.target.value); setPage2(1); }}>
          <option value="">Todas as tags</option>
          {allTags.map(t=><option key={t}>{t}</option>)}
        </select>
        <select className="fc" style={{ width:140 }} value={filterCanal} onChange={e=>{ setFilterCanal(e.target.value); setPage2(1); }}>
          <option value="">Todos os canais</option>
          <option>WhatsApp</option><option>Instagram</option><option>Email</option><option>Chat</option>
        </select>
        <button className="btn btn-ghost btn-sm" onClick={()=>setModal({ type:'import' })}>↑ Importar CSV</button>
        <button className="btn btn-ghost btn-sm" onClick={exportCSV}>↓ Exportar</button>
        <button className="btn-primary btn-sm" onClick={()=>setModal({ type:'edit', ct:null })}>+ Novo Contato</button>
      </div>

      {/* Stats bar */}
      <div style={{ display:'flex', borderBottom:'1px solid var(--border)', flexShrink:0 }}>
        {[
          { l:'Total',     v:contatos.length,                                         c:'var(--accent3)' },
          { l:'WhatsApp',  v:contatos.filter(c=>c.canal==='WhatsApp').length,         c:'var(--green)' },
          { l:'Instagram', v:contatos.filter(c=>c.canal==='Instagram').length,        c:'#e1306c' },
          { l:'Email',     v:contatos.filter(c=>c.canal==='Email').length,            c:'var(--blue)' },
          { l:'Com tag',   v:contatos.filter(c=>(c.tags||[]).length>0).length,        c:'var(--yellow)' },
        ].map((s,i) => (
          <div key={i} style={{ flex:1, padding:'8px 14px', borderRight: i<4?'1px solid var(--border)':'none', textAlign:'center' }}>
            <div style={{ fontSize:16, fontWeight:900, color:s.c }}>{s.v}</div>
            <div style={{ fontSize:10, color:'var(--muted)' }}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div style={{ flex:1, overflowY:'auto' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead style={{ position:'sticky', top:0, background:'var(--card2)', zIndex:1 }}>
            <tr style={{ borderBottom:'1.5px solid var(--border)' }}>
              <th style={{ textAlign:'left', padding:'10px 16px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>CONTATO</th>
              <th style={{ textAlign:'left', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>EMPRESA</th>
              <th style={{ textAlign:'left', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>TELEFONE</th>
              <th style={{ textAlign:'left', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>EMAIL</th>
              <th style={{ textAlign:'center', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>CANAL</th>
              <th style={{ textAlign:'left', padding:'10px 10px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>TAGS</th>
              <th style={{ padding:'10px 14px', fontSize:11, fontWeight:700, color:'var(--muted)' }}>AÇÕES</th>
            </tr>
          </thead>
          <tbody>
            {pageData.map((ct, i) => (
              <tr key={ct.id||i} style={{ borderBottom:'1px solid var(--border)', transition:'background .12s' }}
                onMouseEnter={e=>e.currentTarget.style.background='var(--card2)'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{ padding:'10px 16px', cursor:'pointer' }} onClick={()=>setModal({ type:'edit', ct })}>
                  <div style={{ display:'flex', alignItems:'center', gap:9 }}>
                    <div className="ava" style={{ width:30, height:30, fontSize:11, borderRadius:9, flexShrink:0 }}>{ct.nome?.[0]||'?'}</div>
                    <div>
                      <div style={{ fontWeight:700, fontSize:13 }}>{ct.nome}</div>
                      <div style={{ fontSize:10, color:'var(--muted)' }}>Adicionado: {ct.data||'—'}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding:'10px 10px', fontSize:12, color:'var(--muted2)' }}>{ct.empresa||'—'}</td>
                <td style={{ padding:'10px 10px' }}>
                  {ct.phone
                    ? <a href={`https://wa.me/${ct.phone.replace(/\D/g,'')}`} target="_blank" rel="noreferrer"
                        style={{ color:'var(--green)', textDecoration:'none', fontFamily:'monospace', fontSize:11.5 }}>{ct.phone}</a>
                    : <span style={{ color:'var(--muted)' }}>—</span>}
                </td>
                <td style={{ padding:'10px 10px', fontSize:12, color:'var(--accent3)' }}>{ct.email||'—'}</td>
                <td style={{ padding:'10px 10px', textAlign:'center', fontSize:18 }}>{cIco(ct.canal)}</td>
                <td style={{ padding:'10px 10px' }}>
                  {(ct.tags||[]).map(t => (
                    <span key={t} className="tag" style={{ cursor:'pointer' }} onClick={()=>setFilterTag(filterTag===t?'':t)}>{t}</span>
                  ))}
                </td>
                <td style={{ padding:'10px 14px' }}>
                  <div style={{ display:'flex', gap:4 }}>
                    <button className="btn btn-ghost btn-sm" title="Editar" onClick={()=>setModal({ type:'edit', ct })}>✏️</button>
                    <button className="btn btn-ghost btn-sm" title="Enviar msg" onClick={()=>setPage('inbox')}>💬</button>
                    <button className="btn btn-ghost btn-sm" title="Excluir" style={{ color:'#ef4444' }} onClick={()=>{ handleDelete(ct); }}>🗑</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div style={{ textAlign:'center', padding:'40px', color:'var(--muted)' }}>
            <div style={{ fontSize:28, marginBottom:8 }}>🔍</div>
            Nenhum contato encontrado
          </div>
        )}
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div style={{ padding:'10px 16px', borderTop:'1px solid var(--border)', display:'flex', alignItems:'center', justifyContent:'space-between', flexShrink:0, background:'var(--card2)' }}>
          <div style={{ fontSize:11.5, color:'var(--muted)' }}>
            Mostrando <strong>{(page-1)*PER_PAGE+1}–{Math.min(page*PER_PAGE, filtered.length)}</strong> de <strong>{filtered.length}</strong> contatos
          </div>
          <div style={{ display:'flex', gap:4 }}>
            <button onClick={()=>setPage2(p=>Math.max(1,p-1))} disabled={page<=1}
              style={{ padding:'4px 10px', border:'1px solid var(--border)', borderRadius:6, background:'transparent', color:'var(--muted)', cursor: page<=1?'not-allowed':'pointer', fontSize:11.5 }}>‹</button>
            {Array.from({ length:Math.min(pages,7) },(_,i)=>i+1).map(p => (
              <button key={p} onClick={()=>setPage2(p)}
                style={{ padding:'4px 10px', border:`1px solid ${p===page?'var(--accent)':'var(--border)'}`, borderRadius:6,
                  background:p===page?'var(--accent)':'transparent', color:p===page?'#fff':'var(--muted)', cursor:'pointer', fontSize:11.5 }}>{p}</button>
            ))}
            {pages > 7 && <span style={{ padding:'4px 6px', color:'var(--muted)', fontSize:11 }}>…{pages}</span>}
            <button onClick={()=>setPage2(p=>Math.min(pages,p+1))} disabled={page>=pages}
              style={{ padding:'4px 10px', border:'1px solid var(--border)', borderRadius:6, background:'transparent', color:'var(--muted)', cursor: page>=pages?'not-allowed':'pointer', fontSize:11.5 }}>›</button>
          </div>
        </div>
      )}

      {/* Modals */}
      {modal?.type === 'edit' && (
        <ContatoModal ct={modal.ct} onClose={()=>setModal(null)} onSave={handleSave} onDelete={handleDelete} />
      )}
      {modal?.type === 'import' && (
        <ImportModal onClose={()=>setModal(null)} />
      )}
    </div>
  );
}
