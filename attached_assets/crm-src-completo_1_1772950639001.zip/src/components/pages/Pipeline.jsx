import { useState } from 'react';
import { useStore } from '../../store/useStore';

const STAGES = {
  novo:       { label:'Novo',        color:'#60a5fa' },
  contatado:  { label:'Contatado',   color:'#818cf8' },
  qualificado:{ label:'Qualificado', color:'#a78bfa' },
  proposta:   { label:'Proposta',    color:'#c084fc' },
  negociacao: { label:'Negociação',  color:'#f59e0b' },
  ganho:      { label:'Ganho',       color:'#34d399' },
  perdido:    { label:'Perdido',     color:'#f87171' },
};

function fmt(n) { return (+n).toLocaleString('pt-BR'); }
function cIco(c) { return {WhatsApp:'💚',Instagram:'📸',Chat:'💬',Email:'📧'}[c]||'💬'; }

function QuickEditModal({ lead, onClose, onSave, onDelete, onInbox, onAgenda, onEditFull, usuarios }) {
  const [stage, setStage] = useState(lead.status);
  const [valor, setValor] = useState(lead.valor);
  const [owner, setOwner] = useState(lead.owner);

  const acts = [
    { icon:'🆕', txt:`Lead criado — canal ${lead.canal}`, time:'há 12 dias' },
    { icon:'📞', txt:'Primeiro contato realizado', time:'há 10 dias' },
    { icon:'📧', txt:'Proposta enviada por email', time:'há 5 dias' },
    { icon:'💬', txt:'Follow-up via WhatsApp', time:'há 2 dias' },
    { icon:'🔄', txt:`Movido para ${STAGES[lead.status]?.label||lead.status}`, time:'hoje' },
  ];

  return (
    <div className="overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal">
        <div className="m-head">
          <div className="m-title">📋 {lead.nome}</div>
          <button className="m-close" onClick={onClose}>✕</button>
        </div>
        <div className="m-body">
          <div style={{ background:'var(--card2)', borderRadius:10, padding:12, display:'flex', gap:12, alignItems:'center', marginBottom:14 }}>
            <div style={{ fontSize:28 }}>{cIco(lead.canal)}</div>
            <div>
              <div style={{ fontSize:15, fontWeight:800 }}>{lead.nome}</div>
              <div style={{ fontSize:11.5, color:'var(--muted2)' }}>{lead.contato}</div>
            </div>
            <div style={{ marginLeft:'auto', textAlign:'right' }}>
              <div style={{ fontSize:18, fontWeight:900, color:'var(--green)' }}>R$ {fmt(lead.valor)}</div>
              <div style={{ fontSize:10, color:'var(--muted)' }}>{lead.data}</div>
            </div>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:14 }}>
            <div className="fg" style={{ gridColumn:'1/-1' }}>
              <label className="fl">Etapa atual</label>
              <select className="fc" value={stage} onChange={e=>setStage(e.target.value)}>
                {Object.entries(STAGES).map(([k,s]) => <option key={k} value={k}>{s.label}</option>)}
              </select>
            </div>
            <div className="fg">
              <label className="fl">Valor (R$)</label>
              <input className="fc" type="number" value={valor} onChange={e=>setValor(e.target.value)} />
            </div>
            <div className="fg">
              <label className="fl">Responsável</label>
              <select className="fc" value={owner} onChange={e=>setOwner(e.target.value)}>
                {(usuarios||[]).map(u => <option key={u.nome}>{u.nome}</option>)}
              </select>
            </div>
          </div>

          <div style={{ background:'var(--card2)', borderRadius:10, padding:12, marginBottom:14 }}>
            <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', marginBottom:10 }}>📋 HISTÓRICO DE ATIVIDADES</div>
            {acts.map((a,i) => (
              <div key={i} style={{ display:'flex', gap:10, padding:'6px 0', borderBottom:'1px solid var(--border)', alignItems:'flex-start' }}>
                <span style={{ fontSize:14, flexShrink:0 }}>{a.icon}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:12 }}>{a.txt}</div>
                  <div style={{ fontSize:10, color:'var(--muted)', marginTop:1 }}>{a.time}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:14 }}>
            <button className="btn btn-ghost btn-sm" onClick={onInbox}>💬 Abrir Inbox</button>
            <button className="btn btn-ghost btn-sm" onClick={onAgenda}>📅 Agendar</button>
            <button className="btn btn-ghost btn-sm" onClick={onEditFull}>✏️ Editar completo</button>
          </div>

          <div style={{ display:'flex', justifyContent:'space-between' }}>
            <button className="btn btn-ghost btn-sm" style={{ color:'#ef4444' }} onClick={()=>{ onDelete(lead); onClose(); }}>🗑 Excluir</button>
            <div style={{ display:'flex', gap:8 }}>
              <button className="btn btn-ghost" onClick={onClose}>Cancelar</button>
              <button className="btn-primary" onClick={()=>onSave({ status:stage, valor:parseFloat(valor)||lead.valor, owner })}>💾 Salvar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Pipeline() {
  const leads = useStore(s => s.data.leads) || [];
  const usuarios = useStore(s => s.data.usuarios) || [];
  const updateLead = useStore(s => s.updateLead);
  const deleteLead = useStore(s => s.deleteLead);
  const notify = useStore(s => s.notify);
  const setPage = useStore(s => s.setPage);

  const [filterOwner, setFilterOwner] = useState('');
  const [modal, setModal] = useState(null);
  const [dragIdx, setDragIdx] = useState(null);
  const [dragOver, setDragOver] = useState(null);

  const totalValue = leads.filter(l=>!['ganho','perdido'].includes(l.status)).reduce((a,l)=>a+(l.valor||0),0);
  const wonValue   = leads.filter(l=>l.status==='ganho').reduce((a,l)=>a+(l.valor||0),0);
  const winRate    = leads.length>0 ? Math.round(leads.filter(l=>l.status==='ganho').length/leads.length*100) : 0;

  const visibleLeads = filterOwner ? leads.filter(l=>l.owner===filterOwner) : leads;

  function onDragStart(e, idx) {
    setDragIdx(idx);
    e.dataTransfer.setData('text/plain', String(idx));
    e.dataTransfer.effectAllowed = 'move';
  }
  function onDragEnd() { setDragIdx(null); setDragOver(null); }
  function onDragOver(e, k) { e.preventDefault(); setDragOver(k); }
  function onDragLeave() { setDragOver(null); }
  function onDrop(e, k) {
    e.preventDefault();
    const idx = dragIdx ?? parseInt(e.dataTransfer.getData('text/plain'));
    const lead = leads[idx];
    if (!lead || lead.status === k) { setDragIdx(null); setDragOver(null); return; }
    updateLead(lead.id, { status: k });
    notify(`✅ ${lead.nome} → ${STAGES[k].label}`);
    setDragIdx(null); setDragOver(null);
  }

  return (
    <div style={{ padding:0, height:'100%', display:'flex', flexDirection:'column' }}>
      {/* Header */}
      <div style={{ padding:'12px 18px', borderBottom:'1px solid var(--border)', display:'flex', gap:10, alignItems:'center', flexShrink:0, flexWrap:'wrap' }}>
        <div style={{ display:'flex', gap:8, flex:1, flexWrap:'wrap' }}>
          <select className="fc" style={{ width:155 }}>
            <option>Todos os nichos</option><option>Imobiliária</option><option>Saúde</option><option>Tecnologia</option>
          </select>
          <select className="fc" style={{ width:155 }} value={filterOwner} onChange={e=>setFilterOwner(e.target.value)}>
            <option value="">Todos os responsáveis</option>
            {usuarios.map(u => <option key={u.nome} value={u.nome}>{u.nome.split(' ')[0]}</option>)}
          </select>
          <select className="fc" style={{ width:140 }}>
            <option>Este mês</option><option>Últimos 30d</option><option>Último trimestre</option><option>Este ano</option>
          </select>
        </div>

        {/* KPI strip */}
        <div style={{ display:'flex', gap:16, fontSize:11.5, padding:'4px 12px', background:'var(--card2)', border:'1px solid var(--border)', borderRadius:9 }}>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontWeight:900, color:'var(--accent3)', fontSize:14 }}>R${fmt(totalValue)}</div>
            <div style={{ color:'var(--muted)', fontSize:10 }}>Em aberto</div>
          </div>
          <div style={{ textAlign:'center', borderLeft:'1px solid var(--border)', paddingLeft:16 }}>
            <div style={{ fontWeight:900, color:'var(--green)', fontSize:14 }}>R${fmt(wonValue)}</div>
            <div style={{ color:'var(--muted)', fontSize:10 }}>Ganhos</div>
          </div>
          <div style={{ textAlign:'center', borderLeft:'1px solid var(--border)', paddingLeft:16 }}>
            <div style={{ fontWeight:900, color:'var(--accent3)', fontSize:14 }}>{winRate}%</div>
            <div style={{ color:'var(--muted)', fontSize:10 }}>Win rate</div>
          </div>
          <div style={{ textAlign:'center', borderLeft:'1px solid var(--border)', paddingLeft:16 }}>
            <div style={{ fontWeight:900, color:'var(--yellow)', fontSize:14 }}>18d</div>
            <div style={{ color:'var(--muted)', fontSize:10 }}>Ciclo médio</div>
          </div>
        </div>
        <button className="btn-primary btn-sm" onClick={()=>setModal({ type:'new' })}>+ Novo Deal</button>
      </div>

      {/* Drag hint */}
      <div style={{ padding:'5px 18px', background:'var(--accentBg)', borderBottom:'1px solid var(--accentBd)', fontSize:10.5, color:'var(--accent3)', flexShrink:0 }}>
        💡 Arraste os cards entre colunas para mover o deal de etapa
      </div>

      {/* Kanban */}
      <div style={{ flex:1, overflowX:'auto', overflowY:'hidden', padding:16 }}>
        <div style={{ display:'flex', gap:12, minWidth:'max-content', height:'100%' }}>
          {Object.entries(STAGES).map(([k,s]) => {
            const colLeads = visibleLeads.filter(l=>l.status===k);
            const colTotal = colLeads.reduce((a,l)=>a+(l.valor||0),0);
            const isOver = dragOver === k;
            return (
              <div key={k} style={{ minWidth:230, maxWidth:230, height:'100%', display:'flex', flexDirection:'column' }}
                onDragOver={e=>onDragOver(e,k)} onDragLeave={onDragLeave} onDrop={e=>onDrop(e,k)}>
                <div style={{ background: isOver?'var(--accentBg)':'var(--card2)', border:`1px solid ${isOver?'var(--accent)':'var(--border)'}`,
                  borderTop:`3px solid ${s.color}`, borderRadius:12, height:'100%', display:'flex', flexDirection:'column', overflow:'hidden', transition:'all .15s' }}>
                  <div style={{ padding:'11px 13px', borderBottom:'1px solid var(--border)', flexShrink:0 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
                      <span style={{ color:s.color, fontWeight:800, fontSize:12 }}>{s.label}</span>
                      <span style={{ fontSize:10, fontWeight:600, background:'var(--card3)', padding:'2px 8px', borderRadius:20, color:'var(--muted2)' }}>{colLeads.length}</span>
                    </div>
                    <div style={{ fontSize:10.5, color:'var(--muted2)' }}>R$ {fmt(colTotal)}</div>
                  </div>
                  <div style={{ flex:1, overflowY:'auto', padding:9, display:'flex', flexDirection:'column', gap:7 }}>
                    {colLeads.map(l => {
                      const idx = leads.indexOf(l);
                      const days = Math.floor(Math.random()*25)+1;
                      const isOld = days > 14;
                      return (
                        <div key={l.id} draggable
                          onDragStart={e=>onDragStart(e,idx)}
                          onDragEnd={onDragEnd}
                          onClick={()=>setModal({ type:'quickedit', lead:l })}
                          style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:9, padding:'10px 12px',
                            cursor:'grab', userSelect:'none', transition:'all .15s', opacity: dragIdx===idx?0.4:1 }}
                          onMouseEnter={e=>{ e.currentTarget.style.borderColor='var(--border2)'; e.currentTarget.style.transform='translateY(-1px)'; }}
                          onMouseLeave={e=>{ e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.transform='none'; }}>
                          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5, alignItems:'flex-start' }}>
                            <div style={{ flex:1, minWidth:0, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', fontSize:12.5, fontWeight:600 }}>{l.nome}</div>
                            <span style={{ fontSize:15, flexShrink:0, marginLeft:4 }}>{cIco(l.canal)}</span>
                          </div>
                          <div style={{ fontSize:10.5, color:'var(--muted2)', marginBottom:6 }}>{l.contato}</div>
                          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:8 }}>
                            <div style={{ fontSize:13, fontWeight:700, color:'var(--green)' }}>R$ {fmt(l.valor||0)}</div>
                            <div className="ava" style={{ width:22, height:22, fontSize:9, borderRadius:6 }} title={l.owner}>{(l.owner||'?')[0]}</div>
                          </div>
                          <div style={{ display:'flex', justifyContent:'space-between', marginTop:7, fontSize:10, color: isOld?'#f87171':'var(--muted)' }}>
                            <span>📅 {l.data}</span>
                            <span style={{ fontWeight: isOld?700:400 }}>{days}d na etapa{isOld?' ⚠️':''}</span>
                          </div>
                        </div>
                      );
                    })}
                    <button onClick={()=>setModal({ type:'new', defaultStatus:k })}
                      style={{ width:'100%', padding:8, border:'1.5px dashed var(--border)', borderRadius:8, background:'transparent', color:'var(--muted)', fontSize:11.5, cursor:'pointer', marginTop:4 }}
                      onMouseEnter={e=>e.currentTarget.style.borderColor='var(--accent)'}
                      onMouseLeave={e=>e.currentTarget.style.borderColor='var(--border)'}>
                      + Adicionar deal
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Edit Modal */}
      {modal?.type === 'quickedit' && (
        <QuickEditModal
          lead={modal.lead} usuarios={usuarios}
          onClose={()=>setModal(null)}
          onSave={(upd) => { updateLead(modal.lead.id, upd); notify('✅ Deal atualizado!'); setModal(null); }}
          onDelete={(l) => { deleteLead(l.id); notify('🗑 Deal excluído'); }}
          onInbox={() => { setPage('inbox'); setModal(null); }}
          onAgenda={() => { setPage('agenda'); setModal(null); }}
          onEditFull={() => { setPage('leads'); setModal(null); }}
        />
      )}
    </div>
  );
}
