# CRM SaaS — Backend Core

> NestJS · TypeScript · PostgreSQL · JWT · Multi-tenant

## Stack
- **Framework:** NestJS 10 + TypeScript
- **Banco:** PostgreSQL 16 com pgvector (para IA na Fase 5)
- **ORM:** TypeORM com migrations
- **Auth:** JWT (access + refresh token) + bcrypt
- **RBAC:** super_admin / admin / user
- **Upload:** AWS S3 / Cloudflare R2
- **Docs:** Swagger em `/api/docs`

## Módulos da Fase 2

| Módulo | Endpoint base | Descrição |
|---|---|---|
| Auth | `/api/v1/auth` | Login, Refresh, Logout |
| Tenants | `/api/v1/tenants` | Multi-tenant (Super Admin) |
| Usuários | `/api/v1/users` | RBAC por tenant |
| Contatos | `/api/v1/contacts` | Contatos unificados |
| Leads | `/api/v1/leads` | Pipeline + Kanban |
| Pipeline | `/api/v1/pipeline` | Stages + Deals |
| Financeiro | `/api/v1/financeiro` | Entradas/saídas/cobranças |
| Agenda | `/api/v1/agenda` | Tarefas e compromissos |
| Uploads | `/api/v1/uploads` | S3/R2 multipart |

## Quickstart

```bash
# 1. Subir banco + redis
docker-compose up -d postgres redis

# 2. Instalar dependências
npm install

# 3. Configurar variáveis
cp .env.example .env
# edite .env com suas credenciais

# 4. Rodar migrations
npm run migration:run

# 5. Iniciar em desenvolvimento
npm run start:dev
```

## Variáveis de ambiente

Veja `.env.example` para a lista completa.

## Arquitetura Multi-tenant

Cada tabela tem `tenantId` como FK para `tenants`. O JWT carrega `tenantId` no payload, e todos os services filtram automaticamente por tenant. Zero vazamento de dados entre empresas.

## Auth Flow

```
POST /api/v1/auth/login        → { accessToken, refreshToken }
POST /api/v1/auth/refresh      → { accessToken, refreshToken }
POST /api/v1/auth/logout       → 204
```

## Próximas fases
- **Fase 3:** Inbox Omnichannel (WhatsApp + Instagram + Socket.io)
- **Fase 4:** Motor de Automações (BullMQ + React Flow)
- **Fase 5:** IA + Base de Conhecimento (OpenAI + pgvector)
