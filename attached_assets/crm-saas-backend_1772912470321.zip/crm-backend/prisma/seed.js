const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed...');

  // ── Usuários ──────────────────────────────────────────
  const senhaHash = await bcrypt.hash('senha123', 10);

  const joao = await prisma.user.upsert({
    where: { email: 'joao@empresa.com' },
    update: {},
    create: {
      nome: 'João Dono',
      email: 'joao@empresa.com',
      senha: senhaHash,
      cargo: 'CEO / Fundador',
      role: 'SUPER_ADMIN',
      status: 'ATIVO',
    },
  });

  const ana = await prisma.user.upsert({
    where: { email: 'ana@empresa.com' },
    update: {},
    create: {
      nome: 'Ana Costa',
      email: 'ana@empresa.com',
      senha: senhaHash,
      cargo: 'Gerente de Vendas',
      role: 'ADMIN',
      status: 'ATIVO',
    },
  });

  const bruno = await prisma.user.upsert({
    where: { email: 'bruno@empresa.com' },
    update: {},
    create: {
      nome: 'Bruno Lima',
      email: 'bruno@empresa.com',
      senha: senhaHash,
      cargo: 'SDR',
      role: 'USER',
      status: 'ATIVO',
    },
  });

  console.log('✅ Usuários criados');

  // ── Contatos ──────────────────────────────────────────
  const contatos = await Promise.all([
    prisma.contato.create({ data: { nome: 'Carlos Silva', empresa: 'Imobiliária SP', phone: '(11) 98765-4321', email: 'carlos@imob.com', canal: 'WHATSAPP', tags: ['vip', 'imobiliária'] } }),
    prisma.contato.create({ data: { nome: 'Dra. Paula', empresa: 'Clínica Bem Estar', phone: '(11) 91234-5678', email: 'paula@clinica.com', canal: 'INSTAGRAM', tags: ['saúde'] } }),
    prisma.contato.create({ data: { nome: 'Dr. Marcos', empresa: 'JK Advocacia', phone: '(11) 93344-5566', email: 'marcos@jk.adv.br', canal: 'WHATSAPP', tags: ['jurídico'] } }),
    prisma.contato.create({ data: { nome: 'Pedro Alves', empresa: 'Academia FitLife', phone: '(11) 97788-9900', email: 'pedro@fitlife.com', canal: 'CHAT', tags: ['fitness'] } }),
    prisma.contato.create({ data: { nome: 'Marina Rocha', empresa: 'Bella Restaurante', phone: '(11) 95566-7788', email: 'marina@bella.com', canal: 'WHATSAPP', tags: ['food', 'vip'] } }),
  ]);

  console.log('✅ Contatos criados');

  // ── Leads ──────────────────────────────────────────────
  await Promise.all([
    prisma.lead.create({ data: { nome: 'Imobiliária São Paulo', contato: 'Carlos Silva', valor: 15000, status: 'PROPOSTA',    canal: 'WHATSAPP',  ownerId: ana.id,   contatoId: contatos[0].id } }),
    prisma.lead.create({ data: { nome: 'Clínica Bem Estar',     contato: 'Dra. Paula',   valor: 8500,  status: 'QUALIFICADO', canal: 'INSTAGRAM', ownerId: bruno.id, contatoId: contatos[1].id } }),
    prisma.lead.create({ data: { nome: 'Escritório JK Adv',     contato: 'Dr. Marcos',   valor: 4200,  status: 'CONTATADO',  canal: 'WHATSAPP',  ownerId: ana.id,   contatoId: contatos[2].id } }),
    prisma.lead.create({ data: { nome: 'Academia FitLife',      contato: 'Pedro Alves',  valor: 3800,  status: 'NOVO',       canal: 'CHAT',      ownerId: joao.id,  contatoId: contatos[3].id } }),
    prisma.lead.create({ data: { nome: 'Restaurante Bella',     contato: 'Marina Rocha', valor: 6200,  status: 'NEGOCIACAO', canal: 'WHATSAPP',  ownerId: bruno.id, contatoId: contatos[4].id } }),
    prisma.lead.create({ data: { nome: 'Tech Startup Alpha',    contato: 'Lucas Dev',    valor: 22000, status: 'GANHO',      canal: 'EMAIL',     ownerId: ana.id } }),
    prisma.lead.create({ data: { nome: 'Construtora Norte',     contato: 'Roberto Paz',  valor: 45000, status: 'PERDIDO',    canal: 'WHATSAPP',  ownerId: joao.id } }),
  ]);

  console.log('✅ Leads criados');

  // ── Conversas ──────────────────────────────────────────
  const conv1 = await prisma.conversation.create({
    data: {
      nome: 'Carlos Silva', phone: '+55 11 99823-4401', canal: 'WHATSAPP',
      status: 'OPEN', prioridade: 'ALTA', agenteId: ana.id,
      tags: ['lead-quente', 'proposta'], empresa: 'Imobiliária SP',
      email: 'carlos@imobsp.com', origem: 'WhatsApp Business',
      notas: 'Cliente VIP — já fechou negócio no ano passado', unread: 2,
      contatoId: contatos[0].id,
    }
  });

  await prisma.message.createMany({
    data: [
      { conversationId: conv1.id, dir: 'IN',  txt: 'Olá! Gostaria de mais detalhes sobre o plano Pro',                     hora: '09:12', status: 'READ' },
      { conversationId: conv1.id, dir: 'OUT', txt: 'Claro, Carlos! Posso enviar a proposta agora?',                         hora: '09:15', status: 'READ', agenteId: ana.id },
      { conversationId: conv1.id, dir: 'IN',  txt: 'Sim, por favor. Precisamos de algo para até 10 usuários',               hora: '09:18', status: 'READ' },
      { conversationId: conv1.id, dir: 'OUT', txt: 'Perfeito! Nosso plano Pro suporta até 10 usuários por R$ 497/mês.',     hora: '09:20', status: 'DELIVERED', agenteId: ana.id },
      { conversationId: conv1.id, dir: 'IN',  txt: 'Preciso de uma proposta atualizada',                                    hora: '14:31', status: 'READ' },
    ]
  });

  const conv2 = await prisma.conversation.create({
    data: {
      nome: 'Dra. Paula Mendes', phone: '+55 21 98741-3320', canal: 'INSTAGRAM',
      status: 'OPEN', prioridade: 'MEDIA',
      tags: ['novo', 'clinica'], empresa: 'Clínica Bem Estar',
      email: 'paula@clinicabem.com.br', origem: 'Instagram DM', unread: 1,
      contatoId: contatos[1].id,
    }
  });

  await prisma.message.createMany({
    data: [
      { conversationId: conv2.id, dir: 'IN',  txt: 'Vi vocês no Instagram! Tenho uma clínica e quero melhorar o atendimento', hora: '10:00', status: 'READ' },
      { conversationId: conv2.id, dir: 'OUT', txt: 'Oi Dra. Paula! Que ótimo! Nossa solução é perfeita para clínicas 🏥',     hora: '10:05', status: 'READ', agenteId: bruno.id },
      { conversationId: conv2.id, dir: 'IN',  txt: 'Quando podemos agendar uma demo?',                                        hora: '13:52', status: 'READ' },
    ]
  });

  console.log('✅ Conversas e mensagens criadas');

  // ── Agenda ─────────────────────────────────────────────
  await prisma.agendaItem.createMany({
    data: [
      { titulo: 'Call com Carlos Silva',     tipo: 'LIGACAO',  hora: '09:00', data: 'Hoje',   status: 'AGENDADO', lead: 'Imobiliária SP', userId: ana.id },
      { titulo: 'Demo Clínica Bem Estar',    tipo: 'REUNIAO',  hora: '11:00', data: 'Hoje',   status: 'AGENDADO', lead: 'Clínica Bem Estar', userId: bruno.id },
      { titulo: 'Follow-up Escritório JK',   tipo: 'FOLLOWUP', hora: '14:00', data: 'Hoje',   status: 'FEITO',    lead: 'Escritório JK Adv', userId: ana.id },
      { titulo: 'Proposta Academia FitLife', tipo: 'TAREFA',   hora: '16:00', data: 'Amanhã', status: 'AGENDADO', lead: 'Academia FitLife', userId: joao.id },
      { titulo: 'Reunião interna comercial', tipo: 'REUNIAO',  hora: '08:30', data: 'Amanhã', status: 'AGENDADO', lead: '—', userId: joao.id },
    ]
  });

  console.log('✅ Agenda criada');

  // ── Financeiro ─────────────────────────────────────────
  await prisma.lancamento.createMany({
    data: [
      { desc: 'Assinatura Tech Alpha',      tipo: 'ENTRADA', valor: 22000, status: 'PAGO',     data: '01/03', cat: 'Vendas' },
      { desc: 'Plano Pro — Imobiliária SP', tipo: 'ENTRADA', valor: 497,   status: 'PENDENTE', data: '05/03', cat: 'Assinatura' },
      { desc: 'Servidor AWS',               tipo: 'SAIDA',   valor: 380,   status: 'PAGO',     data: '01/03', cat: 'Infra' },
      { desc: 'Marketing Digital',          tipo: 'SAIDA',   valor: 1200,  status: 'PAGO',     data: '28/02', cat: 'Marketing' },
      { desc: 'Comissão vendedor',          tipo: 'SAIDA',   valor: 800,   status: 'PENDENTE', data: '10/03', cat: 'RH' },
      { desc: 'Plano Starter — Academia',   tipo: 'ENTRADA', valor: 197,   status: 'PAGO',     data: '02/03', cat: 'Assinatura' },
    ]
  });

  console.log('✅ Financeiro criado');

  // ── Campanhas ──────────────────────────────────────────
  await prisma.campanha.createMany({
    data: [
      { nome: 'Black Friday 2024',   canal: 'WHATSAPP', segmento: 'Clientes Ativos',   status: 'COMPLETED', total: 1820, sent: 1820, delivered: 1711, read: 706, replies: 82 },
      { nome: 'Promo Janeiro',       canal: 'WHATSAPP', segmento: 'Leads Quentes',     status: 'COMPLETED', total: 342,  sent: 342,  delivered: 324,  read: 134, replies: 18 },
      { nome: 'Follow-up Proposta',  canal: 'WHATSAPP', segmento: 'Pipeline Proposta', status: 'RUNNING',   total: 94,   sent: 67,   delivered: 63,   read: 28,  replies: 9 },
      { nome: 'Reengajamento 30d',   canal: 'WHATSAPP', segmento: 'Sem resposta 7d',   status: 'DRAFT',     total: 289,  sent: 0,    delivered: 0,    read: 0,   replies: 0 },
    ]
  });

  console.log('✅ Campanhas criadas');

  // ── Automações ─────────────────────────────────────────
  await prisma.automacao.createMany({
    data: [
      {
        nome: 'Boas-vindas WhatsApp', trigger: '💬 Nova mensagem recebida', status: 'ACTIVE', execucoes: 234,
        nodes: JSON.stringify([
          { id: 'n1', type: 'trigger',      label: 'Nova conversa WA', config: { triggerType: 'conversation_opened', channel: 'whatsapp' }, x: 120, y: 40,  next: ['n2'] },
          { id: 'n2', type: 'delay',        label: 'Aguardar 5s',      config: { value: 5, unit: 'seconds' },                               x: 120, y: 160, next: ['n3'] },
          { id: 'n3', type: 'send_message', label: 'Boas-vindas',      config: { content: 'Olá! 👋 Seja bem-vindo(a)!' },                   x: 120, y: 280, next: ['n4'] },
          { id: 'n4', type: 'assign_agent', label: 'Atribuir agente',  config: { strategy: 'round_robin' },                                 x: 120, y: 400, next: ['n5'] },
          { id: 'n5', type: 'end',          label: 'Fim',              config: {},                                                          x: 120, y: 520, next: [] },
        ])
      },
      {
        nome: 'Follow-up 24h sem resposta', trigger: '⏰ Sem resposta por 24h', status: 'ACTIVE', execucoes: 89,
        nodes: JSON.stringify([
          { id: 'n1', type: 'trigger',      label: 'Sem resposta 24h',   config: { triggerType: 'no_reply_timeout' }, x: 120, y: 40, next: ['n2'] },
          { id: 'n2', type: 'send_message', label: 'Follow-up',          config: { content: 'Oi, {{nome}}! Ainda posso te ajudar?' },       x: 120, y: 160, next: ['n3'] },
          { id: 'n3', type: 'end',          label: 'Fim',                config: {},                                                         x: 120, y: 280, next: [] },
        ])
      },
    ]
  });

  console.log('✅ Automações criadas');

  // ── Base de Conhecimento ───────────────────────────────
  await prisma.kbDocument.createMany({
    data: [
      { titulo: 'Preços e Planos 2025',      cat: 'Vendas',    conteudo: 'Plano Starter: R$ 197/mês (3 usuários, 10.000 msgs). Plano Pro: R$ 497/mês (10 usuários, 30.000 msgs). Plano Enterprise: R$ 997/mês (ilimitado).', palavras: 420, tipo: 'product', status: 'indexed' },
      { titulo: 'FAQ — Integração WhatsApp', cat: 'Suporte',   conteudo: 'A integração WhatsApp utiliza a Evolution API. Para conectar, acesse Conexões > Nova Conexão > WhatsApp > escaneie o QR Code.', palavras: 280, tipo: 'faq',     status: 'indexed' },
      { titulo: 'Onboarding de Clientes',    cat: 'Processos', conteudo: 'Passo 1: Criar conta. Passo 2: Configurar conexão WhatsApp. Passo 3: Importar contatos. Passo 4: Criar primeira campanha.', palavras: 650, tipo: 'text',    status: 'indexed' },
    ]
  });

  console.log('✅ Base de conhecimento criada');

  // ── Conexões ───────────────────────────────────────────
  await prisma.conexao.createMany({
    data: [
      { nome: 'WhatsApp Comercial', tipo: 'WHATSAPP', status: 'CONNECTED', numero: '+55 11 99999-0001', instance: 'wa_comercial', msgs: 1240 },
      { nome: 'WhatsApp Suporte',   tipo: 'WHATSAPP', status: 'CONNECTED', numero: '+55 11 99999-0002', instance: 'wa_suporte',   msgs: 430 },
      { nome: 'Instagram DMs',      tipo: 'INSTAGRAM',status: 'CONNECTED', numero: '@minhaempresa',     instance: 'ig_main',      msgs: 210 },
      { nome: 'Chat no Site',       tipo: 'CHAT',     status: 'CONNECTED', numero: 'widget_v2',         instance: 'chat_site',    msgs: 89 },
    ]
  });

  console.log('✅ Conexões criadas');

  // ── Billing ────────────────────────────────────────────
  const billing = await prisma.billing.create({
    data: {
      plan: 'Pro', status: 'Trial ativo', trialDays: 11,
      nextBilling: '01/04/2025', mrr: 497,
      seatsUsed: 3, seatsLimit: 10,
      contactsUsed: 847, contactsLimit: -1,
      msgsSent: 4230, msgsLimit: 30000,
    }
  });

  await prisma.invoice.createMany({
    data: [
      { billingId: billing.id, period: 'Mar/2025', plan: 'Pro',     amount: 497, paid: false },
      { billingId: billing.id, period: 'Fev/2025', plan: 'Pro',     amount: 497, paid: true },
      { billingId: billing.id, period: 'Jan/2025', plan: 'Starter', amount: 197, paid: true },
    ]
  });

  console.log('✅ Billing criado');

  console.log('\n🎉 Seed concluído com sucesso!');
  console.log('👤 Login: joao@empresa.com | Senha: senha123');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
