const jwt = require('jsonwebtoken');
const prisma = require('../database/prisma');

async function auth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token não fornecido' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);

    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: { id: true, nome: true, email: true, role: true, status: true },
    });

    if (!user || user.status === 'INATIVO') {
      return res.status(401).json({ error: 'Usuário inativo ou não encontrado' });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido ou expirado' });
  }
}

function requireAdmin(req, res, next) {
  if (!['ADMIN', 'SUPER_ADMIN'].includes(req.user?.role)) {
    return res.status(403).json({ error: 'Acesso restrito a administradores' });
  }
  next();
}

function requireSuperAdmin(req, res, next) {
  if (req.user?.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ error: 'Acesso restrito ao Super Admin' });
  }
  next();
}

module.exports = { auth, requireAdmin, requireSuperAdmin };
