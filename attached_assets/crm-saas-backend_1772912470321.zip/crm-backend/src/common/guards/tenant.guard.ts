import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';

@Injectable()
export class TenantGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    const paramTenantId = request.params?.tenantId;

    // Super admin pode acessar qualquer tenant
    if (user?.role === 'super_admin') return true;

    // Se há tenantId no param, verifica se bate com o do usuário
    if (paramTenantId && paramTenantId !== user?.tenantId) {
      throw new ForbiddenException('Acesso negado a este tenant');
    }

    return true;
  }
}
