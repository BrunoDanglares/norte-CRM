import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { User } from '../../users/entities/user.entity';

export enum AppointmentType { REUNIAO = 'reuniao', LIGACAO = 'ligacao', VISITA = 'visita', TAREFA = 'tarefa', LEMBRETE = 'lembrete' }
export enum AppointmentStatus { AGENDADO = 'agendado', CONCLUIDO = 'concluido', CANCELADO = 'cancelado' }

@Entity('appointments')
export class Appointment {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() tenantId: string;
  @Column({ length: 200 }) title: string;
  @Column({ type: 'text', nullable: true }) description: string;
  @Column({ type: 'enum', enum: AppointmentType, default: AppointmentType.TAREFA }) type: AppointmentType;
  @Column({ type: 'enum', enum: AppointmentStatus, default: AppointmentStatus.AGENDADO }) status: AppointmentStatus;
  @Column() startAt: Date;
  @Column({ nullable: true }) endAt: Date;
  @Column({ default: false }) allDay: boolean;
  @Column({ nullable: true }) assignedToId: string;
  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' }) @JoinColumn({ name: 'assignedToId' }) assignedTo: User;
  @Column({ nullable: true }) leadId: string;
  @CreateDateColumn() createdAt: Date;
  @UpdateDateColumn() updatedAt: Date;
}
