import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Tenant } from '../tenants/tenant.entity';
import { User } from '../users/user.entity';
import { Contact } from '../contacts/contact.entity';

export enum AppointmentType { CALL = 'ligacao', MEETING = 'reuniao', TASK = 'tarefa', FOLLOWUP = 'followup' }
export enum AppointmentStatus { SCHEDULED = 'agendado', DONE = 'feito', CANCELLED = 'cancelado' }

@Entity('appointments')
export class Appointment {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() tenantId: string;
  @ManyToOne(() => Tenant, { onDelete: 'CASCADE' }) @JoinColumn({ name: 'tenantId' }) tenant: Tenant;
  @Column() title: string;
  @Column({ nullable: true }) description: string;
  @Column({ type: 'enum', enum: AppointmentType, default: AppointmentType.TASK }) type: AppointmentType;
  @Column({ type: 'enum', enum: AppointmentStatus, default: AppointmentStatus.SCHEDULED }) status: AppointmentStatus;
  @Column() startAt: Date;
  @Column({ nullable: true }) endAt: Date;
  @Column({ nullable: true }) assignedToId: string;
  @ManyToOne(() => User, { nullable: true, eager: true }) @JoinColumn({ name: 'assignedToId' }) assignedTo: User;
  @Column({ nullable: true }) contactId: string;
  @ManyToOne(() => Contact, { nullable: true, eager: true }) @JoinColumn({ name: 'contactId' }) contact: Contact;
  @Column({ nullable: true }) leadId: string;
  @CreateDateColumn() createdAt: Date;
  @UpdateDateColumn() updatedAt: Date;
}
