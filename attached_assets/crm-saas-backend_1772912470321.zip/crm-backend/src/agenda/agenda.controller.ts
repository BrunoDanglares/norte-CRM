import { Controller, Get, Post, Patch, Delete, Body, Param, Query, Request, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { AgendaService } from './agenda.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';

@ApiTags('Agenda')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('agenda')
export class AgendaController {
  constructor(private readonly svc: AgendaService) {}

  @Get()
  @ApiQuery({ name: 'from', required: false }) @ApiQuery({ name: 'to', required: false })
  findAll(@Request() req: any, @Query('from') from?: string, @Query('to') to?: string) {
    return this.svc.findAll(req.user.tenantId, from, to);
  }

  @Get(':id') findOne(@Request() req: any, @Param('id') id: string) { return this.svc.findOne(req.user.tenantId, id); }
  @Post() create(@Request() req: any, @Body() body: any) { return this.svc.create(req.user.tenantId, body); }
  @Patch(':id/complete') complete(@Request() req: any, @Param('id') id: string) { return this.svc.complete(req.user.tenantId, id); }
  @Patch(':id') update(@Request() req: any, @Param('id') id: string, @Body() body: any) { return this.svc.update(req.user.tenantId, id, body); }
  @Delete(':id') remove(@Request() req: any, @Param('id') id: string) { return this.svc.remove(req.user.tenantId, id); }
}
