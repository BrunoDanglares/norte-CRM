import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between } from 'typeorm';
import { Appointment, AppointmentStatus } from './appointment.entity';

@Injectable()
export class AgendaService {
  constructor(@InjectRepository(Appointment) private repo: Repository<Appointment>) {}

  create(tenantId: string, data: Partial<Appointment>) {
    return this.repo.save(this.repo.create({ ...data, tenantId }));
  }

  findAll(tenantId: string, from?: string, to?: string) {
    if (from && to) {
      return this.repo.find({ where: { tenantId, startAt: Between(new Date(from), new Date(to)) }, order: { startAt: 'ASC' } });
    }
    return this.repo.find({ where: { tenantId }, order: { startAt: 'ASC' } });
  }

  async findOne(tenantId: string, id: string) {
    const a = await this.repo.findOne({ where: { id, tenantId } });
    if (!a) throw new NotFoundException('Compromisso não encontrado');
    return a;
  }

  async update(tenantId: string, id: string, data: Partial<Appointment>) {
    await this.repo.update({ id, tenantId }, data);
    return this.findOne(tenantId, id);
  }

  async complete(tenantId: string, id: string) {
    return this.update(tenantId, id, { status: AppointmentStatus.DONE });
  }

  remove(tenantId: string, id: string) { return this.repo.delete({ id, tenantId }); }
}
