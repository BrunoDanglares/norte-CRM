const express = require('express');
const prisma  = require('../database/prisma');

const router = express.Router();

/**
 * POST /api/webhook/evolution
 * Recebe eventos da Evolution API (WhatsApp)
 * Configure este endpoint na Evolution API como webhook URL
 */
router.post('/evolution', async (req, res) => {
  try {
    const { event, instance, data } = req.body;

    console.log(`📩 Webhook Evolution | event: ${event} | instance: ${instance}`);

    switch (event) {

      case 'MESSAGES_UPSERT': {
        // Nova mensagem recebida
        const msg = data.messages?.[0];
        if (!msg || msg.key?.fromMe) break; // ignorar mensagens enviadas por nós

        const phone    = msg.key?.remoteJid?.replace('@s.whatsapp.net', '');
        const txt      = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '[Mídia]';
        const nomeSender = msg.pushName || phone;
        const hora     = new Date(msg.messageTimestamp * 1000).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

        // Busca ou cria conversa
        let conv = await prisma.conversation.findFirst({
          where: { phone: { contains: phone } },
        });

        if (!conv) {
          conv = await prisma.conversation.create({
            data: {
              nome: nomeSender,
              phone: `+${phone}`,
              canal: 'WHATSAPP',
              status: 'OPEN',
              origem: `WhatsApp — instância: ${instance}`,
              unread: 1,
            },
          });
        } else {
          await prisma.conversation.update({
            where: { id: conv.id },
            data: { unread: { increment: 1 }, updatedAt: new Date() },
          });
        }

        await prisma.message.create({
          data: {
            conversationId: conv.id,
            dir: 'IN',
            txt,
            hora,
            status: 'READ',
          },
        });

        break;
      }

      case 'MESSAGES_UPDATE': {
        // Status de mensagem atualizado (sent → delivered → read)
        const update = data.updates?.[0];
        if (!update) break;

        const statusMap = { 2: 'SENT', 3: 'DELIVERED', 4: 'READ' };
        const newStatus = statusMap[update.update?.status];
        if (newStatus) {
          // Aqui você poderia atualizar o status da mensagem pelo ID externo
          // await prisma.message.updateMany({ where: { externalId: update.key?.id }, data: { status: newStatus } });
        }
        break;
      }

      case 'CONNECTION_UPDATE': {
        // Status da conexão mudou
        const { state } = data;
        const statusMap = { open: 'CONNECTED', close: 'DISCONNECTED', connecting: 'CONNECTING' };
        const newStatus = statusMap[state];

        if (newStatus) {
          await prisma.conexao.updateMany({
            where: { instance },
            data: { status: newStatus },
          });
        }
        break;
      }

      case 'QRCODE_UPDATED': {
        // QR Code atualizado — em produção você emitiria via WebSocket para o front
        console.log(`📱 QR Code atualizado para instância: ${instance}`);
        // io.emit(`qrcode:${instance}`, data.qrcode);
        break;
      }
    }

    res.json({ received: true });
  } catch (err) {
    console.error('❌ Erro no webhook:', err);
    res.status(500).json({ error: 'Erro ao processar webhook' });
  }
});

module.exports = router;
