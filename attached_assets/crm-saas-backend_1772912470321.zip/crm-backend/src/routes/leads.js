const express = require('express');
const prisma = require('../database/prisma');
const { auth } = require('../middleware/auth');

const router = express.Router();
router.use(auth);

// GET /api/leads
router.get('/', async (req, res) => {
  try {
    const { status, canal, search, page = 1, limit = 50 } = req.query;

    const where = {};
    if (status) where.status = status;
    if (canal)  where.canal  = canal;
    if (search) {
      where.OR = [
        { nome:    { contains: search, mode: 'insensitive' } },
        { contato: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [leads, total] = await Promise.all([
      prisma.lead.findMany({
        where,
        include: { owner: { select: { nome: true } }, contato_ref: { select: { nome: true, phone: true, email: true } } },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: Number(limit),
      }),
      prisma.lead.count({ where }),
    ]);

    res.json({ leads, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar leads' });
  }
});

// GET /api/leads/:id
router.get('/:id', async (req, res) => {
  try {
    const lead = await prisma.lead.findUnique({
      where: { id: req.params.id },
      include: {
        owner:      { select: { nome: true, email: true } },
        contato_ref:{ select: { nome: true, phone: true, email: true, tags: true } },
        agendaItems:{ orderBy: { createdAt: 'desc' } },
        notas:      { include: { user: { select: { nome: true } } }, orderBy: { createdAt: 'desc' } },
      },
    });
    if (!lead) return res.status(404).json({ error: 'Lead não encontrado' });
    res.json(lead);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao buscar lead' });
  }
});

// POST /api/leads
router.post('/', async (req, res) => {
  try {
    const { nome, contato, valor = 0, status = 'NOVO', canal = 'WHATSAPP', ownerId, contatoId } = req.body;

    if (!nome || !contato) {
      return res.status(400).json({ error: 'Nome e contato são obrigatórios' });
    }

    const lead = await prisma.lead.create({
      data: { nome, contato, valor: Number(valor), status, canal, ownerId: ownerId || req.user.id, contatoId },
      include: { owner: { select: { nome: true } } },
    });

    res.status(201).json(lead);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao criar lead' });
  }
});

// PUT /api/leads/:id
router.put('/:id', async (req, res) => {
  try {
    const { nome, contato, valor, status, canal, ownerId, contatoId } = req.body;

    const lead = await prisma.lead.update({
      where: { id: req.params.id },
      data: {
        ...(nome      && { nome }),
        ...(contato   && { contato }),
        ...(valor     !== undefined && { valor: Number(valor) }),
        ...(status    && { status }),
        ...(canal     && { canal }),
        ...(ownerId   && { ownerId }),
        ...(contatoId !== undefined && { contatoId }),
      },
      include: { owner: { select: { nome: true } } },
    });

    res.json(lead);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao atualizar lead' });
  }
});

// DELETE /api/leads/:id
router.delete('/:id', async (req, res) => {
  try {
    await prisma.lead.delete({ where: { id: req.params.id } });
    res.json({ message: 'Lead removido' });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao remover lead' });
  }
});

// POST /api/leads/:id/notas
router.post('/:id/notas', async (req, res) => {
  try {
    const { conteudo } = req.body;
    const nota = await prisma.nota.create({
      data: { conteudo, userId: req.user.id, leadId: req.params.id },
      include: { user: { select: { nome: true } } },
    });
    res.status(201).json(nota);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao criar nota' });
  }
});

module.exports = router;
