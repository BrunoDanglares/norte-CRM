import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Tenant, TenantPlan } from './entities/tenant.entity';

const PLAN_LIMITS = {
  [TenantPlan.STARTER]:    { maxUsers: 1,   maxLeads: 500,  maxChannels: 1,  aiEnabled: false, automationsEnabled: false },
  [TenantPlan.PRO]:        { maxUsers: 10,  maxLeads: 99999, maxChannels: 3, aiEnabled: true,  automationsEnabled: true  },
  [TenantPlan.ENTERPRISE]: { maxUsers: 999, maxLeads: 99999, maxChannels: 10, aiEnabled: true, automationsEnabled: true  },
};

@Injectable()
export class TenantsService {
  constructor(@InjectRepository(Tenant) private repo: Repository<Tenant>) {}

  async findAll() {
    return this.repo.find({ order: { createdAt: 'DESC' } });
  }

  async findOne(id: string) {
    const t = await this.repo.findOne({ where: { id } });
    if (!t) throw new NotFoundException('Tenant não encontrado');
    return t;
  }

  async update(id: string, dto: Partial<Tenant>) {
    const t = await this.findOne(id);
    Object.assign(t, dto);
    return this.repo.save(t);
  }

  async upgradePlan(id: string, plan: TenantPlan) {
    const limits = PLAN_LIMITS[plan];
    return this.update(id, { plan, ...limits });
  }

  async toggleActive(id: string) {
    const t = await this.findOne(id);
    t.active = !t.active;
    return this.repo.save(t);
  }
}
