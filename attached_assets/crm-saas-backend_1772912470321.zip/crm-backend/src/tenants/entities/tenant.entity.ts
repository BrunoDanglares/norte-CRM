import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn, OneToMany,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';

export enum TenantPlan {
  STARTER = 'starter',
  PRO = 'pro',
  ENTERPRISE = 'enterprise',
}

@Entity('tenants')
export class Tenant {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 200 })
  name: string;

  @Column({ unique: true, length: 100 })
  subdomain: string;

  @Column({ type: 'enum', enum: TenantPlan, default: TenantPlan.STARTER })
  plan: TenantPlan;

  @Column({ default: true })
  active: boolean;

  @Column({ nullable: true, length: 200 })
  logoUrl: string;

  @Column({ nullable: true, length: 200 })
  primaryColor: string;

  // Limites por plano
  @Column({ default: 1 })
  maxUsers: number;

  @Column({ default: 500 })
  maxLeads: number;

  @Column({ default: 1 })
  maxChannels: number;

  @Column({ default: false })
  aiEnabled: boolean;

  @Column({ default: false })
  automationsEnabled: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @OneToMany(() => User, (user) => user.tenant)
  users: User[];
}
