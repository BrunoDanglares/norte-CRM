import { Controller, Get, Patch, Param, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { TenantsService } from './tenants.service';
import { Roles } from '../common/decorators/roles.decorator';
import { RolesGuard } from '../common/guards/roles.guard';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { UserRole } from '../users/entities/user.entity';
import { TenantPlan } from './entities/tenant.entity';

@ApiTags('Tenants')
@ApiBearerAuth('access-token')
@UseGuards(RolesGuard)
@Controller('tenants')
export class TenantsController {
  constructor(private service: TenantsService) {}

  @Get()
  @Roles(UserRole.SUPER_ADMIN)
  findAll() { return this.service.findAll(); }

  @Get(':id')
  @Roles(UserRole.SUPER_ADMIN, UserRole.ADMIN)
  findOne(@Param('id') id: string) { return this.service.findOne(id); }

  @Patch(':id')
  @Roles(UserRole.SUPER_ADMIN)
  update(@Param('id') id: string, @Body() dto: any) { return this.service.update(id, dto); }

  @Patch(':id/plan')
  @Roles(UserRole.SUPER_ADMIN)
  upgradePlan(@Param('id') id: string, @Body() body: { plan: TenantPlan }) {
    return this.service.upgradePlan(id, body.plan);
  }

  @Patch(':id/toggle-active')
  @Roles(UserRole.SUPER_ADMIN)
  toggleActive(@Param('id') id: string) { return this.service.toggleActive(id); }
}
