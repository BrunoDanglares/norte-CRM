import { Injectable, NotFoundException, ConflictException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User, UserRole } from './entities/user.entity';

@Injectable()
export class UsersService {
  constructor(@InjectRepository(User) private repo: Repository<User>) {}

  async findAll(tenantId: string) {
    return this.repo.find({
      where: { tenantId },
      select: ['id','name','email','role','active','avatarUrl','phone','createdAt'],
      order: { createdAt: 'DESC' },
    });
  }

  async findOne(id: string, tenantId: string) {
    const user = await this.repo.findOne({ where: { id, tenantId },
      select: ['id','name','email','role','active','avatarUrl','phone','createdAt'] });
    if (!user) throw new NotFoundException('Usuário não encontrado');
    return user;
  }

  async create(dto: Partial<User>, tenantId: string) {
    const existing = await this.repo.findOne({ where: { email: dto.email } });
    if (existing) throw new ConflictException('E-mail já cadastrado');
    const user = this.repo.create({ ...dto, tenantId });
    return this.repo.save(user);
  }

  async update(id: string, dto: Partial<User>, tenantId: string) {
    const user = await this.repo.findOne({ where: { id, tenantId } });
    if (!user) throw new NotFoundException('Usuário não encontrado');
    Object.assign(user, dto);
    return this.repo.save(user);
  }

  async toggleActive(id: string, tenantId: string) {
    const user = await this.repo.findOne({ where: { id, tenantId } });
    if (!user) throw new NotFoundException('Usuário não encontrado');
    user.active = !user.active;
    return this.repo.save(user);
  }

  async changeRole(id: string, role: UserRole, tenantId: string, requesterId: string) {
    if (id === requesterId) throw new ForbiddenException('Não é possível alterar o próprio role');
    const user = await this.repo.findOne({ where: { id, tenantId } });
    if (!user) throw new NotFoundException('Usuário não encontrado');
    user.role = role;
    return this.repo.save(user);
  }
}
