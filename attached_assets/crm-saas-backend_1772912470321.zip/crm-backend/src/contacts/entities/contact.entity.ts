import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn,
} from 'typeorm';

@Entity('contacts')
export class Contact {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column({ length: 200 })
  name: string;

  @Column({ nullable: true, length: 20 })
  phone: string;

  @Column({ nullable: true, length: 200 })
  email: string;

  @Column({ nullable: true, length: 100 })
  instagramId: string;

  @Column({ nullable: true, length: 100 })
  whatsappId: string;

  @Column({ type: 'simple-array', nullable: true })
  tags: string[];

  @Column({ nullable: true, length: 200 })
  avatarUrl: string;

  @Column({ nullable: true, length: 100 })
  city: string;

  @Column({ nullable: true, length: 2 })
  state: string;

  @Column({ type: 'text', nullable: true })
  notes: string;

  @Column({ default: false })
  isBlocked: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
