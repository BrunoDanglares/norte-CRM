import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, ILike } from 'typeorm';
import { Contact } from './contact.entity';

@Injectable()
export class ContactsService {
  constructor(@InjectRepository(Contact) private repo: Repository<Contact>) {}

  create(tenantId: string, data: Partial<Contact>): Promise<Contact> {
    const c = this.repo.create({ ...data, tenantId });
    return this.repo.save(c);
  }

  findAll(tenantId: string, search?: string): Promise<Contact[]> {
    if (search) return this.repo.find({ where: [
      { tenantId, name: ILike(`%${search}%`) },
      { tenantId, phone: ILike(`%${search}%`) },
      { tenantId, email: ILike(`%${search}%`) },
    ]});
    return this.repo.find({ where: { tenantId }, order: { name: 'ASC' } });
  }

  async findOne(tenantId: string, id: string): Promise<Contact> {
    const c = await this.repo.findOne({ where: { id, tenantId } });
    if (!c) throw new NotFoundException('Contato não encontrado');
    return c;
  }

  async update(tenantId: string, id: string, data: Partial<Contact>): Promise<Contact> {
    await this.repo.update({ id, tenantId }, data);
    return this.findOne(tenantId, id);
  }

  async remove(tenantId: string, id: string): Promise<void> {
    await this.repo.delete({ id, tenantId });
  }
}
