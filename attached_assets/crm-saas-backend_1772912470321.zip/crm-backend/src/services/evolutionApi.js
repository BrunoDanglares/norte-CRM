/**
 * Serviço de integração com Evolution API (WhatsApp)
 * Documentação: https://doc.evolution-api.com
 */

const EVOLUTION_URL = process.env.EVOLUTION_API_URL;
const EVOLUTION_KEY = process.env.EVOLUTION_API_KEY;

async function request(method, path, body = null) {
  const res = await fetch(`${EVOLUTION_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      'apikey': EVOLUTION_KEY,
    },
    ...(body && { body: JSON.stringify(body) }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Evolution API error ${res.status}: ${err}`);
  }

  return res.json();
}

// ── Instâncias ────────────────────────────────────────────

/**
 * Criar uma nova instância WhatsApp
 */
async function createInstance(instanceName) {
  return request('POST', '/instance/create', {
    instanceName,
    integration: 'WHATSAPP-BAILEYS',
  });
}

/**
 * Buscar todas as instâncias
 */
async function fetchInstances() {
  return request('GET', '/instance/fetchInstances');
}

/**
 * Conectar instância (retorna QR Code)
 */
async function connectInstance(instanceName) {
  return request('GET', `/instance/connect/${instanceName}`);
}

/**
 * Estado da conexão
 */
async function getConnectionState(instanceName) {
  return request('GET', `/instance/connectionState/${instanceName}`);
}

/**
 * Desconectar instância
 */
async function logoutInstance(instanceName) {
  return request('DELETE', `/instance/logout/${instanceName}`);
}

/**
 * Deletar instância
 */
async function deleteInstance(instanceName) {
  return request('DELETE', `/instance/delete/${instanceName}`);
}

// ── Mensagens ─────────────────────────────────────────────

/**
 * Enviar mensagem de texto
 * @param {string} instance - Nome da instância
 * @param {string} to - Número no formato 5511999990000
 * @param {string} text - Texto da mensagem
 */
async function sendTextMessage(instance, to, text) {
  return request('POST', `/message/sendText/${instance}`, {
    number: to,
    text,
  });
}

/**
 * Enviar mensagem com mídia
 */
async function sendMediaMessage(instance, to, mediaUrl, caption, mediatype = 'image') {
  return request('POST', `/message/sendMedia/${instance}`, {
    number: to,
    mediatype,
    media: mediaUrl,
    caption,
  });
}

/**
 * Enviar botões interativos
 */
async function sendButtons(instance, to, text, buttons) {
  return request('POST', `/message/sendButtons/${instance}`, {
    number: to,
    title: text,
    buttons,
  });
}

// ── Webhook ───────────────────────────────────────────────

/**
 * Configurar webhook para receber mensagens
 * @param {string} instance - Nome da instância
 * @param {string} webhookUrl - URL do seu backend para receber eventos
 */
async function setWebhook(instance, webhookUrl) {
  return request('POST', `/webhook/set/${instance}`, {
    webhook: {
      enabled: true,
      url: webhookUrl,
      events: [
        'MESSAGES_UPSERT',
        'MESSAGES_UPDATE',
        'CONNECTION_UPDATE',
        'QRCODE_UPDATED',
      ],
    },
  });
}

// ── Contatos ──────────────────────────────────────────────

/**
 * Verificar se número tem WhatsApp
 */
async function checkNumber(instance, number) {
  return request('POST', `/chat/whatsappNumbers/${instance}`, {
    numbers: [number],
  });
}

module.exports = {
  createInstance,
  fetchInstances,
  connectInstance,
  getConnectionState,
  logoutInstance,
  deleteInstance,
  sendTextMessage,
  sendMediaMessage,
  sendButtons,
  setWebhook,
  checkNumber,
};
