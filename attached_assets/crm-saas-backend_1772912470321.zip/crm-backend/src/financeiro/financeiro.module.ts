import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Transaction } from './transaction.entity';
import { FinanceiroService } from './financeiro.service';
import { FinanceiroController } from './financeiro.controller';

@Module({
  imports: [TypeOrmModule.forFeature([Transaction])],
  providers: [FinanceiroService],
  controllers: [FinanceiroController],
  exports: [FinanceiroService],
})
export class FinanceiroModule {}
