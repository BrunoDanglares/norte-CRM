import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { User } from '../../users/entities/user.entity';

export enum TransactionType { ENTRADA = 'entrada', SAIDA = 'saida' }
export enum TransactionStatus { PENDENTE = 'pendente', PAGO = 'pago', CANCELADO = 'cancelado', VENCIDO = 'vencido' }

@Entity('transactions')
export class Transaction {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() tenantId: string;
  @Column({ type: 'enum', enum: TransactionType }) type: TransactionType;
  @Column({ length: 200 }) description: string;
  @Column({ type: 'decimal', precision: 12, scale: 2 }) amount: number;
  @Column({ type: 'enum', enum: TransactionStatus, default: TransactionStatus.PENDENTE }) status: TransactionStatus;
  @Column({ nullable: true }) dueDate: Date;
  @Column({ nullable: true }) paidAt: Date;
  @Column({ nullable: true, length: 100 }) category: string;
  @Column({ nullable: true }) createdById: string;
  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' }) @JoinColumn({ name: 'createdById' }) createdBy: User;
  @CreateDateColumn() createdAt: Date;
  @UpdateDateColumn() updatedAt: Date;
}
