import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Transaction, TransactionType, TransactionStatus } from './transaction.entity';

@Injectable()
export class FinanceiroService {
  constructor(@InjectRepository(Transaction) private repo: Repository<Transaction>) {}

  create(tenantId: string, createdById: string, data: Partial<Transaction>) {
    return this.repo.save(this.repo.create({ ...data, tenantId, createdById }));
  }

  findAll(tenantId: string, filters?: { type?: TransactionType; status?: TransactionStatus }) {
    const where: any = { tenantId };
    if (filters?.type) where.type = filters.type;
    if (filters?.status) where.status = filters.status;
    return this.repo.find({ where, order: { createdAt: 'DESC' } });
  }

  async findOne(tenantId: string, id: string) {
    const t = await this.repo.findOne({ where: { id, tenantId } });
    if (!t) throw new NotFoundException('Transação não encontrada');
    return t;
  }

  async update(tenantId: string, id: string, data: Partial<Transaction>) {
    await this.repo.update({ id, tenantId }, data);
    return this.findOne(tenantId, id);
  }

  remove(tenantId: string, id: string) { return this.repo.delete({ id, tenantId }); }

  async getSummary(tenantId: string) {
    const all = await this.findAll(tenantId);
    const paid = all.filter(t => t.status === TransactionStatus.PAID);
    const income  = paid.filter(t => t.type === TransactionType.INCOME).reduce((s, t) => s + +t.amount, 0);
    const expense = paid.filter(t => t.type === TransactionType.EXPENSE).reduce((s, t) => s + +t.amount, 0);
    const pending = all.filter(t => t.status === TransactionStatus.PENDING).reduce((s, t) => s + +t.amount, 0);
    const overdue = all.filter(t => t.status === TransactionStatus.OVERDUE).reduce((s, t) => s + +t.amount, 0);
    return { income, expense, balance: income - expense, pending, overdue };
  }
}
