import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Tenant } from '../tenants/tenant.entity';
import { User } from '../users/user.entity';

export enum TransactionType { INCOME = 'entrada', EXPENSE = 'saida' }
export enum TransactionStatus { PENDING = 'pendente', PAID = 'pago', OVERDUE = 'vencido', CANCELLED = 'cancelado' }

@Entity('transactions')
export class Transaction {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() tenantId: string;
  @ManyToOne(() => Tenant, { onDelete: 'CASCADE' }) @JoinColumn({ name: 'tenantId' }) tenant: Tenant;
  @Column({ type: 'enum', enum: TransactionType }) type: TransactionType;
  @Column() description: string;
  @Column({ type: 'decimal', precision: 12, scale: 2 }) amount: number;
  @Column({ type: 'enum', enum: TransactionStatus, default: TransactionStatus.PENDING }) status: TransactionStatus;
  @Column({ nullable: true }) category: string;
  @Column({ nullable: true }) dueDate: Date;
  @Column({ nullable: true }) paidAt: Date;
  @Column({ nullable: true }) leadId: string;
  @Column({ nullable: true }) createdById: string;
  @ManyToOne(() => User, { nullable: true, eager: true }) @JoinColumn({ name: 'createdById' }) createdBy: User;
  @CreateDateColumn() createdAt: Date;
}
