import { Controller, Get, Post, Patch, Delete, Body, Param, Query, Request, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { FinanceiroService } from './financeiro.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';

@ApiTags('Financeiro')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('financeiro')
export class FinanceiroController {
  constructor(private readonly svc: FinanceiroService) {}

  @Get('summary') summary(@Request() req: any) { return this.svc.getSummary(req.user.tenantId); }
  @Get() findAll(@Request() req: any, @Query() q: any) { return this.svc.findAll(req.user.tenantId, q); }
  @Get(':id') findOne(@Request() req: any, @Param('id') id: string) { return this.svc.findOne(req.user.tenantId, id); }
  @Post() create(@Request() req: any, @Body() body: any) { return this.svc.create(req.user.tenantId, req.user.id, body); }
  @Patch(':id') update(@Request() req: any, @Param('id') id: string, @Body() body: any) { return this.svc.update(req.user.tenantId, id, body); }
  @Delete(':id') remove(@Request() req: any, @Param('id') id: string) { return this.svc.remove(req.user.tenantId, id); }
}
