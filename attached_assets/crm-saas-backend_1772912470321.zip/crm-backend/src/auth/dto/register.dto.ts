import { IsEmail, IsString, MinLength, Matches } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class RegisterDto {
  @ApiProperty({ example: 'João Silva' })
  @IsString()
  name: string;

  @ApiProperty({ example: 'joao@empresa.com' })
  @IsEmail()
  email: string;

  @ApiProperty({ example: 'senha123', minLength: 6 })
  @IsString()
  @MinLength(6)
  password: string;

  @ApiProperty({ example: 'Imobiliária Horizonte' })
  @IsString()
  companyName: string;

  @ApiProperty({ example: 'imobiliaria-horizonte', description: 'Subdomínio único (sem espaços)' })
  @IsString()
  @Matches(/^[a-z0-9-]+$/, { message: 'Subdomínio deve conter apenas letras minúsculas, números e hífens' })
  subdomain: string;
}
