import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, ILike } from 'typeorm';
import { Lead, LeadStatus } from './lead.entity';

@Injectable()
export class LeadsService {
  constructor(@InjectRepository(Lead) private repo: Repository<Lead>) {}

  create(tenantId: string, data: Partial<Lead>): Promise<Lead> {
    return this.repo.save(this.repo.create({ ...data, tenantId }));
  }

  findAll(tenantId: string, filters?: { status?: LeadStatus; ownerId?: string; search?: string }): Promise<Lead[]> {
    const q = this.repo.createQueryBuilder('l')
      .where('l.tenantId = :tenantId', { tenantId })
      .orderBy('l.createdAt', 'DESC');

    if (filters?.status) q.andWhere('l.status = :status', { status: filters.status });
    if (filters?.ownerId) q.andWhere('l.ownerId = :ownerId', { ownerId: filters.ownerId });
    if (filters?.search) q.andWhere('l.title ILIKE :s', { s: `%${filters.search}%` });

    return q.getMany();
  }

  async findOne(tenantId: string, id: string): Promise<Lead> {
    const l = await this.repo.findOne({ where: { id, tenantId } });
    if (!l) throw new NotFoundException('Lead não encontrado');
    return l;
  }

  async update(tenantId: string, id: string, data: Partial<Lead>): Promise<Lead> {
    await this.repo.update({ id, tenantId }, data);
    return this.findOne(tenantId, id);
  }

  async remove(tenantId: string, id: string): Promise<void> {
    await this.repo.delete({ id, tenantId });
  }

  async getKanbanBoard(tenantId: string) {
    const leads = await this.findAll(tenantId);
    const board: Record<string, Lead[]> = {};
    Object.values(LeadStatus).forEach(s => { board[s] = []; });
    leads.forEach(l => board[l.status]?.push(l));
    return board;
  }

  async moveStage(tenantId: string, id: string, status: LeadStatus): Promise<Lead> {
    return this.update(tenantId, id, { status });
  }
}
