import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, UpdateDateColumn,
  ManyToOne, JoinColumn, OneToMany,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';

export enum LeadStatus {
  NOVO       = 'novo',
  CONTATO    = 'contato',
  QUALIFICADO = 'qualificado',
  PROPOSTA   = 'proposta',
  NEGOCIACAO = 'negociacao',
  GANHO      = 'ganho',
  PERDIDO    = 'perdido',
}

export enum LeadPriority {
  BAIXA  = 'baixa',
  MEDIA  = 'media',
  ALTA   = 'alta',
  URGENTE = 'urgente',
}

@Entity('leads')
export class Lead {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column({ length: 200 })
  name: string;

  @Column({ nullable: true, length: 200 })
  email: string;

  @Column({ nullable: true, length: 20 })
  phone: string;

  @Column({ nullable: true, length: 200 })
  company: string;

  @Column({ nullable: true, length: 100 })
  nicho: string;

  @Column({ type: 'enum', enum: LeadStatus, default: LeadStatus.NOVO })
  status: LeadStatus;

  @Column({ type: 'enum', enum: LeadPriority, default: LeadPriority.MEDIA })
  priority: LeadPriority;

  @Column({ type: 'decimal', precision: 12, scale: 2, default: 0 })
  value: number;

  @Column({ nullable: true })
  ownerId: string;

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'ownerId' })
  owner: User;

  @Column({ nullable: true, length: 100 })
  source: string; // whatsapp, instagram, formulario, indicacao...

  @Column({ nullable: true, length: 100 })
  tag: string;

  @Column({ type: 'text', nullable: true })
  notes: string;

  @Column({ nullable: true })
  expectedCloseDate: Date;

  @Column({ default: false })
  isArchived: boolean;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
