import {
  IsString, IsEmail, IsOptional, IsEnum,
  IsNumber, IsUUID, IsDateString, MinLength,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { LeadStatus, LeadPriority } from '../entities/lead.entity';
import { PartialType } from '@nestjs/swagger';

export class CreateLeadDto {
  @ApiProperty({ example: 'Maria Oliveira' })
  @IsString()
  @MinLength(2)
  name: string;

  @ApiPropertyOptional({ example: 'maria@email.com' })
  @IsOptional()
  @IsEmail()
  email?: string;

  @ApiPropertyOptional({ example: '11999998888' })
  @IsOptional()
  @IsString()
  phone?: string;

  @ApiPropertyOptional({ example: 'Empresa XYZ' })
  @IsOptional()
  @IsString()
  company?: string;

  @ApiPropertyOptional({ example: 'imobiliaria' })
  @IsOptional()
  @IsString()
  nicho?: string;

  @ApiPropertyOptional({ enum: LeadStatus, default: LeadStatus.NOVO })
  @IsOptional()
  @IsEnum(LeadStatus)
  status?: LeadStatus;

  @ApiPropertyOptional({ enum: LeadPriority, default: LeadPriority.MEDIA })
  @IsOptional()
  @IsEnum(LeadPriority)
  priority?: LeadPriority;

  @ApiPropertyOptional({ example: 15000 })
  @IsOptional()
  @IsNumber()
  value?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  ownerId?: string;

  @ApiPropertyOptional({ example: 'whatsapp' })
  @IsOptional()
  @IsString()
  source?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  tag?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  expectedCloseDate?: string;
}

export class UpdateLeadDto extends PartialType(CreateLeadDto) {}
