import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Tenant } from '../tenants/tenant.entity';
import { Contact } from '../contacts/contact.entity';
import { User } from '../users/user.entity';

export enum LeadStatus {
  NEW       = 'novo',
  CONTACTED = 'contatado',
  QUALIFIED = 'qualificado',
  PROPOSAL  = 'proposta',
  NEGOTIATION = 'negociacao',
  WON       = 'ganho',
  LOST      = 'perdido',
}

@Entity('leads')
export class Lead {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @ManyToOne(() => Tenant, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'tenantId' })
  tenant: Tenant;

  @Column({ nullable: true })
  contactId: string;

  @ManyToOne(() => Contact, { nullable: true, eager: true })
  @JoinColumn({ name: 'contactId' })
  contact: Contact;

  @Column()
  title: string;

  @Column({ nullable: true })
  nicho: string;

  @Column({ type: 'enum', enum: LeadStatus, default: LeadStatus.NEW })
  status: LeadStatus;

  @Column({ nullable: true })
  stageId: string;

  @Column({ type: 'decimal', precision: 12, scale: 2, default: 0 })
  value: number;

  @Column({ nullable: true })
  tag: string;

  @Column({ nullable: true })
  ownerId: string;

  @ManyToOne(() => User, { nullable: true, eager: true })
  @JoinColumn({ name: 'ownerId' })
  owner: User;

  @Column({ nullable: true })
  notes: string;

  @Column({ nullable: true })
  expectedCloseDate: Date;

  @Column({ nullable: true })
  lostReason: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
