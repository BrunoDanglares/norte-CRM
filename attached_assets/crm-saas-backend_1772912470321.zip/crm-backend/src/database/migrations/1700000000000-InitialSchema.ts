import { MigrationInterface, QueryRunner } from 'typeorm';

export class InitialSchema1700000000000 implements MigrationInterface {
  name = 'InitialSchema1700000000000';

  public async up(qr: QueryRunner): Promise<void> {
    // Tenants
    await qr.query(`
      CREATE TYPE tenant_plan_enum AS ENUM ('starter','pro','enterprise');
      CREATE TABLE tenants (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name VARCHAR NOT NULL UNIQUE,
        subdomain VARCHAR NOT NULL UNIQUE,
        plan tenant_plan_enum NOT NULL DEFAULT 'starter',
        active BOOLEAN NOT NULL DEFAULT true,
        "stripeCustomerId" VARCHAR,
        "stripeSubscriptionId" VARCHAR,
        "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
        "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now()
      );
    `);

    // Users
    await qr.query(`
      CREATE TYPE user_role_enum AS ENUM ('super_admin','admin','user');
      CREATE TABLE users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        "tenantId" UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        name VARCHAR NOT NULL,
        email VARCHAR NOT NULL UNIQUE,
        "passwordHash" VARCHAR NOT NULL,
        role user_role_enum NOT NULL DEFAULT 'user',
        active BOOLEAN NOT NULL DEFAULT true,
        "avatarUrl" VARCHAR,
        "refreshToken" VARCHAR,
        "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
        "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX idx_users_tenant ON users("tenantId");
      CREATE INDEX idx_users_email  ON users(email);
    `);

    // Contacts
    await qr.query(`
      CREATE TABLE contacts (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        "tenantId" UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        name VARCHAR NOT NULL,
        phone VARCHAR,
        email VARCHAR,
        "instagramId" VARCHAR,
        "whatsappId" VARCHAR,
        tags TEXT[] DEFAULT '{}',
        "avatarUrl" VARCHAR,
        company VARCHAR,
        notes TEXT,
        "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
        "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX idx_contacts_tenant ON contacts("tenantId");
    `);

    // Leads
    await qr.query(`
      CREATE TYPE lead_status_enum AS ENUM ('novo','contatado','qualificado','proposta','negociacao','ganho','perdido');
      CREATE TABLE leads (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        "tenantId" UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        "contactId" UUID REFERENCES contacts(id) ON DELETE SET NULL,
        title VARCHAR NOT NULL,
        nicho VARCHAR,
        status lead_status_enum NOT NULL DEFAULT 'novo',
        "stageId" UUID,
        value DECIMAL(12,2) DEFAULT 0,
        tag VARCHAR,
        "ownerId" UUID REFERENCES users(id) ON DELETE SET NULL,
        notes TEXT,
        "expectedCloseDate" DATE,
        "lostReason" VARCHAR,
        "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
        "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX idx_leads_tenant ON leads("tenantId");
      CREATE INDEX idx_leads_status ON leads(status);
    `);

    // Stages + Deals
    await qr.query(`
      CREATE TABLE stages (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        "tenantId" UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        name VARCHAR NOT NULL,
        "order" INT NOT NULL DEFAULT 0,
        color VARCHAR,
        "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE TABLE deals (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        "tenantId" UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        title VARCHAR NOT NULL,
        value DECIMAL(12,2) DEFAULT 0,
        "stageId" UUID REFERENCES stages(id) ON DELETE SET NULL,
        "contactId" UUID REFERENCES contacts(id) ON DELETE SET NULL,
        "ownerId" UUID REFERENCES users(id) ON DELETE SET NULL,
        "expectedCloseDate" DATE,
        won BOOLEAN DEFAULT false,
        lost BOOLEAN DEFAULT false,
        "lostReason" VARCHAR,
        "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
        "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now()
      );
    `);

    // Transactions (Financeiro)
    await qr.query(`
      CREATE TYPE transaction_type_enum   AS ENUM ('entrada','saida');
      CREATE TYPE transaction_status_enum AS ENUM ('pendente','pago','vencido','cancelado');
      CREATE TABLE transactions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        "tenantId" UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        type transaction_type_enum NOT NULL,
        description VARCHAR NOT NULL,
        amount DECIMAL(12,2) NOT NULL,
        status transaction_status_enum NOT NULL DEFAULT 'pendente',
        category VARCHAR,
        "dueDate" DATE,
        "paidAt" TIMESTAMPTZ,
        "leadId" UUID,
        "createdById" UUID REFERENCES users(id) ON DELETE SET NULL,
        "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX idx_transactions_tenant ON transactions("tenantId");
    `);

    // Appointments (Agenda)
    await qr.query(`
      CREATE TYPE appointment_type_enum   AS ENUM ('ligacao','reuniao','tarefa','followup');
      CREATE TYPE appointment_status_enum AS ENUM ('agendado','feito','cancelado');
      CREATE TABLE appointments (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        "tenantId" UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
        title VARCHAR NOT NULL,
        description TEXT,
        type appointment_type_enum NOT NULL DEFAULT 'tarefa',
        status appointment_status_enum NOT NULL DEFAULT 'agendado',
        "startAt" TIMESTAMPTZ NOT NULL,
        "endAt" TIMESTAMPTZ,
        "assignedToId" UUID REFERENCES users(id) ON DELETE SET NULL,
        "contactId" UUID REFERENCES contacts(id) ON DELETE SET NULL,
        "leadId" UUID REFERENCES leads(id) ON DELETE SET NULL,
        "createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
        "updatedAt" TIMESTAMPTZ NOT NULL DEFAULT now()
      );
      CREATE INDEX idx_appointments_tenant  ON appointments("tenantId");
      CREATE INDEX idx_appointments_startat ON appointments("startAt");
    `);
  }

  public async down(qr: QueryRunner): Promise<void> {
    await qr.query(`
      DROP TABLE IF EXISTS appointments, transactions, deals, stages, leads, contacts, users, tenants CASCADE;
      DROP TYPE IF EXISTS appointment_status_enum, appointment_type_enum, transaction_status_enum, transaction_type_enum, lead_status_enum, user_role_enum, tenant_plan_enum CASCADE;
    `);
  }
}
