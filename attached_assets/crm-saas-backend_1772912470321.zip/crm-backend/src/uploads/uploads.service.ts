import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { S3Client, PutObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { v4 as uuid } from 'uuid';

@Injectable()
export class UploadsService {
  private s3: S3Client;
  private bucket: string;

  constructor(private config: ConfigService) {
    this.bucket = config.get('S3_BUCKET', 'crm-saas-uploads');
    this.s3 = new S3Client({
      region: config.get('S3_REGION', 'us-east-1'),
      credentials: {
        accessKeyId: config.get('S3_ACCESS_KEY'),
        secretAccessKey: config.get('S3_SECRET_KEY'),
      },
      ...(config.get('S3_ENDPOINT') ? { endpoint: config.get('S3_ENDPOINT') } : {}),
    });
  }

  async uploadFile(file: Express.Multer.File, tenantId: string, folder = 'general') {
    const ext = file.originalname.split('.').pop();
    const key = `${tenantId}/${folder}/${uuid()}.${ext}`;

    await this.s3.send(new PutObjectCommand({
      Bucket: this.bucket,
      Key: key,
      Body: file.buffer,
      ContentType: file.mimetype,
      Metadata: { tenantId, originalName: file.originalname },
    }));

    return {
      key,
      url: `https://${this.bucket}.s3.amazonaws.com/${key}`,
      size: file.size,
      mimetype: file.mimetype,
      originalName: file.originalname,
    };
  }

  async deleteFile(key: string) {
    await this.s3.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
    return { message: 'Arquivo removido' };
  }

  async getPresignedUrl(key: string, expiresIn = 3600) {
    const cmd = new PutObjectCommand({ Bucket: this.bucket, Key: key });
    return getSignedUrl(this.s3, cmd, { expiresIn });
  }
}
