import { Controller, Post, Delete, Param, UploadedFile, UseInterceptors, Body } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth, ApiConsumes, ApiBody } from '@nestjs/swagger';
import { UploadsService } from './uploads.service';
import { CurrentUser } from '../common/decorators/current-user.decorator';

@ApiTags('Uploads') @ApiBearerAuth('access-token') @Controller('uploads')
export class UploadsController {
  constructor(private service: UploadsService) {}

  @Post(':folder')
  @ApiConsumes('multipart/form-data')
  @ApiBody({ schema: { type: 'object', properties: { file: { type: 'string', format: 'binary' } } } })
  @UseInterceptors(FileInterceptor('file'))
  upload(@UploadedFile() file: Express.Multer.File, @Param('folder') folder: string, @CurrentUser() user: any) {
    return this.service.uploadFile(file, user.tenantId, folder);
  }

  @Delete(':key')
  delete(@Param('key') key: string) {
    return this.service.deleteFile(decodeURIComponent(key));
  }
}
