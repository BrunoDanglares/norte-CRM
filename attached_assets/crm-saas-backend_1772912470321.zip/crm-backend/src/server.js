require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const morgan  = require('morgan');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth');
const leadsRoutes = require('./routes/leads');
const {
  contatos, conversations, campanhas, agenda,
  financeiro, usuarios, billing, conexoes,
  automacoes, kbRouter, relatorios,
} = require('./routes/index');

const app  = express();
const PORT = process.env.PORT || 3001;

// ── Segurança ──────────────────────────────────────────
app.use(helmet());

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
}));

// Rate limit geral
app.use(rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 500,
  message: { error: 'Muitas requisições. Tente novamente em 15 minutos.' },
}));

// Rate limit mais rígido para auth
app.use('/api/auth', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { error: 'Muitas tentativas de login. Aguarde 15 minutos.' },
}));

// ── Middlewares ────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── Rotas ──────────────────────────────────────────────
app.use('/api/auth',          authRoutes);
app.use('/api/leads',         leadsRoutes);
app.use('/api/contatos',      contatos);
app.use('/api/conversations', conversations);
app.use('/api/campanhas',     campanhas);
app.use('/api/agenda',        agenda);
app.use('/api/financeiro',    financeiro);
app.use('/api/usuarios',      usuarios);
app.use('/api/billing',       billing);
app.use('/api/conexoes',      conexoes);
app.use('/api/automacoes',    automacoes);
app.use('/api/kb',            kbRouter);
app.use('/api/relatorios',    relatorios);
app.use('/api/webhook',       require('./routes/webhook'));

// ── Health check ───────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', env: process.env.NODE_ENV, timestamp: new Date().toISOString() });
});

// ── 404 ────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: `Rota ${req.method} ${req.path} não encontrada` });
});

// ── Error Handler ──────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌ Erro:', err);
  res.status(500).json({ error: process.env.NODE_ENV === 'production' ? 'Erro interno do servidor' : err.message });
});

// ── Start ──────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 CRM SaaS Backend rodando na porta ${PORT}`);
  console.log(`📡 Ambiente: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔗 Health: http://localhost:${PORT}/health`);
  console.log(`📖 API: http://localhost:${PORT}/api`);

  if (process.env.NODE_ENV !== 'production') {
    console.log('\n📋 Rotas disponíveis:');
    [
      'POST   /api/auth/login',
      'GET    /api/auth/me',
      'GET    /api/leads',
      'POST   /api/leads',
      'PUT    /api/leads/:id',
      'DELETE /api/leads/:id',
      'GET    /api/contatos',
      'POST   /api/contatos',
      'GET    /api/conversations',
      'POST   /api/conversations/:id/messages',
      'POST   /api/conversations/:id/resolve',
      'GET    /api/campanhas',
      'POST   /api/campanhas',
      'GET    /api/agenda',
      'POST   /api/agenda',
      'GET    /api/financeiro',
      'POST   /api/financeiro',
      'GET    /api/usuarios',
      'POST   /api/usuarios/invite',
      'GET    /api/billing',
      'POST   /api/billing/upgrade',
      'GET    /api/conexoes',
      'POST   /api/conexoes',
      'GET    /api/automacoes',
      'GET    /api/kb',
      'POST   /api/kb/test',
      'GET    /api/relatorios/resumo',
    ].forEach(r => console.log('  ' + r));
  }
});

module.exports = app;
// já importado acima — não duplicar
