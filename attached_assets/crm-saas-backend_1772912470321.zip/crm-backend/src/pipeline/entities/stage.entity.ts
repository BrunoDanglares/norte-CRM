// stage.entity.ts
import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, ManyToOne, JoinColumn, OneToMany,
} from 'typeorm';

@Entity('pipeline_stages')
export class PipelineStage {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @Column({ length: 100 })
  name: string;

  @Column({ default: 0 })
  order: number;

  @Column({ nullable: true, length: 20 })
  color: string;

  @CreateDateColumn()
  createdAt: Date;
}
