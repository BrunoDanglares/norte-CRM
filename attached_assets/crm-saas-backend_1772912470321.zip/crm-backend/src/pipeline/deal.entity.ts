import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Tenant } from '../tenants/tenant.entity';
import { Stage } from './stage.entity';
import { Contact } from '../contacts/contact.entity';
import { User } from '../users/user.entity';

@Entity('deals')
export class Deal {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  tenantId: string;

  @ManyToOne(() => Tenant, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'tenantId' })
  tenant: Tenant;

  @Column()
  title: string;

  @Column({ type: 'decimal', precision: 12, scale: 2, default: 0 })
  value: number;

  @Column({ nullable: true })
  stageId: string;

  @ManyToOne(() => Stage, { eager: true, nullable: true })
  @JoinColumn({ name: 'stageId' })
  stage: Stage;

  @Column({ nullable: true })
  contactId: string;

  @ManyToOne(() => Contact, { eager: true, nullable: true })
  @JoinColumn({ name: 'contactId' })
  contact: Contact;

  @Column({ nullable: true })
  ownerId: string;

  @ManyToOne(() => User, { eager: true, nullable: true })
  @JoinColumn({ name: 'ownerId' })
  owner: User;

  @Column({ nullable: true })
  expectedCloseDate: Date;

  @Column({ default: false })
  won: boolean;

  @Column({ default: false })
  lost: boolean;

  @Column({ nullable: true })
  lostReason: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
