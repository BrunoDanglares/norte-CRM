import { Controller, Get, Post, Patch, Delete, Body, Param, Request, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { PipelineService } from './pipeline.service';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';

@ApiTags('Pipeline')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('pipeline')
export class PipelineController {
  constructor(private readonly svc: PipelineService) {}

  @Get('board')
  board(@Request() req: any) { return this.svc.getBoard(req.user.tenantId); }

  @Get('stages')
  stages(@Request() req: any) { return this.svc.getStages(req.user.tenantId); }

  @Post('stages')
  createStage(@Request() req: any, @Body() body: any) { return this.svc.createStage(req.user.tenantId, body); }

  @Patch('stages/:id')
  updateStage(@Request() req: any, @Param('id') id: string, @Body() body: any) {
    return this.svc.updateStage(req.user.tenantId, id, body);
  }

  @Delete('stages/:id')
  removeStage(@Request() req: any, @Param('id') id: string) { return this.svc.removeStage(req.user.tenantId, id); }

  @Get('deals')
  deals(@Request() req: any) { return this.svc.getDeals(req.user.tenantId); }

  @Post('deals')
  createDeal(@Request() req: any, @Body() body: any) { return this.svc.createDeal(req.user.tenantId, body); }

  @Patch('deals/:id')
  updateDeal(@Request() req: any, @Param('id') id: string, @Body() body: any) {
    return this.svc.updateDeal(req.user.tenantId, id, body);
  }

  @Delete('deals/:id')
  removeDeal(@Request() req: any, @Param('id') id: string) { return this.svc.removeDeal(req.user.tenantId, id); }
}
