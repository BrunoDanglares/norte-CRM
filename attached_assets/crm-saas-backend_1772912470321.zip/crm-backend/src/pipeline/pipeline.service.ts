import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Stage } from './stage.entity';
import { Deal } from './deal.entity';

@Injectable()
export class PipelineService {
  constructor(
    @InjectRepository(Stage) private stageRepo: Repository<Stage>,
    @InjectRepository(Deal)  private dealRepo: Repository<Deal>,
  ) {}

  // Stages
  createStage(tenantId: string, data: Partial<Stage>) {
    return this.stageRepo.save(this.stageRepo.create({ ...data, tenantId }));
  }
  getStages(tenantId: string) {
    return this.stageRepo.find({ where: { tenantId }, order: { order: 'ASC' } });
  }
  async updateStage(tenantId: string, id: string, data: Partial<Stage>) {
    await this.stageRepo.update({ id, tenantId }, data);
    return this.stageRepo.findOne({ where: { id } });
  }
  removeStage(tenantId: string, id: string) {
    return this.stageRepo.delete({ id, tenantId });
  }

  // Deals
  createDeal(tenantId: string, data: Partial<Deal>) {
    return this.dealRepo.save(this.dealRepo.create({ ...data, tenantId }));
  }
  getDeals(tenantId: string) {
    return this.dealRepo.find({ where: { tenantId }, order: { createdAt: 'DESC' } });
  }
  async getDeal(tenantId: string, id: string) {
    const d = await this.dealRepo.findOne({ where: { id, tenantId } });
    if (!d) throw new NotFoundException('Deal não encontrado');
    return d;
  }
  async updateDeal(tenantId: string, id: string, data: Partial<Deal>) {
    await this.dealRepo.update({ id, tenantId }, data);
    return this.getDeal(tenantId, id);
  }
  removeDeal(tenantId: string, id: string) {
    return this.dealRepo.delete({ id, tenantId });
  }

  async getBoard(tenantId: string) {
    const [stages, deals] = await Promise.all([this.getStages(tenantId), this.getDeals(tenantId)]);
    return stages.map(s => ({ ...s, deals: deals.filter(d => d.stageId === s.id) }));
  }
}
