import { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Badge, CanalIcon, PageHeader } from '../ui';
import { STAGES } from '../../data/mockData';

export default function Pipeline() {
  const data = useStore(s => s.data);
  const updateLead = useStore(s => s.updateLead);
  const notify = useStore(s => s.notify);
  const setPage = useStore(s => s.setPage);
  const leads = data.leads;
  const [dragging, setDragging] = useState(null);
  const [overCol, setOverCol] = useState(null);

  const fmt = n => (+n).toLocaleString('pt-BR');

  const byStage = (stage) => leads.filter(l => l.status === stage);

  function onDragStart(lead) { setDragging(lead); }
  function onDragOver(e, stage) { e.preventDefault(); setOverCol(stage); }
  function onDrop(stage) {
    if (dragging && dragging.status !== stage) {
      updateLead(dragging.id, { status: stage });
      notify(`Lead movido para ${STAGES[stage].label}`);
    }
    setDragging(null);
    setOverCol(null);
  }

  const stages = ['novo','contatado','qualificado','proposta','negociacao','ganho','perdido'];

  return (
    <div style={{ padding:'20px 24px 0', display:'flex', flexDirection:'column', height:'100%' }}>
      <PageHeader
        title="Pipeline"
        subtitle={`${leads.length} leads · R$ ${fmt(leads.reduce((a,l) => a+l.valor, 0))} em potencial`}
        action={<button className="btn-primary" onClick={() => setPage('leads')}>+ Novo Lead</button>}
      />

      {/* Kanban */}
      <div style={{ display:'flex', gap:12, overflowX:'auto', flex:1, paddingBottom:16 }}>
        {stages.map(stage => {
          const stageLeads = byStage(stage);
          const s = STAGES[stage];
          const stageValue = stageLeads.reduce((a,l) => a+l.valor, 0);
          const isOver = overCol === stage;

          return (
            <div
              key={stage}
              onDragOver={(e) => onDragOver(e, stage)}
              onDrop={() => onDrop(stage)}
              style={{
                minWidth:200, width:200, flexShrink:0,
                background: isOver ? 'rgba(124,92,191,.08)' : 'var(--bg2)',
                border:`1.5px solid ${isOver ? 'var(--accent2)' : 'var(--border)'}`,
                borderRadius:12,
                display:'flex', flexDirection:'column',
                maxHeight:'100%', transition:'all .15s',
              }}
            >
              {/* Col Header */}
              <div style={{ padding:'12px 14px', borderBottom:'1px solid var(--border)' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:4 }}>
                  <div style={{ fontWeight:700, fontSize:12.5, color:s.color }}>{s.label}</div>
                  <span style={{ background:'var(--card3)', color:'var(--muted2)', fontSize:10.5, fontWeight:700, padding:'1px 7px', borderRadius:20 }}>
                    {stageLeads.length}
                  </span>
                </div>
                <div style={{ fontSize:11, color:'var(--muted)' }}>R$ {fmt(stageValue)}</div>
              </div>

              {/* Cards */}
              <div style={{ flex:1, overflowY:'auto', padding:'10px 8px', display:'flex', flexDirection:'column', gap:8 }}>
                {stageLeads.map(lead => (
                  <div
                    key={lead.id}
                    draggable
                    onDragStart={() => onDragStart(lead)}
                    onDragEnd={() => { setDragging(null); setOverCol(null); }}
                    style={{
                      background:'var(--card)',
                      border:'1.5px solid var(--border)',
                      borderRadius:10, padding:'12px',
                      cursor:'grab',
                      opacity: dragging?.id === lead.id ? 0.5 : 1,
                      transition:'all .15s',
                    }}
                    onMouseEnter={e => e.currentTarget.style.borderColor = s.color}
                    onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
                  >
                    <div style={{ fontWeight:600, fontSize:12.5, marginBottom:4 }}>{lead.nome}</div>
                    <div style={{ fontSize:11, color:'var(--muted)', marginBottom:8 }}>{lead.contato}</div>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
                      <span style={{ fontWeight:700, color:'var(--accent3)', fontSize:12 }}>R$ {fmt(lead.valor)}</span>
                      <CanalIcon canal={lead.canal} />
                    </div>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                      <span style={{ fontSize:10.5, color:'var(--muted)' }}>{lead.owner}</span>
                      <span style={{ fontSize:10, color:'var(--muted)' }}>{lead.data}</span>
                    </div>
                  </div>
                ))}
                {stageLeads.length === 0 && (
                  <div style={{ textAlign:'center', padding:'20px 0', color:'var(--muted)', fontSize:11.5 }}>
                    Nenhum lead
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
