import { useState } from 'react';
import { useStore } from '../../store/useStore';
import { CanalIcon, Avatar, Badge } from '../ui';

export default function Inbox() {
  const data = useStore(s => s.data);
  const sendMessage = useStore(s => s.sendMessage);
  const resolveConv = useStore(s => s.resolveConv);
  const notify = useStore(s => s.notify);
  const conversations = data.conversations;

  const [activeId, setActiveId] = useState(0);
  const [input, setInput] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [search, setSearch] = useState('');

  const activeConv = conversations.find(c => c.id === activeId);

  const filtered = conversations.filter(c => {
    const matchStatus = filterStatus === 'all' || c.status === filterStatus;
    const matchSearch = !search || c.nome.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  function handleSend() {
    if (!input.trim()) return;
    sendMessage(activeId, input.trim());
    setInput('');
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  const prioColor = { alta:'var(--red)', media:'var(--yellow)', baixa:'var(--green)' };

  return (
    <div style={{ display:'flex', height:'100%', overflow:'hidden' }}>

      {/* Conversation List */}
      <div style={{ width:300, borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', flexShrink:0 }}>
        {/* Header */}
        <div style={{ padding:'14px 16px', borderBottom:'1px solid var(--border)' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
            <div style={{ fontWeight:700, fontSize:13 }}>
              Inbox
              {conversations.reduce((a,c) => a + (c.unread||0), 0) > 0 && (
                <span style={{ background:'#ef4444', color:'#fff', borderRadius:10, padding:'1px 6px', fontSize:9.5, marginLeft:6 }}>
                  {conversations.reduce((a,c) => a + (c.unread||0), 0)}
                </span>
              )}
            </div>
            <button className="btn btn-ghost btn-sm">⚙</button>
          </div>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Buscar conversas..."
            style={{ width:'100%', background:'var(--card2)', border:'1px solid var(--border)', borderRadius:8, padding:'6px 10px', color:'var(--text)', fontSize:12, outline:'none' }}
          />
        </div>

        {/* Status Filters */}
        <div style={{ display:'flex', gap:4, padding:'8px 12px', borderBottom:'1px solid var(--border)' }}>
          {[['all','Todos'],['open','Abertos'],['pending','Pendentes'],['resolved','Resolvidos']].map(([val,label]) => (
            <button key={val}
              onClick={() => setFilterStatus(val)}
              style={{
                padding:'3px 10px', borderRadius:20, fontSize:'10.5px', fontWeight:700,
                background: filterStatus === val ? 'var(--accentBg)' : 'var(--card2)',
                border:`1px solid ${filterStatus === val ? 'var(--accentBd)' : 'var(--border)'}`,
                color: filterStatus === val ? 'var(--accent3)' : 'var(--muted2)',
                cursor:'pointer',
              }}
            >{label}</button>
          ))}
        </div>

        {/* List */}
        <div style={{ flex:1, overflowY:'auto' }}>
          {filtered.map(cv => (
            <div key={cv.id}
              onClick={() => setActiveId(cv.id)}
              style={{
                padding:'12px 14px',
                borderBottom:'1px solid var(--border)',
                cursor:'pointer',
                background: activeId === cv.id ? 'var(--accentBg)' : 'transparent',
                borderLeft: activeId === cv.id ? '2.5px solid var(--accent)' : '2.5px solid transparent',
                transition:'all .1s',
              }}
            >
              <div style={{ display:'flex', gap:10 }}>
                <div style={{ position:'relative', flexShrink:0 }}>
                  <Avatar nome={cv.nome} size={36} />
                  <div style={{ position:'absolute', bottom:0, right:0, fontSize:11, lineHeight:1 }}><CanalIcon canal={cv.canal} /></div>
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ display:'flex', justifyContent:'space-between', marginBottom:2 }}>
                    <span style={{ fontWeight:600, fontSize:12.5 }}>{cv.nome}</span>
                    <span style={{ fontSize:10, color:'var(--muted)' }}>{cv.tempo}</span>
                  </div>
                  <div style={{ fontSize:11.5, color:'var(--muted2)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', marginBottom:4 }}>
                    {cv.ultima}
                  </div>
                  <div style={{ display:'flex', gap:4, alignItems:'center' }}>
                    {cv.tags.slice(0,2).map(t => (
                      <span key={t} className="tag" style={{ fontSize:9.5, padding:'1px 5px' }}>{t}</span>
                    ))}
                    {cv.unread > 0 && (
                      <span style={{ marginLeft:'auto', background:'#ef4444', color:'#fff', borderRadius:10, padding:'1px 6px', fontSize:9.5 }}>{cv.unread}</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      {activeConv ? (
        <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
          {/* Chat Header */}
          <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:12, background:'var(--sidebar)' }}>
            <Avatar nome={activeConv.nome} size={36} />
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:700, fontSize:13 }}>{activeConv.nome}</div>
              <div style={{ fontSize:11, color:'var(--muted)' }}>
                <CanalIcon canal={activeConv.canal} /> {activeConv.origem} · {activeConv.empresa || 'Sem empresa'}
              </div>
            </div>
            <div style={{ display:'flex', gap:6 }}>
              {activeConv.prioridade && (
                <span style={{ padding:'2px 8px', borderRadius:20, fontSize:10.5, fontWeight:700, background:`${prioColor[activeConv.prioridade]}20`, color:prioColor[activeConv.prioridade], border:`1px solid ${prioColor[activeConv.prioridade]}40` }}>
                  {activeConv.prioridade}
                </span>
              )}
              <Badge label={activeConv.status} />
              {activeConv.status !== 'resolved' && (
                <button className="btn btn-sm" style={{ background:'var(--greenDim)', borderColor:'#34d39930', color:'var(--green)' }}
                  onClick={() => { resolveConv(activeConv.id); notify('Conversa resolvida'); }}>
                  ✓ Resolver
                </button>
              )}
            </div>
          </div>

          {/* Messages */}
          <div style={{ flex:1, overflowY:'auto', padding:'16px', background:'var(--bg2)', display:'flex', flexDirection:'column', gap:10 }}>
            {activeConv.msgs.map((msg, i) => (
              <div key={i} style={{ display:'flex', justifyContent: msg.dir === 'out' ? 'flex-end' : 'flex-start' }}>
                <div style={{
                  maxWidth:'70%',
                  background: msg.dir === 'out' ? 'linear-gradient(135deg,var(--accent),var(--accent2))' : 'var(--card)',
                  border: msg.dir === 'in' ? '1px solid var(--border)' : 'none',
                  borderRadius: msg.dir === 'out' ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
                  padding:'10px 14px',
                  color: msg.dir === 'out' ? '#fff' : 'var(--text)',
                }}>
                  <div style={{ fontSize:13, lineHeight:1.5 }}>{msg.txt}</div>
                  <div style={{ display:'flex', justifyContent:'flex-end', alignItems:'center', gap:4, marginTop:4 }}>
                    {msg.agente && <span style={{ fontSize:10, opacity:.7 }}>{msg.agente}</span>}
                    <span style={{ fontSize:10, opacity:.7 }}>{msg.hora}</span>
                    {msg.dir === 'out' && <span style={{ fontSize:10 }}>{msg.status === 'read' ? '✓✓' : msg.status === 'delivered' ? '✓✓' : '✓'}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div style={{ padding:'12px 16px', borderTop:'1px solid var(--border)', background:'var(--sidebar)' }}>
            {/* Quick Replies */}
            <div style={{ display:'flex', gap:6, marginBottom:8, overflowX:'auto' }}>
              {['Olá, como posso ajudar?','Pode me dar mais detalhes?','Vou verificar e retorno em breve!','Obrigado pelo contato!'].map(r => (
                <button key={r} onClick={() => setInput(r)}
                  style={{ padding:'4px 10px', borderRadius:20, fontSize:'10.5px', fontWeight:600, background:'var(--card2)', border:'1px solid var(--border)', color:'var(--muted2)', cursor:'pointer', whiteSpace:'nowrap', flexShrink:0 }}>
                  {r}
                </button>
              ))}
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <textarea
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Digite uma mensagem... (Enter para enviar)"
                rows={2}
                style={{ flex:1, background:'var(--card2)', border:'1px solid var(--border2)', borderRadius:10, padding:'8px 12px', color:'var(--text)', fontSize:13, resize:'none', outline:'none', fontFamily:'inherit' }}
              />
              <button className="btn-primary" onClick={handleSend} style={{ alignSelf:'flex-end', padding:'10px 16px' }}>
                ➤
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--muted)' }}>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize:40, marginBottom:12 }}>💬</div>
            <div>Selecione uma conversa</div>
          </div>
        </div>
      )}

      {/* Right Sidebar */}
      {activeConv && (
        <div style={{ width:240, borderLeft:'1px solid var(--border)', overflowY:'auto', background:'var(--sidebar)', padding:14 }}>
          <div style={{ fontWeight:700, fontSize:12, marginBottom:12, color:'var(--muted)', textTransform:'uppercase' }}>Informações</div>
          {[
            ['Empresa', activeConv.empresa || '—'],
            ['Email',   activeConv.email   || '—'],
            ['Telefone',activeConv.phone],
            ['Canal',   activeConv.origem],
            ['Agente',  activeConv.agente  || 'Não atribuído'],
          ].map(([k,v]) => (
            <div key={k} style={{ marginBottom:10 }}>
              <div style={{ fontSize:10.5, fontWeight:700, color:'var(--muted)', marginBottom:2 }}>{k.toUpperCase()}</div>
              <div style={{ fontSize:12.5 }}>{v}</div>
            </div>
          ))}

          {activeConv.notas && (
            <div style={{ marginTop:14 }}>
              <div style={{ fontSize:10.5, fontWeight:700, color:'var(--muted)', marginBottom:6 }}>NOTAS</div>
              <div style={{ background:'var(--card2)', border:'1px solid var(--border)', borderRadius:8, padding:'8px 10px', fontSize:12, color:'var(--text2)' }}>
                {activeConv.notas}
              </div>
            </div>
          )}

          {activeConv.tags.length > 0 && (
            <div style={{ marginTop:14 }}>
              <div style={{ fontSize:10.5, fontWeight:700, color:'var(--muted)', marginBottom:6 }}>TAGS</div>
              <div style={{ display:'flex', flexWrap:'wrap', gap:4 }}>
                {activeConv.tags.map(t => <span key={t} className="tag">{t}</span>)}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
