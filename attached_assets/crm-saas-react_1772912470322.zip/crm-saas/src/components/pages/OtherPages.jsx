// ═══════════════════════════════════════════════════════
// CONTATOS
// ═══════════════════════════════════════════════════════
import { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Badge, CanalIcon, Avatar, Modal, PageHeader, SearchBox } from '../ui';

export function Contatos() {
  const data = useStore(s => s.data);
  const notify = useStore(s => s.notify);
  const setPage = useStore(s => s.setPage);
  const contatos = data.contatos;
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);

  const filtered = contatos.filter(c =>
    !search || c.nome.toLowerCase().includes(search.toLowerCase()) || c.empresa.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader
        title="Contatos"
        subtitle={`${contatos.length} contatos cadastrados`}
        action={<button className="btn-primary" onClick={() => setShowModal(true)}>+ Novo Contato</button>}
      />
      <div style={{ marginBottom:14 }}>
        <SearchBox value={search} onChange={setSearch} placeholder="Buscar contatos..." />
      </div>
      <div className="card" style={{ overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ borderBottom:'1px solid var(--border)', background:'var(--card2)' }}>
              {['Nome','Empresa','Telefone','Email','Canal','Tags','Ações'].map(h => (
                <th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:700, color:'var(--muted)', textTransform:'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(c => (
              <tr key={c.id} style={{ borderBottom:'1px solid var(--border)' }}
                onMouseEnter={e => e.currentTarget.style.background='var(--card2)'}
                onMouseLeave={e => e.currentTarget.style.background='transparent'}
              >
                <td style={{ padding:'10px 14px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:9 }}>
                    <Avatar nome={c.nome} size={30} />
                    <span style={{ fontWeight:600, fontSize:12.5 }}>{c.nome}</span>
                  </div>
                </td>
                <td style={{ padding:'10px 14px', fontSize:12, color:'var(--text2)' }}>{c.empresa}</td>
                <td style={{ padding:'10px 14px', fontSize:12, color:'var(--text2)' }}>{c.phone}</td>
                <td style={{ padding:'10px 14px', fontSize:12, color:'var(--text2)' }}>{c.email}</td>
                <td style={{ padding:'10px 14px' }}><CanalIcon canal={c.canal} /></td>
                <td style={{ padding:'10px 14px' }}>
                  <div style={{ display:'flex', gap:4, flexWrap:'wrap' }}>
                    {c.tags.map(t => <span key={t} className="tag">{t}</span>)}
                  </div>
                </td>
                <td style={{ padding:'10px 14px' }}>
                  <div style={{ display:'flex', gap:4 }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => setPage('inbox')}>💬</button>
                    <button className="btn btn-ghost btn-sm">✏️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showModal && (
        <Modal title="Novo Contato" onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); notify('Contato criado'); }}>
          <div className="fg"><label className="fl">Nome</label><input className="fc" placeholder="Nome completo" /></div>
          <div className="fg"><label className="fl">Empresa</label><input className="fc" placeholder="Empresa" /></div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div className="fg"><label className="fl">Telefone</label><input className="fc" placeholder="(11) 99999-0000" /></div>
            <div className="fg"><label className="fl">Email</label><input className="fc" placeholder="email@exemplo.com" /></div>
          </div>
          <div className="fg"><label className="fl">Canal</label><select className="fc"><option>WhatsApp</option><option>Instagram</option><option>Chat</option><option>Email</option></select></div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// AGENDA
// ═══════════════════════════════════════════════════════
export function Agenda() {
  const data = useStore(s => s.data);
  const notify = useStore(s => s.notify);
  const [showModal, setShowModal] = useState(false);
  const agenda = data.agenda;

  const tipos = { ligacao:'📞', reuniao:'👥', followup:'🔔', tarefa:'✅' };

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader
        title="Agenda"
        subtitle="Gerencie seus compromissos"
        action={<button className="btn-primary" onClick={() => setShowModal(true)}>+ Novo Compromisso</button>}
      />
      {['Hoje','Amanhã'].map(dia => {
        const items = agenda.filter(a => a.data === dia);
        return (
          <div key={dia} style={{ marginBottom:20 }}>
            <div style={{ fontSize:11.5, fontWeight:700, color:'var(--muted)', textTransform:'uppercase', marginBottom:10 }}>{dia}</div>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {items.map((ev, i) => (
                <div key={i} className="card" style={{ padding:'14px 16px', display:'flex', alignItems:'center', gap:14 }}>
                  <div style={{ fontSize:24 }}>{tipos[ev.tipo] || '📅'}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:600, fontSize:13, marginBottom:2 }}>{ev.titulo}</div>
                    <div style={{ fontSize:11.5, color:'var(--muted)' }}>{ev.lead}</div>
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <div style={{ fontSize:13, fontWeight:700, color:'var(--accent3)', marginBottom:4 }}>{ev.hora}</div>
                    <Badge label={ev.status} />
                  </div>
                </div>
              ))}
              {items.length === 0 && <div style={{ color:'var(--muted)', fontSize:12.5, padding:'10px 0' }}>Nenhum compromisso</div>}
            </div>
          </div>
        );
      })}
      {showModal && (
        <Modal title="Novo Compromisso" onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); notify('Compromisso criado'); }}>
          <div className="fg"><label className="fl">Título</label><input className="fc" placeholder="Ex: Call com cliente" /></div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div className="fg"><label className="fl">Data</label><input className="fc" type="date" /></div>
            <div className="fg"><label className="fl">Hora</label><input className="fc" type="time" defaultValue="09:00" /></div>
          </div>
          <div className="fg"><label className="fl">Tipo</label><select className="fc"><option>Ligação</option><option>Reunião</option><option>Tarefa</option><option>Follow-up</option></select></div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// FINANCEIRO
// ═══════════════════════════════════════════════════════
export function Financeiro() {
  const data = useStore(s => s.data);
  const notify = useStore(s => s.notify);
  const [showModal, setShowModal] = useState(false);
  const fin = data.financeiro;
  const fmt = n => (+n).toLocaleString('pt-BR');

  const entradas = fin.filter(f => f.tipo==='entrada').reduce((a,f) => a+f.valor, 0);
  const saidas   = fin.filter(f => f.tipo==='saida'  ).reduce((a,f) => a+f.valor, 0);

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader
        title="Financeiro"
        subtitle="Controle de receitas e despesas"
        action={<button className="btn-primary" onClick={() => setShowModal(true)}>+ Novo Lançamento</button>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:20 }}>
        <div className="card" style={{ padding:16 }}>
          <div style={{ fontSize:10.5, fontWeight:700, color:'var(--muted)', textTransform:'uppercase', marginBottom:6 }}>Entradas</div>
          <div style={{ fontSize:22, fontWeight:900, color:'var(--green)' }}>R$ {fmt(entradas)}</div>
        </div>
        <div className="card" style={{ padding:16 }}>
          <div style={{ fontSize:10.5, fontWeight:700, color:'var(--muted)', textTransform:'uppercase', marginBottom:6 }}>Saídas</div>
          <div style={{ fontSize:22, fontWeight:900, color:'var(--red)' }}>R$ {fmt(saidas)}</div>
        </div>
        <div className="card" style={{ padding:16 }}>
          <div style={{ fontSize:10.5, fontWeight:700, color:'var(--muted)', textTransform:'uppercase', marginBottom:6 }}>Saldo</div>
          <div style={{ fontSize:22, fontWeight:900, color: entradas-saidas >= 0 ? 'var(--green)' : 'var(--red)' }}>R$ {fmt(entradas-saidas)}</div>
        </div>
      </div>
      <div className="card" style={{ overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ borderBottom:'1px solid var(--border)', background:'var(--card2)' }}>
              {['Descrição','Tipo','Categoria','Valor','Data','Status'].map(h => (
                <th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:700, color:'var(--muted)', textTransform:'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {fin.map((f,i) => (
              <tr key={i} style={{ borderBottom:'1px solid var(--border)' }}
                onMouseEnter={e => e.currentTarget.style.background='var(--card2)'}
                onMouseLeave={e => e.currentTarget.style.background='transparent'}
              >
                <td style={{ padding:'10px 14px', fontWeight:600, fontSize:12.5 }}>{f.desc}</td>
                <td style={{ padding:'10px 14px' }}>
                  <span style={{ color: f.tipo==='entrada' ? 'var(--green)' : 'var(--red)', fontSize:12, fontWeight:700 }}>
                    {f.tipo==='entrada' ? '↑ Entrada' : '↓ Saída'}
                  </span>
                </td>
                <td style={{ padding:'10px 14px', fontSize:12, color:'var(--text2)' }}>{f.cat}</td>
                <td style={{ padding:'10px 14px', fontWeight:700, color: f.tipo==='entrada' ? 'var(--green)' : 'var(--red)' }}>
                  {f.tipo==='entrada' ? '+' : '-'} R$ {fmt(f.valor)}
                </td>
                <td style={{ padding:'10px 14px', fontSize:11.5, color:'var(--muted)' }}>{f.data}</td>
                <td style={{ padding:'10px 14px' }}><Badge label={f.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showModal && (
        <Modal title="Novo Lançamento" onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); notify('Lançamento salvo'); }}>
          <div className="fg"><label className="fl">Descrição</label><input className="fc" placeholder="Ex: Pagamento assinatura" /></div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div className="fg"><label className="fl">Tipo</label><select className="fc"><option>Entrada</option><option>Saída</option></select></div>
            <div className="fg"><label className="fl">Valor</label><input className="fc" placeholder="R$ 0" /></div>
          </div>
          <div className="fg"><label className="fl">Categoria</label><input className="fc" placeholder="Ex: Vendas, Infra..." /></div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// CAMPANHAS
// ═══════════════════════════════════════════════════════
export function Campanhas() {
  const data = useStore(s => s.data);
  const notify = useStore(s => s.notify);
  const [showModal, setShowModal] = useState(false);
  const campanhas = data.campanhas;

  const statusColor = { completed:'b-green', running:'b-blue', scheduled:'b-purple', draft:'b-muted' };
  const statusLabel = { completed:'Concluída', running:'Rodando', scheduled:'Agendada', draft:'Rascunho' };
  const fmt = n => (+n).toLocaleString('pt-BR');

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader
        title="Campanhas"
        subtitle={`${campanhas.length} campanhas criadas`}
        action={<button className="btn-primary" onClick={() => setShowModal(true)}>+ Nova Campanha</button>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:14 }}>
        {campanhas.map((camp, i) => {
          const pct = camp.sent > 0 ? Math.round((camp.read / camp.sent) * 100) : 0;
          return (
            <div key={i} className="card" style={{ padding:16 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
                <div>
                  <div style={{ fontWeight:700, fontSize:13, marginBottom:4 }}>{camp.nome}</div>
                  <div style={{ fontSize:11, color:'var(--muted)' }}>{camp.segmento} · {camp.data}</div>
                </div>
                <Badge label={statusLabel[camp.status]} color={statusColor[camp.status]} />
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:12 }}>
                {[['Total',camp.total],['Enviados',camp.sent],['Lidos',camp.read],['Respostas',camp.replies]].map(([k,v]) => (
                  <div key={k} style={{ textAlign:'center', background:'var(--card2)', borderRadius:8, padding:'8px 4px' }}>
                    <div style={{ fontSize:15, fontWeight:800 }}>{fmt(v)}</div>
                    <div style={{ fontSize:10, color:'var(--muted)' }}>{k}</div>
                  </div>
                ))}
              </div>
              {camp.sent > 0 && (
                <div>
                  <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, color:'var(--muted)', marginBottom:4 }}>
                    <span>Taxa de leitura</span><span style={{ fontWeight:700, color:'var(--accent3)' }}>{pct}%</span>
                  </div>
                  <div className="progress"><div className="progress-bar" style={{ width:`${pct}%` }} /></div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      {showModal && (
        <Modal title="Nova Campanha" onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); notify('Campanha criada'); }}>
          <div className="fg"><label className="fl">Nome da Campanha</label><input className="fc" placeholder="Ex: Promo Março" /></div>
          <div className="fg"><label className="fl">Canal</label><select className="fc"><option>WhatsApp</option><option>Instagram</option></select></div>
          <div className="fg"><label className="fl">Segmento</label><select className="fc"><option>Todos os contatos</option><option>Leads Quentes</option><option>Clientes Ativos</option></select></div>
          <div className="fg"><label className="fl">Mensagem</label><textarea className="fc" rows={4} placeholder="Digite a mensagem da campanha..." /></div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// AUTOMAÇÕES
// ═══════════════════════════════════════════════════════
export function Automacoes() {
  const data = useStore(s => s.data);
  const notify = useStore(s => s.notify);
  const automacoes = data.automacoes;
  const [activeId, setActiveId] = useState(null);

  const nodeTypes = {
    trigger:'🎯', delay:'⏱', send_message:'💬', assign_agent:'👤',
    condition:'🔀', tag_lead:'🏷', ai_response:'🤖', update_lead:'✏️',
    notify_agent:'🔔', end:'🏁',
  };
  const nodeColors = {
    trigger:'var(--green)', delay:'var(--blue)', send_message:'var(--accent3)',
    condition:'var(--yellow)', end:'var(--muted)', ai_response:'var(--lilac)',
    assign_agent:'var(--accent2)', tag_lead:'var(--yellow)',
  };

  const active = automacoes[activeId];

  return (
    <div style={{ display:'flex', height:'100%', overflow:'hidden' }}>
      {/* List */}
      <div style={{ width:280, borderRight:'1px solid var(--border)', overflowY:'auto', padding:16 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
          <div style={{ fontWeight:700, fontSize:13 }}>Automações</div>
          <button className="btn-primary btn-sm" onClick={() => notify('Editor de automação em breve')}>+</button>
        </div>
        {automacoes.map((auto, i) => (
          <div key={i}
            onClick={() => setActiveId(i)}
            style={{
              padding:'12px', marginBottom:8,
              background: activeId === i ? 'var(--accentBg)' : 'var(--card)',
              border:`1.5px solid ${activeId === i ? 'var(--accentBd)' : 'var(--border)'}`,
              borderRadius:10, cursor:'pointer',
            }}
          >
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
              <div style={{ fontWeight:600, fontSize:12.5 }}>{auto.nome}</div>
              <Badge label={auto.status === 'active' ? 'Ativo' : 'Pausado'} color={auto.status === 'active' ? 'b-green' : 'b-yellow'} />
            </div>
            <div style={{ fontSize:11, color:'var(--muted)', marginBottom:6 }}>{auto.trigger}</div>
            <div style={{ fontSize:11, color:'var(--text2)' }}>🔁 {auto.execucoes} execuções · {auto.passos} passos</div>
          </div>
        ))}
      </div>

      {/* Canvas */}
      <div style={{ flex:1, overflow:'auto', background:'var(--bg2)', position:'relative' }}
        style={{ flex:1, overflow:'auto', backgroundImage:'radial-gradient(circle,var(--border) 1px,transparent 1px)', backgroundSize:'24px 24px', position:'relative' }}
      >
        {active ? (
          <div style={{ padding:30 }}>
            <div style={{ fontWeight:700, fontSize:14, marginBottom:4 }}>{active.nome}</div>
            <div style={{ fontSize:12, color:'var(--muted)', marginBottom:24 }}>{active.trigger}</div>
            <div style={{ display:'flex', flexDirection:'column', alignItems:'flex-start', gap:0 }}>
              {active.nodes.map((node, i) => (
                <div key={node.id} style={{ display:'flex', flexDirection:'column', alignItems:'flex-start' }}>
                  <div style={{
                    background:'var(--card)',
                    border:`2px solid ${nodeColors[node.type] || 'var(--border2)'}`,
                    borderRadius:12, padding:'12px 16px', minWidth:220,
                    boxShadow:'0 2px 12px rgba(0,0,0,.2)',
                  }}>
                    <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:4 }}>
                      <span style={{ fontSize:16 }}>{nodeTypes[node.type] || '●'}</span>
                      <span style={{ fontWeight:700, fontSize:12.5 }}>{node.label}</span>
                    </div>
                    {node.config?.content && <div style={{ fontSize:11, color:'var(--muted2)', fontStyle:'italic' }}>"{node.config.content.slice(0,50)}..."</div>}
                    {node.config?.value !== undefined && node.config?.unit && <div style={{ fontSize:11, color:'var(--muted2)' }}>Aguardar {node.config.value} {node.config.unit}</div>}
                  </div>
                  {i < active.nodes.length - 1 && (
                    <div style={{ width:2, height:24, background:'var(--border2)', marginLeft:20 }} />
                  )}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%', color:'var(--muted)' }}>
            <div style={{ textAlign:'center' }}>
              <div style={{ fontSize:40, marginBottom:12 }}>⟳</div>
              <div>Selecione uma automação para visualizar</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// BASE DE IA
// ═══════════════════════════════════════════════════════
export function IA() {
  const data = useStore(s => s.data);
  const notify = useStore(s => s.notify);
  const kb = data.kb;
  const [showModal, setShowModal] = useState(false);
  const [testInput, setTestInput] = useState('');
  const [testOutput, setTestOutput] = useState('');

  function testIA() {
    if (!testInput) return;
    setTestOutput('Processando...');
    setTimeout(() => {
      setTestOutput(`Baseado na base de conhecimento: O plano Pro custa R$ 497/mês e inclui até 10 usuários, WhatsApp Business API, automações ilimitadas e suporte prioritário. Temos 14 dias de trial grátis.`);
    }, 1000);
  }

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader
        title="Base de IA"
        subtitle="Gerencie o conhecimento do seu assistente"
        action={<button className="btn-primary" onClick={() => setShowModal(true)}>+ Novo Documento</button>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        {/* Docs */}
        <div>
          <div style={{ fontWeight:700, fontSize:13, marginBottom:12 }}>Documentos Indexados</div>
          {kb.map((doc, i) => (
            <div key={i} className="card" style={{ padding:'12px 14px', marginBottom:8, display:'flex', gap:12, alignItems:'center' }}>
              <div style={{ fontSize:20 }}>{doc.tipo==='product'?'📦':doc.tipo==='faq'?'❓':'📄'}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:600, fontSize:12.5 }}>{doc.titulo}</div>
                <div style={{ fontSize:11, color:'var(--muted)' }}>{doc.cat} · {doc.palavras} palavras · atualizado {doc.updated}</div>
              </div>
              <Badge label={doc.status==='indexed'?'Indexado':'Pendente'} color={doc.status==='indexed'?'b-green':'b-yellow'} />
            </div>
          ))}
        </div>

        {/* Test */}
        <div>
          <div style={{ fontWeight:700, fontSize:13, marginBottom:12 }}>Testar IA</div>
          <div className="card" style={{ padding:16 }}>
            <div className="fg">
              <label className="fl">Pergunta de teste</label>
              <textarea className="fc" rows={3} placeholder="Ex: Qual o preço do plano Pro?" value={testInput} onChange={e => setTestInput(e.target.value)} />
            </div>
            <button className="btn-primary" style={{ width:'100%', justifyContent:'center' }} onClick={testIA}>🤖 Testar IA</button>
            {testOutput && (
              <div style={{ marginTop:14, background:'var(--card2)', border:'1px solid var(--border)', borderRadius:10, padding:'12px', fontSize:12.5, lineHeight:1.6 }}>
                <div style={{ fontSize:10.5, fontWeight:700, color:'var(--muted)', marginBottom:6 }}>RESPOSTA DA IA</div>
                {testOutput}
              </div>
            )}
          </div>

          {/* Stats */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginTop:14 }}>
            {[['Documentos',kb.length],['Indexados',kb.filter(d=>d.status==='indexed').length],['Consultas hoje',247],['Precisão','94%']].map(([k,v]) => (
              <div key={k} className="card" style={{ padding:'12px 14px' }}>
                <div style={{ fontSize:10.5, color:'var(--muted)', fontWeight:700, marginBottom:4 }}>{k.toUpperCase()}</div>
                <div style={{ fontSize:20, fontWeight:900 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {showModal && (
        <Modal title="Novo Documento" onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); notify('Documento adicionado à base'); }}>
          <div className="fg"><label className="fl">Título</label><input className="fc" placeholder="Ex: Política de preços" /></div>
          <div className="fg"><label className="fl">Categoria</label><select className="fc"><option>Vendas</option><option>Suporte</option><option>Processos</option><option>Jurídico</option></select></div>
          <div className="fg"><label className="fl">Conteúdo</label><textarea className="fc" rows={6} placeholder="Cole ou escreva o conteúdo do documento..." /></div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// CONEXÕES
// ═══════════════════════════════════════════════════════
export function Conexoes() {
  const data = useStore(s => s.data);
  const removeConexao = useStore(s => s.removeConexao);
  const notify = useStore(s => s.notify);
  const [showModal, setShowModal] = useState(false);
  const conexoes = data.conexoes || [];

  const canalIcon = { whatsapp:'💚', instagram:'📸', chat:'💬' };

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader
        title="Conexões"
        subtitle="Gerencie seus canais de comunicação"
        action={<button className="btn-primary" onClick={() => setShowModal(true)}>+ Nova Conexão</button>}
      />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:14 }}>
        {conexoes.map(conn => (
          <div key={conn.id} className="card" style={{ padding:16 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
              <div style={{ display:'flex', gap:10, alignItems:'center' }}>
                <div style={{ fontSize:28 }}>{canalIcon[conn.tipo]||'📡'}</div>
                <div>
                  <div style={{ fontWeight:700, fontSize:13 }}>{conn.nome}</div>
                  <div style={{ fontSize:11.5, color:'var(--muted)' }}>{conn.numero}</div>
                </div>
              </div>
              <Badge label={conn.status === 'connected' ? 'Conectado' : 'Desconectado'} color={conn.status === 'connected' ? 'b-green' : 'b-red'} />
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
              <div style={{ fontSize:11.5, color:'var(--muted)' }}>{conn.msgs?.toLocaleString('pt-BR')} mensagens enviadas</div>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <button className="btn btn-sm" style={{ flex:1, justifyContent:'center' }}>⚙ Configurar</button>
              <button className="btn btn-ghost btn-sm" onClick={() => { removeConexao(conn.id); notify('Conexão removida'); }}>🗑</button>
            </div>
          </div>
        ))}
        {/* Add placeholder */}
        <div className="card" style={{ padding:16, border:'2px dashed var(--border)', background:'transparent', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:10, cursor:'pointer', minHeight:140 }}
          onClick={() => setShowModal(true)}>
          <div style={{ fontSize:28, opacity:.4 }}>+</div>
          <div style={{ fontSize:12.5, color:'var(--muted)' }}>Adicionar nova conexão</div>
        </div>
      </div>
      {showModal && (
        <Modal title="Nova Conexão" onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); notify('QR Code seria exibido em produção'); }}>
          <div className="fg">
            <label className="fl">Tipo de Canal</label>
            <select className="fc"><option>WhatsApp</option><option>Instagram</option><option>Chat no Site</option></select>
          </div>
          <div className="fg"><label className="fl">Nome da Conexão</label><input className="fc" placeholder="Ex: WhatsApp Comercial" /></div>
          <div style={{ background:'var(--yellowDim)', border:'1px solid var(--yellowDim)', borderRadius:10, padding:'10px 12px', fontSize:12, color:'var(--yellow)' }}>
            ⚠️ Em produção, um QR Code seria exibido aqui para escanear com o WhatsApp.
          </div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// USUÁRIOS
// ═══════════════════════════════════════════════════════
export function Usuarios() {
  const data = useStore(s => s.data);
  const notify = useStore(s => s.notify);
  const [showModal, setShowModal] = useState(false);
  const usuarios = data.usuarios;

  const roleLabel = { super_admin:'Super Admin', admin:'Admin', user:'Usuário' };
  const roleColor = { super_admin:'b-blue', admin:'b-purple', user:'b-muted' };

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader
        title="Usuários"
        subtitle={`${usuarios.filter(u=>u.status==='ativo').length} usuários ativos`}
        action={<button className="btn-primary" onClick={() => setShowModal(true)}>+ Convidar Usuário</button>}
      />
      <div className="card" style={{ overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ borderBottom:'1px solid var(--border)', background:'var(--card2)' }}>
              {['Usuário','Cargo','Papel','Status','Último acesso','Ações'].map(h => (
                <th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:700, color:'var(--muted)', textTransform:'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {usuarios.map((u, i) => (
              <tr key={i} style={{ borderBottom:'1px solid var(--border)' }}
                onMouseEnter={e => e.currentTarget.style.background='var(--card2)'}
                onMouseLeave={e => e.currentTarget.style.background='transparent'}
              >
                <td style={{ padding:'10px 14px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                    <div style={{ width:32, height:32, borderRadius:'50%', background:'linear-gradient(135deg,var(--accent),var(--accent2))', display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, fontWeight:700, color:'#fff' }}>
                      {u.nome.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase()}
                    </div>
                    <div>
                      <div style={{ fontWeight:600, fontSize:12.5 }}>{u.nome}</div>
                      <div style={{ fontSize:11, color:'var(--muted)' }}>{u.email}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding:'10px 14px', fontSize:12, color:'var(--text2)' }}>{u.cargo || '—'}</td>
                <td style={{ padding:'10px 14px' }}><Badge label={roleLabel[u.role]} color={roleColor[u.role]} /></td>
                <td style={{ padding:'10px 14px' }}><Badge label={u.status === 'ativo' ? 'Ativo' : 'Convidado'} color={u.status === 'ativo' ? 'b-green' : 'b-yellow'} /></td>
                <td style={{ padding:'10px 14px', fontSize:11.5, color:'var(--muted)' }}>{u.lastAccess}</td>
                <td style={{ padding:'10px 14px' }}>
                  <button className="btn btn-ghost btn-sm">✏️</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showModal && (
        <Modal title="Convidar Usuário" onClose={() => setShowModal(false)} onSave={() => { setShowModal(false); notify('Convite enviado por e-mail'); }}>
          <div className="fg"><label className="fl">E-mail</label><input className="fc" placeholder="nome@empresa.com" /></div>
          <div className="fg"><label className="fl">Papel</label><select className="fc"><option>Usuário</option><option>Admin</option></select></div>
          <div className="fg"><label className="fl">Cargo</label><input className="fc" placeholder="Ex: SDR, Closer..." /></div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// INTEGRAÇÕES
// ═══════════════════════════════════════════════════════
export function Integracoes() {
  const data = useStore(s => s.data);
  const notify = useStore(s => s.notify);
  const integracoes = data.integracoes || [];

  const statusColor = { ativo:'b-green', inativo:'b-muted', configurar:'b-yellow' };
  const statusLabel = { ativo:'Ativo', inativo:'Inativo', configurar:'Configurar' };

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader title="Integrações" subtitle="Conecte com suas ferramentas favoritas" />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:12 }}>
        {integracoes.map((int, i) => (
          <div key={i} className="card" style={{ padding:16, display:'flex', gap:14, alignItems:'center' }}>
            <div style={{ fontSize:28, width:44, height:44, background:'var(--card2)', borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>{int.icon}</div>
            <div style={{ flex:1 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                <div style={{ fontWeight:700, fontSize:13 }}>{int.nome}</div>
                <Badge label={statusLabel[int.status]} color={statusColor[int.status]} />
              </div>
              <div style={{ fontSize:11.5, color:'var(--muted)', marginBottom:10 }}>{int.desc}</div>
              <div style={{ display:'flex', gap:6 }}>
                {int.status === 'ativo' ? (
                  <>
                    <button className="btn btn-ghost btn-sm">⚙ Configurar</button>
                    <button className="btn btn-ghost btn-sm" style={{ color:'var(--red)' }} onClick={() => notify('Integração desconectada')}>Desconectar</button>
                  </>
                ) : (
                  <button className="btn-primary btn-sm" onClick={() => notify(`Abrindo configuração de ${int.nome}`)}>Conectar</button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// BILLING
// ═══════════════════════════════════════════════════════
export function Billing() {
  const data = useStore(s => s.data);
  const upgradePlan = useStore(s => s.upgradePlan);
  const notify = useStore(s => s.notify);
  const billing = data.billing;
  const fmt = n => (+n).toLocaleString('pt-BR');

  const plans = [
    { id:'starter', nome:'Starter', preco:197, desc:'Para equipes pequenas', features:['3 usuários','10.000 msgs/mês','1 conexão WhatsApp','Automações básicas'] },
    { id:'pro',     nome:'Pro',     preco:497, desc:'Para times em crescimento', features:['10 usuários','30.000 msgs/mês','3 conexões','Automações + IA','Relatórios avançados'], popular:true },
    { id:'enterprise', nome:'Enterprise', preco:997, desc:'Para grandes operações', features:['Usuários ilimitados','Msgs ilimitadas','Conexões ilimitadas','Suporte dedicado','SLA garantido'] },
  ];

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader title="Billing & Planos" subtitle="Gerencie sua assinatura" />

      {/* Current Plan */}
      <div className="card" style={{ padding:16, marginBottom:20, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <div style={{ fontSize:11, color:'var(--muted)', fontWeight:700, marginBottom:4 }}>PLANO ATUAL</div>
          <div style={{ fontSize:18, fontWeight:900, marginBottom:4 }}>Plano {billing.plan}</div>
          <Badge label={billing.status} color={billing.status.includes('Trial') ? 'b-yellow' : 'b-green'} />
          {billing.trialDays && <span style={{ marginLeft:8, fontSize:11.5, color:'var(--muted)' }}>{billing.trialDays} dias restantes</span>}
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:22, fontWeight:900, color:'var(--accent3)' }}>R$ {fmt(billing.mrr)}<span style={{ fontSize:12, fontWeight:400, color:'var(--muted)' }}>/mês</span></div>
          <button className="btn btn-sm" style={{ marginTop:8 }} onClick={() => notify('Abrindo portal Stripe...')}>Portal de Cobrança</button>
        </div>
      </div>

      {/* Usage */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12, marginBottom:24 }}>
        {[
          { label:'Usuários', used:billing.seatsUsed, limit:billing.seatsLimit },
          { label:'Mensagens', used:billing.msgsSent, limit:billing.msgsLimit },
          { label:'Contatos', used:billing.contactsUsed, limit:billing.contactsLimit },
        ].map(item => {
          const pct = item.limit > 0 ? (item.used/item.limit)*100 : 0;
          return (
            <div key={item.label} className="card" style={{ padding:14 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
                <div style={{ fontSize:12, fontWeight:700 }}>{item.label}</div>
                <div style={{ fontSize:11.5, color:'var(--muted)' }}>
                  {fmt(item.used)} / {item.limit === -1 ? '∞' : fmt(item.limit)}
                </div>
              </div>
              {item.limit > 0 && (
                <div className="progress"><div className="progress-bar" style={{ width:`${pct}%`, background: pct > 80 ? 'var(--red)' : undefined }} /></div>
              )}
            </div>
          );
        })}
      </div>

      {/* Plans */}
      <div style={{ fontWeight:700, fontSize:14, marginBottom:14 }}>Alterar Plano</div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:14 }}>
        {plans.map(plan => (
          <div key={plan.id} className="card" style={{ padding:18, position:'relative', border: plan.popular ? '2px solid var(--accent2)' : undefined }}>
            {plan.popular && (
              <div style={{ position:'absolute', top:-10, left:'50%', transform:'translateX(-50%)', background:'linear-gradient(135deg,var(--accent),var(--accent2))', color:'#fff', fontSize:9.5, fontWeight:700, padding:'2px 10px', borderRadius:20 }}>
                POPULAR
              </div>
            )}
            <div style={{ fontWeight:800, fontSize:15, marginBottom:4 }}>{plan.nome}</div>
            <div style={{ fontSize:11.5, color:'var(--muted)', marginBottom:12 }}>{plan.desc}</div>
            <div style={{ fontSize:24, fontWeight:900, marginBottom:14 }}>R$ {fmt(plan.preco)}<span style={{ fontSize:12, fontWeight:400, color:'var(--muted)' }}>/mês</span></div>
            <div style={{ marginBottom:16 }}>
              {plan.features.map(f => (
                <div key={f} style={{ display:'flex', gap:6, alignItems:'center', marginBottom:6, fontSize:12 }}>
                  <span style={{ color:'var(--green)' }}>✓</span> {f}
                </div>
              ))}
            </div>
            <button
              onClick={() => { upgradePlan(plan.id); notify(`Upgrade para ${plan.nome} realizado!`); }}
              className={plan.popular ? 'btn-primary' : 'btn'}
              style={{ width:'100%', justifyContent:'center' }}
              disabled={billing.plan === plan.nome}
            >
              {billing.plan === plan.nome ? '✓ Plano atual' : `Assinar ${plan.nome}`}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// RELATÓRIOS
// ═══════════════════════════════════════════════════════
export function Relatorios() {
  const data = useStore(s => s.data);
  const leads = data.leads;
  const fin = data.financeiro;
  const campanhas = data.campanhas;
  const fmt = n => (+n).toLocaleString('pt-BR');

  const totalReceita = fin.filter(f=>f.tipo==='entrada').reduce((a,f)=>a+f.valor,0);
  const totalLeads = leads.length;
  const taxaConversao = Math.round((leads.filter(l=>l.status==='ganho').length / totalLeads)*100);

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader title="Relatórios" subtitle="Visão analítica do seu negócio" />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:20 }}>
        {[
          { label:'Receita Total', value:`R$ ${fmt(totalReceita)}`, color:'var(--green)' },
          { label:'Total de Leads', value:totalLeads, color:'var(--blue)' },
          { label:'Taxa de Conversão', value:`${taxaConversao}%`, color:'var(--accent3)' },
          { label:'Msgs Enviadas', value:fmt(data.billing.msgsSent), color:'var(--yellow)' },
        ].map(item => (
          <div key={item.label} className="card" style={{ padding:16 }}>
            <div style={{ fontSize:10.5, color:'var(--muted)', fontWeight:700, textTransform:'uppercase', marginBottom:6 }}>{item.label}</div>
            <div style={{ fontSize:22, fontWeight:900, color:item.color }}>{item.value}</div>
          </div>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        {/* Leads por status */}
        <div className="card" style={{ padding:16 }}>
          <div style={{ fontWeight:700, fontSize:13, marginBottom:14 }}>Leads por Status</div>
          {Object.entries(
            leads.reduce((acc, l) => { acc[l.status] = (acc[l.status]||0)+1; return acc; }, {})
          ).map(([status, count]) => (
            <div key={status} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
              <span style={{ fontSize:12.5, color:'var(--text2)' }}>{status}</span>
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <div style={{ width:80, height:6, background:'var(--card3)', borderRadius:10, overflow:'hidden' }}>
                  <div style={{ height:'100%', width:`${(count/leads.length)*100}%`, background:'var(--accent2)', borderRadius:10 }} />
                </div>
                <span style={{ fontSize:12, fontWeight:700, width:20, textAlign:'right' }}>{count}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Performance de campanhas */}
        <div className="card" style={{ padding:16 }}>
          <div style={{ fontWeight:700, fontSize:13, marginBottom:14 }}>Performance de Campanhas</div>
          {campanhas.filter(c=>c.sent>0).map((c,i) => (
            <div key={i} style={{ marginBottom:12 }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                <span style={{ fontSize:12.5 }}>{c.nome}</span>
                <span style={{ fontSize:11.5, color:'var(--accent3)', fontWeight:700 }}>{Math.round((c.read/c.sent)*100)}% leitura</span>
              </div>
              <div className="progress"><div className="progress-bar" style={{ width:`${(c.read/c.sent)*100}%` }} /></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// CONFIGURAÇÕES
// ═══════════════════════════════════════════════════════
export function Configuracoes() {
  const notify = useStore(s => s.notify);
  const [tab, setTab] = useState('geral');

  const tabs = ['geral','notificacoes','seguranca','aparencia'];
  const tabLabel = { geral:'Geral', notificacoes:'Notificações', seguranca:'Segurança', aparencia:'Aparência' };

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader title="Configurações" />
      <div style={{ display:'flex', gap:4, marginBottom:20 }}>
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)}
            style={{ padding:'6px 14px', borderRadius:8, fontSize:12.5, fontWeight:600, cursor:'pointer', background: tab===t ? 'var(--accentBg)' : 'var(--card2)', border:`1px solid ${tab===t ? 'var(--accentBd)' : 'var(--border)'}`, color: tab===t ? 'var(--accent3)' : 'var(--muted2)' }}>
            {tabLabel[t]}
          </button>
        ))}
      </div>
      <div className="card" style={{ padding:20, maxWidth:560 }}>
        {tab === 'geral' && <>
          <div className="fg"><label className="fl">Nome da Empresa</label><input className="fc" defaultValue="Minha Empresa LTDA" /></div>
          <div className="fg"><label className="fl">Domínio</label><input className="fc" defaultValue="minhaempresa.com.br" /></div>
          <div className="fg"><label className="fl">Fuso Horário</label><select className="fc"><option>America/Sao_Paulo (GMT-3)</option><option>America/Manaus (GMT-4)</option></select></div>
          <div className="fg"><label className="fl">Idioma</label><select className="fc"><option>Português (BR)</option><option>English</option></select></div>
        </>}
        {tab === 'notificacoes' && <>
          {['Novas mensagens no Inbox','Lead atualizado','Campanha concluída','Cobrança realizada','Novo usuário convidado'].map(item => (
            <div key={item} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 0', borderBottom:'1px solid var(--border)' }}>
              <span style={{ fontSize:12.5 }}>{item}</span>
              <div className="toggle on" onClick={() => {}} />
            </div>
          ))}
        </>}
        {tab === 'seguranca' && <>
          <div className="fg"><label className="fl">Senha atual</label><input className="fc" type="password" placeholder="••••••••" /></div>
          <div className="fg"><label className="fl">Nova senha</label><input className="fc" type="password" placeholder="••••••••" /></div>
          <div className="fg"><label className="fl">Confirmar nova senha</label><input className="fc" type="password" placeholder="••••••••" /></div>
        </>}
        {tab === 'aparencia' && <>
          <div style={{ marginBottom:14 }}>
            <label className="fl">Tema</label>
            <div style={{ display:'flex', gap:10, marginTop:6 }}>
              {['Escuro','Claro'].map(t => (
                <div key={t} style={{ flex:1, padding:'10px', border:'1.5px solid var(--border)', borderRadius:10, textAlign:'center', cursor:'pointer', fontSize:12.5 }}>{t}</div>
              ))}
            </div>
          </div>
          <div className="fg"><label className="fl">Cor de destaque</label>
            <div style={{ display:'flex', gap:8, marginTop:6 }}>
              {['#7c5cbf','#3b82f6','#10b981','#ef4444','#f59e0b'].map(c => (
                <div key={c} style={{ width:28, height:28, borderRadius:'50%', background:c, cursor:'pointer', border:'2px solid var(--border)' }} />
              ))}
            </div>
          </div>
        </>}
        <button className="btn-primary" style={{ marginTop:10 }} onClick={() => notify('Configurações salvas')}>Salvar Alterações</button>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// PERFIL
// ═══════════════════════════════════════════════════════
export function Perfil() {
  const notify = useStore(s => s.notify);
  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader title="Meu Perfil" />
      <div style={{ maxWidth:500 }}>
        <div className="card" style={{ padding:20, marginBottom:16, display:'flex', gap:16, alignItems:'center' }}>
          <div style={{ width:64, height:64, borderRadius:'50%', background:'linear-gradient(135deg,#7c5cbf,#9b7ee0)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:22, fontWeight:800, color:'#fff' }}>JD</div>
          <div>
            <div style={{ fontSize:16, fontWeight:800 }}>João Dono</div>
            <div style={{ fontSize:12, color:'var(--muted)' }}>joao@empresa.com</div>
            <div style={{ marginTop:4 }}><Badge label="Super Admin" color="b-blue" /></div>
          </div>
        </div>
        <div className="card" style={{ padding:20 }}>
          <div className="fg"><label className="fl">Nome</label><input className="fc" defaultValue="João Dono" /></div>
          <div className="fg"><label className="fl">E-mail</label><input className="fc" defaultValue="joao@empresa.com" /></div>
          <div className="fg"><label className="fl">Telefone</label><input className="fc" defaultValue="+55 11 99999-0000" /></div>
          <div className="fg"><label className="fl">Cargo</label><input className="fc" defaultValue="CEO / Fundador" /></div>
          <button className="btn-primary" onClick={() => notify('Perfil atualizado')}>Salvar Alterações</button>
        </div>
      </div>
    </div>
  );
}
