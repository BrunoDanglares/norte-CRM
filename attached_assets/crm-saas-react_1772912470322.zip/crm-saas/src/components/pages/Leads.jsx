import { useState } from 'react';
import { useStore } from '../../store/useStore';
import { Badge, CanalIcon, Modal, PageHeader, SearchBox, Avatar } from '../ui';
import { STAGES } from '../../data/mockData';

const STATUS_BADGE = {
  novo:'b-blue', contatado:'b-purple', qualificado:'b-teal',
  proposta:'b-yellow', negociacao:'b-purple', ganho:'b-green', perdido:'b-red',
};

export default function Leads() {
  const data = useStore(s => s.data);
  const addLead = useStore(s => s.addLead);
  const updateLead = useStore(s => s.updateLead);
  const deleteLead = useStore(s => s.deleteLead);
  const notify = useStore(s => s.notify);
  const setPage = useStore(s => s.setPage);

  const leads = data.leads;
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [selectedLead, setSelectedLead] = useState(null);
  const [newLead, setNewLead] = useState({ nome:'', contato:'', valor:'', canal:'WhatsApp', status:'novo' });
  const [sortField, setSortField] = useState('data');

  const fmt = n => (+n).toLocaleString('pt-BR');

  const filtered = leads.filter(l => {
    const matchSearch = !search || l.nome.toLowerCase().includes(search.toLowerCase()) || l.contato.toLowerCase().includes(search.toLowerCase());
    const matchStatus = !filterStatus || l.status === filterStatus;
    return matchSearch && matchStatus;
  });

  function handleSave() {
    if (!newLead.nome) return notify('Informe o nome do lead');
    addLead({ ...newLead, data: new Date().toLocaleDateString('pt-BR', { day:'2-digit', month:'2-digit' }), owner:'Ana Costa' });
    setShowModal(false);
    setNewLead({ nome:'', contato:'', valor:'', canal:'WhatsApp', status:'novo' });
    notify('✓ Lead criado com sucesso');
  }

  function openDetail(lead) {
    setSelectedLead(lead);
  }

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>
      <PageHeader
        title="Leads"
        subtitle={`${leads.length} leads no total`}
        action={<button className="btn-primary" onClick={() => setShowModal(true)}>+ Novo Lead</button>}
      />

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10, marginBottom:16 }}>
        {Object.entries(STAGES).slice(0,4).map(([key,s]) => {
          const count = leads.filter(l => l.status === key).length;
          return (
            <div key={key} className="card" style={{ padding:'10px 14px', cursor:'pointer' }} onClick={() => setFilterStatus(filterStatus === key ? '' : key)}>
              <div style={{ fontSize:10.5, fontWeight:700, color:'var(--muted)', textTransform:'uppercase', marginBottom:4 }}>{s.label}</div>
              <div style={{ fontSize:20, fontWeight:900, color:s.color }}>{count}</div>
            </div>
          );
        })}
      </div>

      {/* Filters */}
      <div style={{ display:'flex', gap:10, marginBottom:14, alignItems:'center' }}>
        <SearchBox value={search} onChange={setSearch} placeholder="Buscar leads..." />
        <select className="fc" style={{ width:150 }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">Todos os status</option>
          {Object.entries(STAGES).map(([key,s]) => <option key={key} value={key}>{s.label}</option>)}
        </select>
        <select className="fc" style={{ width:130 }}>
          <option>Todos os canais</option>
          <option>WhatsApp</option>
          <option>Instagram</option>
          <option>Chat</option>
          <option>Email</option>
        </select>
      </div>

      {/* Table */}
      <div className="card" style={{ overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead>
            <tr style={{ borderBottom:'1px solid var(--border)' }}>
              {['Lead','Contato','Valor','Canal','Status','Owner','Data','Ações'].map(h => (
                <th key={h} style={{ padding:'10px 14px', textAlign:'left', fontSize:11, fontWeight:700, color:'var(--muted)', textTransform:'uppercase', background:'var(--card2)' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(lead => (
              <tr key={lead.id} style={{ borderBottom:'1px solid var(--border)', cursor:'pointer' }}
                onMouseEnter={e => e.currentTarget.style.background='var(--card2)'}
                onMouseLeave={e => e.currentTarget.style.background='transparent'}
              >
                <td style={{ padding:'10px 14px' }} onClick={() => openDetail(lead)}>
                  <div style={{ fontWeight:600, fontSize:12.5 }}>{lead.nome}</div>
                </td>
                <td style={{ padding:'10px 14px' }} onClick={() => openDetail(lead)}>
                  <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                    <Avatar nome={lead.contato} size={26} />
                    <span style={{ fontSize:12, color:'var(--text2)' }}>{lead.contato}</span>
                  </div>
                </td>
                <td style={{ padding:'10px 14px' }} onClick={() => openDetail(lead)}>
                  <span style={{ fontWeight:700, color:'var(--accent3)' }}>R$ {fmt(lead.valor)}</span>
                </td>
                <td style={{ padding:'10px 14px' }} onClick={() => openDetail(lead)}>
                  <CanalIcon canal={lead.canal} /> <span style={{ fontSize:11.5, color:'var(--text2)', marginLeft:4 }}>{lead.canal}</span>
                </td>
                <td style={{ padding:'10px 14px' }} onClick={() => openDetail(lead)}>
                  <Badge label={lead.status} />
                </td>
                <td style={{ padding:'10px 14px', fontSize:12, color:'var(--text2)' }} onClick={() => openDetail(lead)}>{lead.owner}</td>
                <td style={{ padding:'10px 14px', fontSize:11.5, color:'var(--muted)' }} onClick={() => openDetail(lead)}>{lead.data}</td>
                <td style={{ padding:'10px 14px' }}>
                  <div style={{ display:'flex', gap:4 }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => setPage('inbox')} title="Inbox">💬</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => openDetail(lead)} title="Editar">✏️</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => { deleteLead(lead.id); notify('Lead removido'); }} title="Remover">🗑</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div style={{ textAlign:'center', padding:'30px', color:'var(--muted)' }}>Nenhum lead encontrado</div>
        )}
      </div>

      {/* Create Modal */}
      {showModal && (
        <Modal title="Novo Lead" onClose={() => setShowModal(false)} onSave={handleSave} saveLabel="Criar Lead">
          <div className="fg">
            <label className="fl">Nome do Lead</label>
            <input className="fc" placeholder="Ex: Empresa XYZ" value={newLead.nome} onChange={e => setNewLead({...newLead, nome:e.target.value})} />
          </div>
          <div className="fg">
            <label className="fl">Contato</label>
            <input className="fc" placeholder="Nome do contato" value={newLead.contato} onChange={e => setNewLead({...newLead, contato:e.target.value})} />
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div className="fg">
              <label className="fl">Valor Estimado</label>
              <input className="fc" placeholder="R$ 0" value={newLead.valor} onChange={e => setNewLead({...newLead, valor:e.target.value})} />
            </div>
            <div className="fg">
              <label className="fl">Canal</label>
              <select className="fc" value={newLead.canal} onChange={e => setNewLead({...newLead, canal:e.target.value})}>
                <option>WhatsApp</option><option>Instagram</option><option>Chat</option><option>Email</option>
              </select>
            </div>
          </div>
          <div className="fg">
            <label className="fl">Status</label>
            <select className="fc" value={newLead.status} onChange={e => setNewLead({...newLead, status:e.target.value})}>
              {Object.entries(STAGES).map(([k,s]) => <option key={k} value={k}>{s.label}</option>)}
            </select>
          </div>
        </Modal>
      )}

      {/* Detail Modal */}
      {selectedLead && (
        <Modal title={selectedLead.nome} onClose={() => setSelectedLead(null)} onSave={() => { setSelectedLead(null); notify('Lead atualizado'); }}>
          <div style={{ display:'grid', gap:10 }}>
            <div style={{ display:'flex', gap:8 }}>
              <Badge label={selectedLead.status} />
              <CanalIcon canal={selectedLead.canal} />
              <span style={{ fontSize:12, color:'var(--muted)' }}>{selectedLead.canal}</span>
            </div>
            <div className="card" style={{ padding:'12px 14px' }}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
                <div><div style={{ fontSize:10.5, color:'var(--muted)', fontWeight:700, marginBottom:2 }}>CONTATO</div><div style={{ fontSize:13 }}>{selectedLead.contato}</div></div>
                <div><div style={{ fontSize:10.5, color:'var(--muted)', fontWeight:700, marginBottom:2 }}>VALOR</div><div style={{ fontSize:13, fontWeight:800, color:'var(--accent3)' }}>R$ {(+selectedLead.valor).toLocaleString('pt-BR')}</div></div>
                <div><div style={{ fontSize:10.5, color:'var(--muted)', fontWeight:700, marginBottom:2 }}>OWNER</div><div style={{ fontSize:13 }}>{selectedLead.owner}</div></div>
                <div><div style={{ fontSize:10.5, color:'var(--muted)', fontWeight:700, marginBottom:2 }}>DATA</div><div style={{ fontSize:13 }}>{selectedLead.data}</div></div>
              </div>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <button className="btn btn-sm" onClick={() => { setPage('inbox'); setSelectedLead(null); }}>💬 Abrir Inbox</button>
              <button className="btn btn-sm" onClick={() => { setPage('agenda'); setSelectedLead(null); }}>📅 Agendar</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
