import { useStore } from '../../store/useStore';
import { StatCard, Badge, CanalIcon } from '../ui';
import { STAGES } from '../../data/mockData';

export default function Dashboard() {
  const setPage = useStore(s => s.setPage);
  const data = useStore(s => s.data);
  const leads = data.leads;
  const conversations = data.conversations;
  const agenda = data.agenda;

  const totalLeads = leads.length;
  const totalWon = leads.filter(l => l.status === 'ganho').length;
  const totalValue = leads.reduce((a, l) => a + l.valor, 0);
  const unreadMsgs = conversations.reduce((a, c) => a + (c.unread || 0), 0);

  const fmt = n => (+n).toLocaleString('pt-BR');

  const stageGroups = {};
  leads.forEach(l => { stageGroups[l.status] = (stageGroups[l.status] || 0) + 1; });

  return (
    <div style={{ padding:'20px 24px', overflowY:'auto', height:'100%' }}>

      {/* Header */}
      <div style={{ marginBottom:20 }}>
        <h2 style={{ fontSize:18, fontWeight:900, marginBottom:4 }}>Bom dia, João! 👋</h2>
        <p style={{ color:'var(--muted)', fontSize:12.5 }}>
          Hoje é {new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long'})}
        </p>
      </div>

      {/* Quick Actions */}
      <div style={{ display:'flex', gap:8, marginBottom:20 }}>
        <button className="btn-primary btn-sm" onClick={() => setPage('leads')}>+ Novo Lead</button>
        <button className="btn btn-sm" onClick={() => setPage('inbox')}>
          💬 Inbox {unreadMsgs > 0 && <span style={{background:'#ef4444',color:'#fff',borderRadius:10,padding:'1px 5px',fontSize:'9.5px',marginLeft:3}}>{unreadMsgs}</span>}
        </button>
        <button className="btn btn-sm" onClick={() => setPage('campanhas')}>📢 Campanha</button>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:20 }}>
        <StatCard title="Total de Leads"     value={fmt(totalLeads)} sub="↑ 12% vs mês anterior" dir="up" icon="◎" bg="var(--blueDim)"   color="var(--blue)"   />
        <StatCard title="Negócios Fechados"  value={totalWon}        sub="↑ 8% vs mês anterior"  dir="up" icon="✓" bg="var(--greenDim)"  color="var(--green)"  />
        <StatCard title="Receita no Mês"     value={`R$ ${fmt(totalValue)}`} sub="↑ 23% vs mês anterior" dir="up" icon="◇" bg="var(--accentBg)" color="var(--accent3)" />
        <StatCard title="Msgs não lidas"     value={unreadMsgs}      sub={`${conversations.filter(c=>c.status==='open').length} conversas abertas`} dir="up" icon="✉" bg="var(--yellowDim)" color="var(--yellow)" />
      </div>

      {/* Middle Row */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:16 }}>

        {/* Pipeline */}
        <div className="card" style={{ padding:16 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
            <div style={{ fontWeight:700, fontSize:13 }}>Pipeline</div>
            <button className="btn btn-ghost btn-sm" onClick={() => setPage('pipeline')}>Ver completo →</button>
          </div>
          {Object.entries(STAGES).slice(0, 5).map(([key, s]) => {
            const count = stageGroups[key] || 0;
            const total = leads.length || 1;
            return (
              <div key={key} style={{ marginBottom:10, cursor:'pointer' }} onClick={() => setPage('pipeline')}>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
                  <span style={{ fontSize:12, color:'var(--text2)' }}>{s.label}</span>
                  <span style={{ fontSize:11, color:'var(--muted)' }}>{count} leads</span>
                </div>
                <div className="progress">
                  <div className="progress-bar" style={{ width:`${(count/total)*100}%`, background:s.color }} />
                </div>
              </div>
            );
          })}
        </div>

        {/* Leads recentes */}
        <div className="card" style={{ padding:16 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
            <div style={{ fontWeight:700, fontSize:13 }}>Leads Recentes</div>
            <button className="btn btn-ghost btn-sm" onClick={() => setPage('leads')}>Ver todos →</button>
          </div>
          {leads.slice(0,5).map(lead => (
            <div key={lead.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'7px 0', borderBottom:'1px solid var(--border)' }}>
              <div style={{ width:30, height:30, borderRadius:'50%', background:'var(--accentBg)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:13, flexShrink:0 }}>
                <CanalIcon canal={lead.canal} />
              </div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:12.5, fontWeight:600, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{lead.nome}</div>
                <div style={{ fontSize:11, color:'var(--muted)' }}>{lead.contato}</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontSize:12, fontWeight:700, color:'var(--accent3)' }}>R$ {fmt(lead.valor)}</div>
                <Badge label={lead.status} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Row */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>

        {/* Inbox preview */}
        <div className="card" style={{ padding:16 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
            <div style={{ fontWeight:700, fontSize:13 }}>Inbox {unreadMsgs > 0 && <span style={{ background:'#ef4444', color:'#fff', borderRadius:10, padding:'1px 6px', fontSize:9.5, marginLeft:4 }}>{unreadMsgs}</span>}</div>
            <button className="btn btn-ghost btn-sm" onClick={() => setPage('inbox')}>Ver completo →</button>
          </div>
          {conversations.slice(0,4).map(cv => (
            <div key={cv.id}
              onClick={() => setPage('inbox')}
              style={{ display:'flex', gap:10, padding:'8px 0', borderBottom:'1px solid var(--border)', cursor:'pointer' }}
            >
              <span style={{ fontSize:16 }}><CanalIcon canal={cv.canal} /></span>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ display:'flex', justifyContent:'space-between' }}>
                  <span style={{ fontSize:12.5, fontWeight:600 }}>{cv.nome}</span>
                  <span style={{ fontSize:10.5, color:'var(--muted)' }}>{cv.tempo}</span>
                </div>
                <div style={{ fontSize:11.5, color:'var(--muted2)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{cv.ultima}</div>
              </div>
              {cv.unread > 0 && <span style={{ background:'#ef4444', color:'#fff', borderRadius:10, padding:'1px 6px', fontSize:9.5, height:'fit-content', marginTop:2 }}>{cv.unread}</span>}
            </div>
          ))}
        </div>

        {/* Agenda */}
        <div className="card" style={{ padding:16 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
            <div style={{ fontWeight:700, fontSize:13 }}>Agenda de Hoje</div>
            <button className="btn btn-ghost btn-sm" onClick={() => setPage('agenda')}>Ver →</button>
          </div>
          {agenda.filter(a => a.data === 'Hoje').map((ev, i) => (
            <div key={i} style={{ display:'flex', gap:10, padding:'8px 0', borderBottom:'1px solid var(--border)' }}>
              <div style={{ fontSize:11, color:'var(--accent3)', fontWeight:700, width:36, flexShrink:0 }}>{ev.hora}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:12.5, fontWeight:600 }}>{ev.titulo}</div>
                <div style={{ fontSize:11, color:'var(--muted)' }}>{ev.lead}</div>
              </div>
              <Badge label={ev.status} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
