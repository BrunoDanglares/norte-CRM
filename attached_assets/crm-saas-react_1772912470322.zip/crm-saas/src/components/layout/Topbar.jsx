import { useState } from 'react';
import { useStore } from '../../store/useStore';

const PAGE_TITLES = {
  dashboard:'Dashboard', leads:'Leads', pipeline:'Pipeline', contatos:'Contatos',
  inbox:'Inbox Omnichannel', campanhas:'Campanhas', automacoes:'Automações',
  ia:'Base de IA', agenda:'Agenda', financeiro:'Financeiro', relatorios:'Relatórios',
  conexoes:'Conexões', usuarios:'Usuários', integracoes:'Integrações',
  billing:'Billing & Planos', configuracoes:'Configurações', perfil:'Meu Perfil',
};

export default function Topbar() {
  const currentPage = useStore(s => s.currentPage);
  const theme = useStore(s => s.theme);
  const toggleTheme = useStore(s => s.toggleTheme);
  const setPage = useStore(s => s.setPage);
  const [showNotif, setShowNotif] = useState(false);
  const [showUser, setShowUser] = useState(false);

  return (
    <div style={{
      height:56, minHeight:56,
      background:'var(--sidebar)',
      borderBottom:'1px solid var(--border)',
      display:'flex', alignItems:'center',
      padding:'0 20px', gap:12,
      position:'relative', zIndex:10,
    }}>
      <div style={{ flex:1, fontSize:15, fontWeight:800, color:'var(--text)' }}>
        {PAGE_TITLES[currentPage] || currentPage}
      </div>

      {/* Search */}
      <div style={{
        display:'flex', alignItems:'center', gap:8,
        background:'var(--card2)', border:'1px solid var(--border)',
        borderRadius:10, padding:'6px 12px', width:200,
      }}>
        <span style={{ color:'var(--muted)', fontSize:12 }}>🔍</span>
        <input placeholder="Buscar..." style={{
          background:'none', border:'none', outline:'none',
          color:'var(--text)', fontSize:12, width:'100%',
        }} />
      </div>

      {/* Theme */}
      <button
        onClick={toggleTheme}
        title={theme === 'dark' ? 'Modo claro' : 'Modo escuro'}
        style={{
          width:34, height:34, borderRadius:9,
          background:'var(--card2)', border:'1px solid var(--border)',
          cursor:'pointer', fontSize:15, display:'flex',
          alignItems:'center', justifyContent:'center',
        }}
      >
        {theme === 'dark' ? '☀️' : '🌙'}
      </button>

      {/* Notifications */}
      <div style={{ position:'relative' }}>
        <button
          onClick={() => { setShowNotif(!showNotif); setShowUser(false); }}
          style={{
            width:34, height:34, borderRadius:9,
            background:'var(--card2)', border:'1px solid var(--border)',
            cursor:'pointer', fontSize:15, display:'flex',
            alignItems:'center', justifyContent:'center', position:'relative',
          }}
        >
          🔔
          <span style={{
            position:'absolute', top:4, right:4,
            width:8, height:8, borderRadius:'50%',
            background:'#ef4444',
          }} />
        </button>
        {showNotif && (
          <div style={{
            position:'absolute', top:40, right:0,
            width:320, background:'var(--card)',
            border:'1.5px solid var(--border2)', borderRadius:14,
            boxShadow:'0 8px 28px rgba(0,0,0,.25)', zIndex:100,
            overflow:'hidden',
          }}>
            <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', fontWeight:700, fontSize:13 }}>
              Notificações
            </div>
            {[
              { ico:'💚', txt:'Carlos Silva respondeu no WhatsApp', time:'2min' },
              { ico:'📅', txt:'Reunião com Tech Start em 30min',   time:'30min' },
              { ico:'🔔', txt:'Campanha Promo Março concluída',     time:'1h' },
            ].map((n,i) => (
              <div key={i} style={{ padding:'10px 16px', borderBottom:'1px solid var(--border)', display:'flex', gap:10, cursor:'pointer' }}
                onMouseEnter={e => e.currentTarget.style.background='var(--card2)'}
                onMouseLeave={e => e.currentTarget.style.background='transparent'}
              >
                <span style={{ fontSize:16 }}>{n.ico}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:12, color:'var(--text)' }}>{n.txt}</div>
                  <div style={{ fontSize:10.5, color:'var(--muted)', marginTop:2 }}>{n.time} atrás</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* User */}
      <div style={{ position:'relative' }}>
        <div
          onClick={() => { setShowUser(!showUser); setShowNotif(false); }}
          style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer', padding:'4px 8px', borderRadius:9 }}
        >
          <div style={{
            width:30, height:30, borderRadius:'50%',
            background:'linear-gradient(135deg,#7c5cbf,#9b7ee0)',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:12, fontWeight:700, color:'#fff',
          }}>JD</div>
          <div>
            <div style={{ fontSize:12, fontWeight:700, lineHeight:1.2 }}>João Dono</div>
            <div style={{ fontSize:10, color:'var(--muted)' }}>Super Admin</div>
          </div>
          <span style={{ color:'var(--muted)', fontSize:10 }}>▼</span>
        </div>

        {showUser && (
          <div style={{
            position:'absolute', top:44, right:0,
            width:200, background:'var(--card)',
            border:'1.5px solid var(--border2)', borderRadius:12,
            boxShadow:'0 8px 28px rgba(0,0,0,.25)', zIndex:100,
            overflow:'hidden',
          }}>
            {[
              { icon:'⚙️', label:'Configurações', page:'configuracoes' },
              { icon:'👤', label:'Meu Perfil',     page:'perfil' },
              { icon:'👥', label:'Usuários',        page:'usuarios' },
              { icon:'💳', label:'Billing & Planos',page:'billing' },
            ].map((item,i) => (
              <div key={i}
                onClick={() => { setPage(item.page); setShowUser(false); }}
                style={{ padding:'9px 16px', fontSize:'12.5px', cursor:'pointer', display:'flex', alignItems:'center', gap:9 }}
                onMouseEnter={e => e.currentTarget.style.background='var(--card2)'}
                onMouseLeave={e => e.currentTarget.style.background='transparent'}
              >
                {item.icon} {item.label}
              </div>
            ))}
            <div style={{ borderTop:'1px solid var(--border)', padding:'9px 16px', fontSize:'12.5px', cursor:'pointer', color:'var(--red)', display:'flex', alignItems:'center', gap:9 }}
              onMouseEnter={e => e.currentTarget.style.background='var(--redDim)'}
              onMouseLeave={e => e.currentTarget.style.background='transparent'}
            >
              🚪 Sair
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
