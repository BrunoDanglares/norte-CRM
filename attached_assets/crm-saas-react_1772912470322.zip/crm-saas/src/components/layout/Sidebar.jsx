import { useStore } from '../../store/useStore';

const NAV_ITEMS = [
  { page:'dashboard',     icon:'⊞',  label:'Dashboard' },
  { page:'leads',         icon:'◎',  label:'Leads',         badge:24 },
  { page:'pipeline',      icon:'⋮⋮', label:'Pipeline' },
  { page:'contatos',      icon:'◉',  label:'Contatos' },
  { divider: true, label: 'COMUNICAÇÃO' },
  { page:'inbox',         icon:'✉',  label:'Inbox',         badge:7 },
  { page:'campanhas',     icon:'▷',  label:'Campanhas' },
  { divider: true, label: 'AUTOMAÇÃO' },
  { page:'automacoes',    icon:'⟳',  label:'Automações' },
  { page:'ia',            icon:'◈',  label:'Base de IA' },
  { divider: true, label: 'GESTÃO' },
  { page:'agenda',        icon:'▣',  label:'Agenda' },
  { page:'financeiro',    icon:'◇',  label:'Financeiro' },
  { page:'relatorios',    icon:'↗',  label:'Relatórios' },
  { divider: true, label: 'CONFIGURAÇÕES' },
  { page:'conexoes',      icon:'🔗', label:'Conexões' },
  { page:'usuarios',      icon:'○',  label:'Usuários' },
  { page:'integracoes',   icon:'⬡',  label:'Integrações' },
  { page:'billing',       icon:'◻',  label:'Billing' },
  { page:'configuracoes', icon:'⚙',  label:'Configurações' },
];

export default function Sidebar() {
  const currentPage = useStore(s => s.currentPage);
  const setPage = useStore(s => s.setPage);

  return (
    <div style={{
      width:216, minWidth:216,
      background:'var(--sidebar)',
      borderRight:'1px solid var(--border)',
      display:'flex', flexDirection:'column',
      overflow:'hidden', height:'100vh',
    }}>
      {/* Logo */}
      <div style={{ padding:'22px 18px 18px', display:'flex', alignItems:'center', gap:10, borderBottom:'1px solid var(--border)' }}>
        <div style={{
          width:32, height:32, borderRadius:9,
          background:'linear-gradient(135deg,#7c5cbf,#9b7ee0)',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:16, fontWeight:900, color:'#fff',
        }}>C</div>
        <div>
          <div style={{ fontSize:13.5, fontWeight:800, color:'var(--text)' }}>CRM SaaS Pro</div>
          <div style={{ fontSize:10, color:'var(--muted)', fontWeight:500 }}>v2.0</div>
        </div>
      </div>

      {/* Nav */}
      <div style={{ flex:1, overflowY:'auto', padding:'8px 0' }}>
        {NAV_ITEMS.map((item, i) => {
          if (item.divider) {
            return (
              <div key={i} style={{
                padding:'12px 20px 4px',
                fontSize:'9.5px', fontWeight:700,
                color:'var(--muted)', letterSpacing:'0.08em',
                textTransform:'uppercase',
              }}>
                {item.label}
              </div>
            );
          }

          const isActive = currentPage === item.page;
          return (
            <div
              key={item.page}
              onClick={() => setPage(item.page)}
              style={{
                display:'flex', alignItems:'center', gap:9,
                padding:'7px 14px', margin:'1px 6px',
                borderRadius:8, cursor:'pointer',
                color: isActive ? 'var(--accent3)' : 'var(--muted2)',
                background: isActive ? 'rgba(124,92,191,.18)' : 'transparent',
                fontWeight: isActive ? 600 : 500,
                fontSize:'12.5px',
                transition:'all .15s',
                position:'relative',
              }}
              onMouseEnter={e => !isActive && (e.currentTarget.style.background = 'rgba(124,92,191,.08)')}
              onMouseLeave={e => !isActive && (e.currentTarget.style.background = 'transparent')}
            >
              {isActive && (
                <div style={{
                  position:'absolute', left:0, top:'20%', bottom:'20%',
                  width:3, background:'linear-gradient(to bottom,var(--accent),var(--accent3))',
                  borderRadius:'0 3px 3px 0',
                }} />
              )}
              <span style={{ fontSize:14, lineHeight:1 }}>{item.icon}</span>
              <span style={{ flex:1 }}>{item.label}</span>
              {item.badge && (
                <span style={{
                  background: isActive ? 'var(--accent2)' : 'var(--card3)',
                  color: isActive ? '#fff' : 'var(--muted2)',
                  fontSize:9.5, fontWeight:700,
                  padding:'1px 6px', borderRadius:20,
                }}>
                  {item.badge}
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* User */}
      <div style={{ padding:'12px 16px', borderTop:'1px solid var(--border)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:9 }}>
          <div style={{
            width:30, height:30, borderRadius:'50%',
            background:'linear-gradient(135deg,#7c5cbf,#9b7ee0)',
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:12, fontWeight:700, color:'#fff', flexShrink:0,
          }}>JD</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:12, fontWeight:700, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>João Dono</div>
            <div style={{ fontSize:10, color:'var(--muted)' }}>Super Admin</div>
          </div>
        </div>
      </div>
    </div>
  );
}
