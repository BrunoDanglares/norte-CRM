import { useStore } from '../store/useStore';

// ── Badge ─────────────────────────────────────────────────
const COLOR_MAP = {
  novo:'b-blue', contatado:'b-purple', qualificado:'b-teal',
  proposta:'b-yellow', negociacao:'b-purple', ganho:'b-green', perdido:'b-red',
  ativo:'b-green', inativo:'b-red', pendente:'b-yellow', pago:'b-green',
  open:'b-green', resolved:'b-muted', pending:'b-yellow',
  active:'b-green', paused:'b-yellow', draft:'b-muted',
  running:'b-blue', completed:'b-green', scheduled:'b-purple',
  convidado:'b-yellow', admin:'b-purple', super_admin:'b-blue', user:'b-muted',
};

export function Badge({ label, color }) {
  const cls = color || COLOR_MAP[label?.toLowerCase()] || 'b-muted';
  return <span className={`badge ${cls}`}>{label}</span>;
}

// ── Canal Icon ────────────────────────────────────────────
export function CanalIcon({ canal }) {
  const map = { whatsapp:'💚', WhatsApp:'💚', instagram:'📸', Instagram:'📸', chat:'💬', Chat:'💬', email:'📧', Email:'📧' };
  return <span>{map[canal] || '💬'}</span>;
}

// ── Avatar ────────────────────────────────────────────────
export function Avatar({ nome, size = 32 }) {
  const initials = (nome || '?').split(' ').slice(0,2).map(w => w[0]).join('').toUpperCase();
  const colors = ['#7c5cbf','#9b7ee0','#6d28d9','#4f46e5','#0891b2','#059669'];
  const color = colors[(nome?.charCodeAt(0) || 0) % colors.length];
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', background: color,
      display:'flex', alignItems:'center', justifyContent:'center',
      fontSize: size * 0.35, fontWeight:700, color:'#fff', flexShrink:0,
    }}>
      {initials}
    </div>
  );
}

// ── Modal ─────────────────────────────────────────────────
export function Modal({ title, onClose, onSave, children, saveLabel = 'Salvar' }) {
  return (
    <div className="overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
          <h3 style={{ fontSize:15, fontWeight:700 }}>{title}</h3>
          <button className="btn btn-ghost btn-sm" onClick={onClose} style={{ padding:'4px 8px', fontSize:16 }}>✕</button>
        </div>
        {children}
        {onSave && (
          <div style={{ display:'flex', gap:8, justifyContent:'flex-end', marginTop:20 }}>
            <button className="btn btn-ghost" onClick={onClose}>Cancelar</button>
            <button className="btn-primary" onClick={onSave}>{saveLabel}</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Stat Card ─────────────────────────────────────────────
export function StatCard({ title, value, sub, dir = 'up', icon, bg, color }) {
  return (
    <div className="card" style={{ padding:16 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:10 }}>
        <div style={{ fontSize:'10.5px', fontWeight:700, color:'var(--muted)', textTransform:'uppercase' }}>{title}</div>
        <div style={{ width:32, height:32, borderRadius:9, background:bg, display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, color }}>
          {icon}
        </div>
      </div>
      <div style={{ fontSize:22, fontWeight:900, marginBottom:4 }}>{value}</div>
      <div style={{ fontSize:11, color: dir === 'up' ? 'var(--green)' : 'var(--red)' }}>{sub}</div>
    </div>
  );
}

// ── Progress Bar ──────────────────────────────────────────
export function ProgressBar({ value, max, color }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className="progress">
      <div className="progress-bar" style={{ width:`${pct}%`, background: color || undefined }} />
    </div>
  );
}

// ── Toggle ────────────────────────────────────────────────
export function Toggle({ on, onChange }) {
  return (
    <div className={`toggle ${on ? 'on' : ''}`} onClick={() => onChange(!on)} />
  );
}

// ── Notifications ─────────────────────────────────────────
export function Notifications() {
  const notifications = useStore(s => s.notifications);
  return (
    <>
      {notifications.map(n => (
        <div key={n.id} className="notif">
          <span style={{ color:'var(--green)' }}>✓</span> {n.msg}
        </div>
      ))}
    </>
  );
}

// ── Empty State ───────────────────────────────────────────
export function Empty({ icon = '📭', text = 'Nenhum item encontrado' }) {
  return (
    <div style={{ textAlign:'center', padding:'40px 20px', color:'var(--muted)' }}>
      <div style={{ fontSize:32, marginBottom:10 }}>{icon}</div>
      <div style={{ fontSize:13 }}>{text}</div>
    </div>
  );
}

// ── Search Box ────────────────────────────────────────────
export function SearchBox({ value, onChange, placeholder = 'Buscar...' }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:8,
      background:'var(--card2)', border:'1px solid var(--border2)',
      borderRadius:10, padding:'7px 12px',
    }}>
      <span style={{ color:'var(--muted)' }}>🔍</span>
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        style={{ background:'none', border:'none', outline:'none', color:'var(--text)', fontSize:13, width:'100%' }}
      />
    </div>
  );
}

// ── Page Header ───────────────────────────────────────────
export function PageHeader({ title, subtitle, action }) {
  return (
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
      <div>
        <h2 style={{ fontSize:17, fontWeight:800, marginBottom:2 }}>{title}</h2>
        {subtitle && <div style={{ fontSize:12, color:'var(--muted)' }}>{subtitle}</div>}
      </div>
      {action}
    </div>
  );
}
