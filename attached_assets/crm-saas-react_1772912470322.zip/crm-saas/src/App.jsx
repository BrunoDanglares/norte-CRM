import './index.css';
import { useStore } from './store/useStore';
import Sidebar from './components/layout/Sidebar';
import Topbar from './components/layout/Topbar';
import { Notifications } from './components/ui';
import Dashboard from './components/pages/Dashboard';
import Leads from './components/pages/Leads';
import Pipeline from './components/pages/Pipeline';
import Inbox from './components/pages/Inbox';
import {
  Contatos, Agenda, Financeiro, Campanhas, Automacoes,
  IA, Conexoes, Usuarios, Integracoes, Billing,
  Relatorios, Configuracoes, Perfil
} from './components/pages/OtherPages';

const PAGES = {
  dashboard:    <Dashboard />,
  leads:        <Leads />,
  pipeline:     <Pipeline />,
  contatos:     <Contatos />,
  inbox:        <Inbox />,
  campanhas:    <Campanhas />,
  automacoes:   <Automacoes />,
  ia:           <IA />,
  agenda:       <Agenda />,
  financeiro:   <Financeiro />,
  relatorios:   <Relatorios />,
  conexoes:     <Conexoes />,
  usuarios:     <Usuarios />,
  integracoes:  <Integracoes />,
  billing:      <Billing />,
  configuracoes:<Configuracoes />,
  perfil:       <Perfil />,
};

export default function App() {
  const currentPage = useStore(s => s.currentPage);

  return (
    <div style={{ display:'flex', height:'100vh', overflow:'hidden' }}>
      <Sidebar />
      <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
        <Topbar />
        <div style={{ flex:1, overflow:'hidden', background:'var(--bg)' }}>
          {PAGES[currentPage] || <Dashboard />}
        </div>
      </div>
      <Notifications />
    </div>
  );
}
