import { create } from 'zustand';
import { mockData } from '../data/mockData';

export const useStore = create((set, get) => ({
  // ── State ──────────────────────────────────────────────
  currentPage: 'dashboard',
  theme: 'dark',
  data: JSON.parse(JSON.stringify(mockData)), // deep clone
  notifications: [],

  // ── Navigation ────────────────────────────────────────
  setPage: (page) => set({ currentPage: page }),

  // ── Theme ─────────────────────────────────────────────
  toggleTheme: () => set((s) => {
    const next = s.theme === 'dark' ? 'light' : 'dark';
    document.body.classList.toggle('light', next === 'light');
    return { theme: next };
  }),

  // ── Notifications ─────────────────────────────────────
  notify: (msg) => {
    const id = Date.now();
    set((s) => ({ notifications: [...s.notifications, { id, msg }] }));
    setTimeout(() => {
      set((s) => ({ notifications: s.notifications.filter(n => n.id !== id) }));
    }, 3000);
  },

  // ── Leads ─────────────────────────────────────────────
  addLead: (lead) => set((s) => ({
    data: { ...s.data, leads: [...s.data.leads, { ...lead, id: Date.now() }] }
  })),
  updateLead: (id, updates) => set((s) => ({
    data: { ...s.data, leads: s.data.leads.map(l => l.id === id ? { ...l, ...updates } : l) }
  })),
  deleteLead: (id) => set((s) => ({
    data: { ...s.data, leads: s.data.leads.filter(l => l.id !== id) }
  })),

  // ── Contatos ──────────────────────────────────────────
  addContato: (contato) => set((s) => ({
    data: { ...s.data, contatos: [...s.data.contatos, { ...contato, id: Date.now() }] }
  })),

  // ── Agenda ────────────────────────────────────────────
  addAgendaItem: (item) => set((s) => ({
    data: { ...s.data, agenda: [...s.data.agenda, item] }
  })),

  // ── Financeiro ────────────────────────────────────────
  addFinanceiro: (item) => set((s) => ({
    data: { ...s.data, financeiro: [...s.data.financeiro, { ...item, id: Date.now() }] }
  })),

  // ── Inbox ─────────────────────────────────────────────
  sendMessage: (convId, txt) => set((s) => {
    const convs = s.data.conversations.map(c => {
      if (c.id !== convId) return c;
      return {
        ...c,
        ultima: txt,
        tempo: 'agora',
        unread: 0,
        msgs: [...c.msgs, { dir:'out', txt, hora: new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}), status:'sent', agente:'Você' }]
      };
    });
    return { data: { ...s.data, conversations: convs } };
  }),

  resolveConv: (convId) => set((s) => ({
    data: {
      ...s.data,
      conversations: s.data.conversations.map(c =>
        c.id === convId ? { ...c, status: 'resolved', unread: 0 } : c
      )
    }
  })),

  // ── Billing ───────────────────────────────────────────
  upgradePlan: (planId) => set((s) => ({
    data: {
      ...s.data,
      billing: {
        ...s.data.billing,
        plan: planId === 'pro' ? 'Pro' : 'Starter',
        status: 'Ativo',
        trialDays: 14,
        mrr: planId === 'pro' ? 497 : 197,
      }
    }
  })),

  // ── Conexoes ──────────────────────────────────────────
  addConexao: (conn) => set((s) => ({
    data: { ...s.data, conexoes: [...s.data.conexoes, { ...conn, id: Date.now() }] }
  })),
  removeConexao: (id) => set((s) => ({
    data: { ...s.data, conexoes: s.data.conexoes.filter(c => c.id !== id) }
  })),
}));
