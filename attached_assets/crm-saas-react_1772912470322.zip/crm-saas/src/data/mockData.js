export const STAGES = {
  novo:       { label: 'Novo',       color: '#60a5fa' },
  contatado:  { label: 'Contatado',  color: '#818cf8' },
  qualificado:{ label: 'Qualificado',color: '#a78bfa' },
  proposta:   { label: 'Proposta',   color: '#c084fc' },
  negociacao: { label: 'Negociação', color: '#e879f9' },
  ganho:      { label: 'Ganho',      color: '#34d399' },
  perdido:    { label: 'Perdido',    color: '#f87171' },
};

export const mockData = {
  leads: [
    { id:1, nome:'Imobiliária São Paulo', contato:'Carlos Silva',  valor:15000, status:'proposta',   canal:'WhatsApp',  owner:'Ana Costa',   data:'05/03' },
    { id:2, nome:'Clínica Bem Estar',     contato:'Dra. Paula',    valor:8500,  status:'qualificado', canal:'Instagram', owner:'Bruno Lima',  data:'04/03' },
    { id:3, nome:'Escritório JK Adv',     contato:'Dr. Marcos',    valor:4200,  status:'contatado',  canal:'WhatsApp',  owner:'Ana Costa',   data:'03/03' },
    { id:4, nome:'Academia FitLife',      contato:'Pedro Alves',   valor:3800,  status:'novo',       canal:'Chat',      owner:'Carlos',      data:'02/03' },
    { id:5, nome:'Restaurante Bella',     contato:'Marina Rocha',  valor:6200,  status:'negociacao', canal:'WhatsApp',  owner:'Bruno Lima',  data:'01/03' },
    { id:6, nome:'Tech Startup Alpha',    contato:'Lucas Dev',     valor:22000, status:'ganho',      canal:'Email',     owner:'Ana Costa',   data:'28/02' },
    { id:7, nome:'Construtora Norte',     contato:'Roberto Paz',   valor:45000, status:'perdido',    canal:'WhatsApp',  owner:'Carlos',      data:'27/02' },
  ],

  contatos: [
    { id:1, nome:'Carlos Silva',    empresa:'Imobiliária SP',    phone:'(11) 98765-4321', email:'carlos@imob.com',    canal:'WhatsApp',  tags:['vip','imobiliária'] },
    { id:2, nome:'Dra. Paula',      empresa:'Clínica Bem Estar', phone:'(11) 91234-5678', email:'paula@clinica.com',  canal:'Instagram', tags:['saúde'] },
    { id:3, nome:'Dr. Marcos',      empresa:'JK Advocacia',      phone:'(11) 93344-5566', email:'marcos@jk.adv.br',   canal:'WhatsApp',  tags:['jurídico'] },
    { id:4, nome:'Pedro Alves',     empresa:'Academia FitLife',  phone:'(11) 97788-9900', email:'pedro@fitlife.com',  canal:'Chat',      tags:['fitness'] },
    { id:5, nome:'Marina Rocha',    empresa:'Bella Restaurante', phone:'(11) 95566-7788', email:'marina@bella.com',   canal:'WhatsApp',  tags:['food','vip'] },
  ],

  conversations: [
    {
      id:0, nome:'Carlos Silva', phone:'+55 11 99823-4401', canal:'whatsapp', status:'open',
      agente:'Ana Costa', tags:['lead-quente','proposta'], ultima:'Preciso de uma proposta atualizada',
      tempo:'2m', unread:2, empresa:'Imobiliária SP', email:'carlos@imobsp.com',
      origem:'WhatsApp Business', prioridade:'alta', scheduledMsgs:[], notas:'Cliente VIP',
      msgs:[
        { dir:'in',  txt:'Olá! Gostaria de mais detalhes sobre o plano Pro',                                hora:'09:12', status:'read' },
        { dir:'out', txt:'Claro, Carlos! Posso enviar a proposta agora?',                                   hora:'09:15', status:'read',      agente:'Ana Costa' },
        { dir:'in',  txt:'Sim, por favor. Precisamos de algo para até 10 usuários',                         hora:'09:18', status:'read' },
        { dir:'out', txt:'Perfeito! Nosso plano Pro suporta até 10 usuários por R$ 497/mês.',               hora:'09:20', status:'delivered', agente:'Ana Costa' },
        { dir:'in',  txt:'Preciso de uma proposta atualizada',                                              hora:'14:31', status:'read' },
      ]
    },
    {
      id:1, nome:'Dra. Paula Mendes', phone:'+55 21 98741-3320', canal:'instagram', status:'open',
      agente:null, tags:['novo','clinica'], ultima:'Quando podemos agendar uma demo?',
      tempo:'18m', unread:1, empresa:'Clínica Bem Estar', email:'paula@clinicabem.com.br',
      origem:'Instagram DM', prioridade:'media',
      scheduledMsgs:[{ txt:'Olá Dra. Paula! Passando para confirmar nossa demo de amanhã às 14h 😊', data:'Amanhã', hora:'09:00', status:'agendada' }],
      notas:'Interagiu com post sobre atendimento médico',
      msgs:[
        { dir:'in',  txt:'Vi vocês no Instagram! Tenho uma clínica e quero melhorar o atendimento', hora:'10:00', status:'read' },
        { dir:'out', txt:'Oi Dra. Paula! Que ótimo! Nossa solução é perfeita para clínicas 🏥',     hora:'10:05', status:'read', agente:'Bruno Lima' },
        { dir:'in',  txt:'Que funcionalidades vocês têm para agendamento?',                         hora:'10:22', status:'read' },
        { dir:'in',  txt:'Quando podemos agendar uma demo?',                                        hora:'13:52', status:'read' },
      ]
    },
    {
      id:2, nome:'Pedro Alves', phone:'+55 31 97652-8811', canal:'chat', status:'pending',
      agente:'Bruno Lima', tags:['suporte','preço'], ultima:'Qual o preço do plano Starter?',
      tempo:'1h', unread:0, empresa:'StartupXYZ', email:'pedro@startupxyz.io',
      origem:'Chat no site', prioridade:'baixa', scheduledMsgs:[], notas:'',
      msgs:[
        { dir:'in',  txt:'Qual o preço do plano Starter?',                          hora:'12:00', status:'read' },
        { dir:'out', txt:'O Starter custa R$ 197/mês com WhatsApp incluso!',        hora:'12:02', status:'read', agente:'Bruno Lima' },
        { dir:'in',  txt:'Tem trial grátis?',                                       hora:'12:05', status:'read' },
        { dir:'out', txt:'Sim! 14 dias grátis sem precisar de cartão de crédito 🎉', hora:'12:07', status:'read', agente:'Bruno Lima' },
      ]
    },
    {
      id:3, nome:'Fernanda Rocha', phone:'+55 11 94321-7700', canal:'whatsapp', status:'resolved',
      agente:'Carlos Vendas', tags:['fechado','enterprise'], ultima:'Perfeito! Vamos assinar o Enterprise',
      tempo:'3h', unread:0, empresa:'Tech Alpha LTDA', email:'fernanda@techalpha.com',
      origem:'WhatsApp Business', prioridade:'alta', scheduledMsgs:[], notas:'Fechou Enterprise — 50 usuários',
      msgs:[
        { dir:'out', txt:'Fernanda, preparei a proposta Enterprise personalizada para vocês!', hora:'08:30', status:'read', agente:'Carlos Vendas' },
        { dir:'in',  txt:'Recebi! Vou revisar com o jurídico',                                hora:'09:15', status:'read' },
        { dir:'in',  txt:'Aprovado! Como procedemos para assinar?',                           hora:'11:00', status:'read' },
        { dir:'out', txt:'Ótimo! Vou te enviar o link do contrato agora mesmo!',              hora:'11:05', status:'read', agente:'Carlos Vendas' },
        { dir:'in',  txt:'Perfeito! Vamos assinar o Enterprise',                              hora:'11:30', status:'read' },
      ]
    },
    {
      id:4, nome:'Marcos Teixeira', phone:'+55 85 99312-5543', canal:'whatsapp', status:'open',
      agente:null, tags:['novo'], ultima:'Oi, vi no Google, quero saber mais',
      tempo:'5m', unread:3, empresa:'', email:'', origem:'WhatsApp Business', prioridade:'media',
      scheduledMsgs:[], notas:'',
      msgs:[
        { dir:'in', txt:'Oi, vi no Google, quero saber mais',   hora:'14:55', status:'read' },
        { dir:'in', txt:'Vocês atendem empresas pequenas?',      hora:'14:56', status:'read' },
        { dir:'in', txt:'Alguém pode me responder?',             hora:'14:58', status:'read' },
      ]
    },
  ],

  agenda: [
    { titulo:'Call com Carlos Silva',     tipo:'ligacao',  hora:'09:00', data:'Hoje',   status:'agendado', lead:'Imobiliária SP' },
    { titulo:'Demo Clínica Bem Estar',    tipo:'reuniao',  hora:'11:00', data:'Hoje',   status:'agendado', lead:'Clínica Bem Estar' },
    { titulo:'Follow-up Escritório JK',   tipo:'followup', hora:'14:00', data:'Hoje',   status:'feito',    lead:'Escritório JK Adv' },
    { titulo:'Proposta Academia FitLife', tipo:'tarefa',   hora:'16:00', data:'Amanhã', status:'agendado', lead:'Academia FitLife' },
    { titulo:'Reunião interna comercial', tipo:'reuniao',  hora:'08:30', data:'Amanhã', status:'agendado', lead:'—' },
  ],

  financeiro: [
    { desc:'Assinatura Tech Alpha',      tipo:'entrada', valor:22000, status:'pago',     data:'01/03', cat:'Vendas' },
    { desc:'Plano Pro — Imobiliária SP', tipo:'entrada', valor:497,   status:'pendente', data:'05/03', cat:'Assinatura' },
    { desc:'Servidor AWS',               tipo:'saida',   valor:380,   status:'pago',     data:'01/03', cat:'Infra' },
    { desc:'Marketing Digital',          tipo:'saida',   valor:1200,  status:'pago',     data:'28/02', cat:'Marketing' },
    { desc:'Comissão vendedor',          tipo:'saida',   valor:800,   status:'pendente', data:'10/03', cat:'RH' },
    { desc:'Plano Starter — Academia',   tipo:'entrada', valor:197,   status:'pago',     data:'02/03', cat:'Assinatura' },
  ],

  campanhas: [
    { nome:'Black Friday 2024',     status:'completed', channel:'whatsapp', segmento:'Clientes Ativos',   total:1820, sent:1820, delivered:1711, read:706, replies:82, data:'Nov/24' },
    { nome:'Promo Janeiro',         status:'completed', channel:'whatsapp', segmento:'Leads Quentes',     total:342,  sent:342,  delivered:324,  read:134, replies:18, data:'Jan/25' },
    { nome:'Follow-up Proposta',    status:'running',   channel:'whatsapp', segmento:'Pipeline Proposta', total:94,   sent:67,   delivered:63,   read:28,  replies:9,  data:'Mar/25' },
    { nome:'Reengajamento 30d',     status:'draft',     channel:'whatsapp', segmento:'Sem resposta 7d',   total:289,  sent:0,    delivered:0,    read:0,   replies:0,  data:'Mar/25' },
    { nome:'Campanha Instagram',    status:'scheduled', channel:'instagram',segmento:'Leads Quentes',     total:342,  sent:0,    delivered:0,    read:0,   replies:0,  data:'Amanhã' },
  ],

  usuarios: [
    { nome:'João Dono',        email:'joao@empresa.com',   role:'super_admin', status:'ativo',     cargo:'CEO / Fundador',    lastAccess:'Agora' },
    { nome:'Ana Costa',        email:'ana@empresa.com',    role:'admin',       status:'ativo',     cargo:'Gerente de Vendas', lastAccess:'5min' },
    { nome:'Bruno Lima',       email:'bruno@empresa.com',  role:'user',        status:'ativo',     cargo:'SDR',               lastAccess:'1h' },
    { nome:'Carlos Vendas',    email:'carlos@empresa.com', role:'user',        status:'ativo',     cargo:'Closer',            lastAccess:'Ontem' },
    { nome:'invite@exemplo.com', email:'invite@exemplo.com', role:'user',      status:'convidado', cargo:'',                  lastAccess:'Nunca' },
  ],

  automacoes: [
    {
      nome:'Boas-vindas WhatsApp', trigger:'💬 Nova mensagem recebida', status:'active', execucoes:234, passos:4,
      nodes:[
        { id:'n1', type:'trigger',      label:'Nova conversa WA', config:{ triggerType:'conversation_opened', channel:'whatsapp' }, x:120, y:40,  next:['n2'] },
        { id:'n2', type:'delay',        label:'Aguardar 5s',      config:{ value:5, unit:'seconds' },                               x:120, y:160, next:['n3'] },
        { id:'n3', type:'send_message', label:'Boas-vindas',      config:{ content:'Olá! 👋 Seja bem-vindo(a)! Como posso te ajudar?' }, x:120, y:280, next:['n4'] },
        { id:'n4', type:'assign_agent', label:'Atribuir agente',  config:{ strategy:'round_robin' },                                x:120, y:400, next:['n5'] },
        { id:'n5', type:'end',          label:'Fim',              config:{},                                                        x:120, y:520, next:[] },
      ]
    },
    {
      nome:'Follow-up 24h sem resposta', trigger:'⏰ Sem resposta por X horas', status:'active', execucoes:89, passos:5,
      nodes:[
        { id:'n1', type:'trigger',      label:'Sem resposta 24h', config:{ triggerType:'no_reply_timeout' }, x:120, y:40,  next:['n2'] },
        { id:'n2', type:'condition',    label:'Horário comercial?',config:{ field:'businessHour', operator:'eq', value:true }, x:120, y:180, nextTrue:'n3', nextFalse:'n4' },
        { id:'n3', type:'send_message', label:'Follow-up',        config:{ content:'Oi, {{nome}}! Vi que nossa conversa ficou pendente.' }, x:20,  y:340, next:['n5'] },
        { id:'n4', type:'delay',        label:'Aguardar 8h',      config:{ value:8, unit:'hours' },          x:230, y:340, next:['n3'] },
        { id:'n5', type:'tag_lead',     label:'Tag: follow-up',   config:{ tags:['follow-up-24h'], action:'add' }, x:120, y:480, next:['n6'] },
        { id:'n6', type:'end',          label:'Fim',              config:{},                                 x:120, y:590, next:[] },
      ]
    },
  ],

  kb: [
    { titulo:'Preços e Planos 2025',       cat:'Vendas',    palavras:420, updated:'hoje',  status:'indexed', tipo:'product' },
    { titulo:'FAQ — Integração WhatsApp',  cat:'Suporte',   palavras:280, updated:'ontem', status:'indexed', tipo:'faq' },
    { titulo:'Onboarding de Clientes',     cat:'Processos', palavras:650, updated:'3d',    status:'indexed', tipo:'text' },
    { titulo:'Objeções mais comuns',       cat:'Vendas',    palavras:310, updated:'1sem',  status:'indexed', tipo:'text' },
    { titulo:'Política de Cancelamento',   cat:'Jurídico',  palavras:180, updated:'2sem',  status:'indexed', tipo:'text' },
  ],

  billing: {
    plan:'Pro', status:'Trial ativo', trialDays:11,
    nextBilling:'01/04/2025', mrr:497,
    seatsUsed:3, seatsLimit:10,
    contactsUsed:847, contactsLimit:-1,
    msgsSent:4230, msgsLimit:30000,
    invoices:[
      { period:'Mar/2025', plan:'Pro',     amount:'497,00', paid:false },
      { period:'Fev/2025', plan:'Pro',     amount:'497,00', paid:true },
      { period:'Jan/2025', plan:'Starter', amount:'197,00', paid:true },
    ],
  },

  conexoes: [
    { id:1, nome:'WhatsApp Comercial', tipo:'whatsapp', status:'connected', numero:'+55 11 99999-0001', instance:'wa_comercial', msgs:1240 },
    { id:2, nome:'WhatsApp Suporte',   tipo:'whatsapp', status:'connected', numero:'+55 11 99999-0002', instance:'wa_suporte',   msgs:430  },
    { id:3, nome:'Instagram DMs',      tipo:'instagram',status:'connected', numero:'@minhaempresa',     instance:'ig_main',      msgs:210  },
    { id:4, nome:'Chat no Site',       tipo:'chat',     status:'connected', numero:'widget_v2',         instance:'chat_site',    msgs:89   },
  ],

  integracoes: [
    { nome:'WhatsApp Business API', cat:'Mensagens',  status:'ativo',      icon:'💚', desc:'Envio e recebimento via Evolution API' },
    { nome:'Instagram DM',          cat:'Mensagens',  status:'ativo',      icon:'📸', desc:'Mensagens diretas do Instagram' },
    { nome:'OpenAI / GPT-4o',       cat:'IA',         status:'ativo',      icon:'🤖', desc:'Respostas automáticas com IA' },
    { nome:'Stripe',                cat:'Pagamentos', status:'configurar', icon:'💳', desc:'Cobrança e assinaturas recorrentes' },
    { nome:'Google Calendar',       cat:'Agenda',     status:'ativo',      icon:'📅', desc:'Sincronização de eventos' },
    { nome:'RD Station',            cat:'Marketing',  status:'inativo',    icon:'📊', desc:'Sincronização de leads e funil' },
    { nome:'HubSpot',               cat:'CRM',        status:'configurar', icon:'🔶', desc:'Sincronizar contatos e negócios' },
    { nome:'Zapier',                cat:'Automação',  status:'inativo',    icon:'⚡', desc:'Conecte com 5000+ apps' },
  ],
};
