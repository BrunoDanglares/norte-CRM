# CRM SaaS Pro — React

Projeto CRM completo convertido de HTML para React com estado global, roteamento e todos os módulos originais.

## Stack

- **React 18** + Vite
- **Zustand** — estado global (dados, navegação, tema)
- **CSS Variables** — tema claro/escuro idêntico ao original

## Módulos Incluídos

| Página | Descrição |
|--------|-----------|
| Dashboard | Visão geral com KPIs, pipeline resumido, inbox e agenda |
| Leads | Tabela completa com filtros, busca e CRUD |
| Pipeline | Kanban drag & drop com estágios |
| Contatos | Lista de contatos com tags e filtros |
| Inbox | Chat omnichannel (WhatsApp, Instagram, Chat) |
| Campanhas | Criação e analytics de campanhas |
| Automações | Visualizador de fluxos com nós |
| Base de IA | Documentos indexados + teste de IA |
| Agenda | Compromissos por dia |
| Financeiro | Controle de entradas/saídas |
| Relatórios | Analytics e gráficos |
| Conexões | Gerenciar canais WhatsApp/Instagram |
| Usuários | Gerenciar equipe e permissões |
| Integrações | Conectar com ferramentas externas |
| Billing | Planos, uso e faturamento |
| Configurações | Geral, notificações, segurança, aparência |
| Perfil | Dados do usuário logado |

## Como rodar

```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev
# Acesse: http://localhost:5173

# Build para produção
npm run build
```

## Próximos Passos (Back-end)

Quando o back-end estiver pronto, substitua `src/data/mockData.js` por chamadas reais à API:

```js
// Exemplo: em vez de mockData, use:
const leads = await fetch('/api/leads').then(r => r.json())
```

### Estrutura de API esperada

```
GET    /api/leads
POST   /api/leads
PUT    /api/leads/:id
DELETE /api/leads/:id

GET    /api/contatos
POST   /api/contatos

GET    /api/conversations
POST   /api/conversations/:id/messages

GET    /api/campanhas
POST   /api/campanhas

GET    /api/financeiro
POST   /api/financeiro

GET    /api/usuarios
POST   /api/usuarios/invite

GET    /api/billing
POST   /api/billing/upgrade
```

## Estrutura do Projeto

```
crm-saas/
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Sidebar.jsx       ← Menu lateral
│   │   │   └── Topbar.jsx        ← Barra superior
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Leads.jsx
│   │   │   ├── Pipeline.jsx
│   │   │   ├── Inbox.jsx
│   │   │   └── OtherPages.jsx    ← Todos os outros módulos
│   │   └── ui/
│   │       └── index.jsx         ← Componentes reutilizáveis
│   ├── data/
│   │   └── mockData.js           ← Dados de demonstração
│   ├── store/
│   │   └── useStore.js           ← Estado global (Zustand)
│   ├── App.jsx                   ← Roteamento de páginas
│   ├── main.jsx                  ← Entry point
│   └── index.css                 ← Estilos globais + variáveis CSS
├── index.html
├── vite.config.js
└── package.json
```
